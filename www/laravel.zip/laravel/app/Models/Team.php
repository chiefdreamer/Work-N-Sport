<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class Team extends Model
{

    protected $table = 'teams'; //custom table name   
    
    //protected $primaryKey = 'item_id'; //remap id to item_id
    //public $timestamps = false; // do not use created_at, updated_at
   
   
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id_user',
        'title',
        'description'
    ];
    
 
    
    
    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    //protected $hidden = [
    //    'password', 'remember_token',
    //];
    
}