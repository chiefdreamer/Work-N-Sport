<?php



use Illuminate\Http\Request;



use Jenssegers\Agent\Agent as Agent;
$agent = new Agent();


//used to hide payment gateway
View::share('IS_DESKTOP', $agent->isDesktop());




if( isset($_GET['app']) ){
	View::share('DEFAULT_VIEW', 'layouts.smartphone');
	View::share('INCLUDE_SUB_MENU', false);	
}else{
	View::share('DEFAULT_VIEW', 'layouts.app');
	View::share('INCLUDE_SUB_MENU', true);	
}	





use Illuminate\Support\Facades\Input;




/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/



/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/



Route::group(['middleware' => ['web']], function () {
    //
});












Route::group(['middleware' => 'web'], function () {







//ACTIVATE ACCOUNT
Route::get('/activate', 'ActivateController@index');

Route::get('activate/{confirmationCode}', [
    'as' => 'confirmation_path',
    'uses' => 'ActivateController@checkToken'
]);





	//default page
	Route::get('/', 'WelcomeController@index');
	
	


	//required to auto display login / logout / registration pages
	Route::auth();
	
	
	
	
	








	//Dashboard (login is required)
    Route::get('/dashboard', 'DashboardController@index');
    
    

	//Redirect to handicap international
	//from smartphone to bypass cors
    Route::get('/hi', 'WelcomeController@hi');
    
    
 
    
    //TEAMS
    


	//Display teams
    Route::get('/teams', 'TeamsController@index'); 
	
	
	//Update Existing Team
    Route::post('/teams/update', 'TeamsController@update');
    
    
	//Add New Team
    Route::post('/teams/store', 'TeamsController@store');


    // Delete Team
    Route::delete('/teams/delete/{id}', 'TeamsController@delete');
    
   
   
    // Moves app
    // activation 
    // 1] participant activation by selection in dropdown
    // 2] participant activation by email
    // 3] participant activation by email (not logged in)
    Route::get('/moves', 'MovesController@index'); 
    
    
    
    Route::get('/moves/faq', 'MovesController@faq');
    Route::get('/moves/error', 'MovesController@error');
     
    Route::get('/moves/activated', 'MovesController@activated'); 
    
    // lsm 11/4/16
    //not logged in send activation by email
    Route::get('/moves/email', 'MovesController@email');    





   
    // Participants
    Route::get('/participants', 'ParticipantsController@index'); 
    


	//////////////////////////////////// DESKTOP
    // Rankings
    Route::get('/rankings', 'RankingsController@index');
    
    
    // Rankings C1 (QTR 4 2016)
    // Rankings C2 (QTR 1 2017)
    // Rankings C3 (QTR 2 2017)
    Route::get('/rankings/{CX}', 'RankingsController@rankingsCX', function ($CX=""){return $CX;});
        

    
	// CNOSF
	// My Rankings  /  My ranking (uses CNOSF id: 140)
    Route::get('{my}/rankings/{clientcode}', 'RankingsController@index');
    
    
    
        
    
    // My Rankings  /  My ranking (uses id of logged in user)
    Route::get('{my}/rankings', 'RankingsController@index', function ($my=""){
    	return $my;
	});
	

	


    // Rankings DEV
    Route::get('/rankings-dev', 'RankingsControllerDev@index');
    

    // Rankings Updating
    Route::get('/rankings/updating', 'RankingsControllerDev@updating');
    
    
    
    
    //////////////////////////////////// SMARTPHONE
    // Rankings
    Route::get('/rankings-smartphone', 'RankingsController@index');
    Route::get('/{my}/rankings-smartphone', 'RankingsController@index', function ($my=""){return $my;});
    
    
    //Route::get('/account-smartphone', 'AccountController@index');
     
     
     
     
  

    // Account
    Route::get('/account', 'AccountController@index');
    
    //Invoices
    Route::get('/account/invoices', 'AccountController@invoices'); 
    

    
    //Account Update
    Route::post('/account/update', 'AccountController@update');
      
   
   // Subscribe
    Route::get('/subscribe', 'SubscribeController@index');
 
 
    
    // About
    Route::get('/about', 'AboutController@index');
    
    // Subscription info
    Route::get('/subscriptions', 'SubscriptionsController@index');  
    
    // Contact
    Route::get('/contact', 'ContactController@index'); 
    Route::post('/contact/send', 'ContactController@send');
    
    
    // FAQ
    Route::get('/faq', 'FaqController@index'); 
    
    
        
   
   
    // Privacy
    Route::get('/privacy', 'PrivacyController@index');
    
    // Terms
    Route::get('/terms', 'TermsController@index');


 	// Languages
	Route::get('lang/{lang}', ['as'=>'lang.switch', 'uses'=>'LanguageController@switchLang']);
	
	
	
	
	
    // Online Payments
    Route::get('/payment-return', 'PaymentsController@index');
    
    Route::get('/payment-process', 'PaymentsController@process');



});

