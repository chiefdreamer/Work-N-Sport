<?php

namespace App\Http\Controllers;



use App\Http\Requests;
use Illuminate\Http\Request;


use Validator;
use Auth;
use App\Models\User;
use DB;

use Lang;

use View;

use Route;



class AccountController extends Controller
{




    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

        
    }







    /**
     * Show the account page.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
   

    
    //if( $_SERVER['HTTP_X_REQUESTED_WITH'] == 'your_android_app_package_name' ) {
   //...Inject your javascript code
   
 

   
        //if not logged in 
        
        if (!Auth::check()) { 
        
     			if( isset($_GET['app'])  && $_GET['app']=='1' ){
					return redirect('login?app=1');
				}else{
					return redirect('login');
				}
        
        }
        
        
        
        //if email not verified    
        if (Auth::user()->confirmed == "0") { 
        
             	if( isset($_GET['app'])  && $_GET['app']=='1' ){
					return redirect('activate?app=1');
				}else{
					return redirect('activate');
				}
        
        }
        
        
        
        
        
    	$user = User::where('id',Auth::user()->id)->first();
    	
    	
    		$is_checked='';
    		if(($user->private_challenge)==1){$is_checked="checked='checked'";}
    		
    		$is_checked2='';
    		if(($user->non_commercial)==1){$is_checked2="checked='checked'";}
    		
    		$is_checked3='';
    		if(($user->email_updates)==1){$is_checked3="checked='checked'";}
    	

    		
    	
    		$cg_cities_unserialized = unserialize($user->cg_cities);
    		
    		//$cg_cities_unserialize = explode($cg_cities_unserialize);
 								
											
			$selectOptions = array(
			'1'  => 'Annecy-le-Vieux',
			'2'  => 'Marseille',
			'3'  => 'Puteaux',
			'4'  => 'Mexico',
			'5'  => 'UK',
			'6'  => 'Romania',
			'8'  => 'US',
			'10'  => 'South Africa',
			'11'  => 'Australia',
			'12'  => 'Japan',
			'13'  => 'Turkey',
			'14'  => 'Nigeria',
			'15'  => 'Abu Dhabi',
			'16'  => 'Ecuador'
			);

			$html_multselect = '<select id="cg_cities" name="cg_cities[]" multiple="multiple">';

			$selected="";
			foreach($selectOptions as $key => $value){
				if(is_array($cg_cities_unserialized)){
					$selected = in_array($key, $cg_cities_unserialized) ? 'selected ' : '';
				}
					$html_multselect .= '<option ' . $selected . 'value="' . $key . '">' . $value . '</option>';
			}
		

			$html_multselect .= '</select>'; 



         	return view('account.index', [
			'company' => $user->company,
			'first_name' => $user->first_name,
			'last_name' => $user->last_name,
			'email' => $user->email,
			'phone' => $user->phone,
			'address' => $user->address,
			'city' => $user->city,
			'postcode' => $user->postcode,
			'country' => $user->country,
			'password' => $user->password,
			'html_multselect' => $html_multselect,
			'is_checked' => $is_checked,
			'is_checked2' => $is_checked2,
			'is_checked3' => $is_checked3
			]);	
	
		
			
    }
 
 

 
 
  public function update(Request $request)
	{

	    
	    //You only want to throw a validation error 
	    //if the user provides an e-mail address 
	    //that is already used by a different user. 
	    //To tell the unique rule to ignore the user's ID, 
	    //you may pass the ID as the third parameter:
	    
	    //'email' => 'required|email|max:255',
	    //'email' => 'required|email|max:255|unique:users,email,'.Auth::user()->id,
	    
		$this->validate($request, [
        'company' => 'required|min:2|max:255',
        'first_name' => 'required|max:255',
        'last_name' => 'required|max:255',
        'email' => 'required|email|max:255|unique:users,email,'.Auth::user()->id,
        'phone' => 'required|max:255',
        'password' => 'required|confirmed|min:6',
        'country' => 'required|min:2',
    	]);
    	
    
    
    
    

		$company = trim($request->company);
		$non_commercial = trim($request->non_commercial);
		$first_name = trim($request->first_name);
		$last_name = trim($request->last_name);
		$email = trim($request->email);
		$phone = trim($request->phone);
		$address = trim($request->address);
		$city = trim($request->city);
		$postcode = trim($request->postcode);
		$country = trim($request->country);
		$password = bcrypt($request->password);
		$cg_cities = $request->cg_cities;
		$private_challenge = ($request->private_challenge);
		$email_updates = ($request->email_updates);
		
		
		$cg_cities_serialized = serialize($cg_cities);
		

		
		$row1 = DB::table('users')->where('id', Auth::user()->id)->update(
    		['company' => $company, 'non_commercial' => $non_commercial, 'first_name' => $first_name, 'last_name' => $last_name, 'email' => $email, 'phone' => $phone, 'address' => $address, 'city' => $city, 'postcode' => $postcode, 'country' => $country, 'password' => $password, 'cg_cities' => $cg_cities_serialized, 'private_challenge' => $private_challenge, 'email_updates' => $email_updates, 'updated_at' => date('Y-m-d H:i:s')]
		);
		
		
		//PUT HERE AFTER YOU SAVE
		$var = \Lang::get('wns.Votre compte a été sauvegardé.');
		
    	\Session::flash('flash_message',$var);
    
	


		if( isset($_GET['app']) && $_GET['app']=='1' ){
			return redirect('account?app=1');
		}else{
			return redirect('account');
		}
				

	}








	public function invoices()
	{

	
	
	
	      
        if (!Auth::check()) { 
        
     			if( isset($_GET['app'])  && $_GET['app']=='1' ){
					return redirect('login?app=1');
				}else{
					return redirect('login');
				}
        
        }
        
        
        
        //if email not verified    
        if (Auth::user()->confirmed == "0") { 
        
             	if( isset($_GET['app'])  && $_GET['app']=='1' ){
					return redirect('activate?app=1');
				}else{
					return redirect('activate');
				}
        }
        
        
        
		$invoices = DB::table('invoices')->where('user_id',Auth::user()->id)->orderby('id','DESC')->get();
		
			return view('account.invoices', [
			'invoices' => $invoices,
			'id_user' => Auth::user()->id
		]);

	}
	
	
}
