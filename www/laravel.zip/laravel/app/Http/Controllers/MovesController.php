<?php


    // activation 
    // 1] participant activation by selection in dropdown
    // 2] participant activation by email
    // 3] participant activation by email (not logged in)
    
    
    
namespace App\Http\Controllers;


use App\Http\Requests;
use Illuminate\Http\Request;



//custom class in libraries folder
use App\Libraries\Moves;

use DB;
use Auth;



class MovesController extends Controller
{





    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

        //login required    
       	//$this->middleware('auth');
       	
       	//required activate email account
        //$this->middleware('activated');  

   
    }

    /**
     * Show the moves page.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {


		//IMPORTANT: THIS FUNCTION CANNOT BE BLOCKED REQUIRES ACCESS NON-LOGGED IN PARTICIPANTS
		
		
		
	    // lsm 11/7/16
		//if not logged in and no user_id (state) from email then redirect to email form 
		if(!Auth::check() && !$request->state){
			return redirect('moves/email');
		}
		
		
		// lsm 11/7/16
		//if error and user_id (state)  is in URL then redirect to email form 
		if($request->error && $request->state){
			return redirect('moves/email');
		}
		
		
 
        
     	//if not logged in 
        //if (!Auth::check()) { return redirect('login');}
        

        
        //if email not verified    
        //if (Auth::user()->confirmed == "0") { return redirect('activate');}
        
  
 
			$request_token = '';
			$tokens = '';
			$access_token = '';
			$refresh_token = '';
			$profile = '';
			$userId = '';
	
			
	require(app_path() . '/Functions/movesConfig.php');

	$m = new Moves($client_id,$client_secret,$redirect_url);
	$request_url = $m->requestURL();

				
		
		if (isset($_GET['code'])!='') {

			$request_token = $_GET['code'];
			$tokens = $m->auth($request_token);
	
			//Save this token for all future request for this user
			$access_token = $tokens['access_token'];
	
			//Save this token for refeshing the token in the future
			$refresh_token = $tokens['refresh_token'];
			
			
			$isAccessTokenValid = $m->validate_token($access_token);
			
		
			


			if($isAccessTokenValid){
				//SAVE MOVES DATA
				
				//... @state appended to URL eg.
				// https://api.moves-app.com/oauth/v1/authorize?response_type=code&client_id=t6HNc4_kcmXx4PUDTXBjJ8agBS41drZu&scope=activity&redirect_uri=http%3A%2F%2Fwww.workn-sport.com%2Fmoves&state=90
				$id_participant = $request->state;
				
				
				$profile = json_encode($m->get_profile($access_token));	
				$profile = json_decode($profile);					
				$userId = $profile->userId;
				
				// lsm 12/6/16 (added userId)
				$row1 = DB::table('participants')->where('id', $id_participant)->update(
					['moves_id_user' => $userId, 'access_token' => $access_token, 'refresh_token' => $refresh_token, 'updated_at' => date('Y-m-d H:i:s')]
				);
				
				return redirect('moves/activated');
		
			}else{
				return redirect('moves/error');
			}
	
		
		}
	
	
		
		
		// DISPLAY PARTICIPANTS TO DIRECTLY ACTIVATE IN DROPDOWN
		
		$participants = Array();		
		$participants = DB::table('participants')->where('last_name','!=','')->where('email','!=','')->where('id_user',Auth::user()->id)->orderBy('last_name', 'ASC')->orderBy('first_name', 'ASC')->get();
		
		if (isset($_GET['participant_id'])){
			$participant_selected = $_GET['participant_id'];
		}else{		
			$participant_selected='';
		}
		
		return view('moves.index', [
			'client_id' => $client_id,
			'request_url' => $request_url,
			'request_token' => $request_token,
			'participant_selected' => $participant_selected,
			'access_token' => $access_token,
			'refresh_token' => $refresh_token,
			'profile' => $profile,
			'participants' => $participants,
		]);
		


    }
 
 // lsm 11/4/16
 
 //not logged in display email form
 public function email()
    {
		return view('moves.email', [
		]);
    }
  
  

      
      
      
    
 public function activated()
    {
		return view('moves.activated', [
		]);
    }


 public function faq()
    {
		return view('moves.faq', [
		]);
    }
    
  public function error()
    {
		return view('moves.error', [
		]);
    }   	
	
}












