<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;


class WelcomeController extends Controller
{



    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
    	//login required
        //$this->middleware('auth');
        
        // ******************************
   		// SET SMARTPHONE / DESKTOP TEMPLATES
 		// ******************************
  	
    	
    }
    
     public function hi(Request $request)
    {
    return redirect('http://www.handicap-international.fr');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
   
   
   
    	// ******************************
   		// SWITCH TO SMARTPHONE PAGES  / Framework7
 		// ******************************
  

    	// ******************************
   		// SWITCH TO SMARTPHONE
 		// ******************************
  		if( isset($_GET['app']) ){
  			return redirect('smartphone');
    	}
    	
  	

        return view('welcome.index');
        
        
        //return redirect('http://www.moves-app.com/');
        
        
    }
 


    public function smartphone(Request $request)
    {
   
        return view('auth.login');
   
    }
     
     
     
	
	
}
