<?php

namespace App\Http\Controllers;



use App\Http\Requests;
use Illuminate\Http\Request;


use Validator;
use Auth;


use App\Models\Team;


use DB;


//custom class in libraries folder
use App\Libraries\Moves;

class TeamsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
    	//login required    
       	$this->middleware('auth');
       	
       	//required activate email account
        $this->middleware('activated');
    }






	//view teams
	
    public function index()
    {
    
    	include(app_path() . '/Functions/movesConfig.php');
		$m = new Moves($client_id,$client_secret,$redirect_url);
		
        //return view('teams.index');
        
        $teams = Team::where('id_user',Auth::user()->id)->orderBy('title', 'asc')->get();
	
	
		//create participants list belonging to team id	
		$teams_participants =Array();
		
		$at_least_one_in_team_not_activated =Array();
	
		foreach ($teams as $team){	

			$participants = DB::table('participants')->where('id_team', ($team->id))->orderby('id')->get();
		
			$c=0;
			
			$at_least_one_in_team_not_activated[$team->id] = false;
			
			foreach ($participants as $participant){	
				$c++;
				if($c>3){break;}
				
				//check token
				
				//DEFAULT:  DISPLAY RED NOT CONNECTED
				
				
				$activate_label ='Activez Moves';
				
				if (\Lang::getLocale() =='fr'){
					$activate_label="Activez Moves";
					$activate_label_email="Envoyez un email pour activer";
				}else{
					$activate_label="Activate Moves";
					$activate_label_email="Send an email to activate";
				}
				
				$green =	' <a href="/moves?participant_id='.$participant->id.'"><img style="height:15px; margin: 0 5px 0 0" src= "http://www.workn-sport.com/images/icon_moves.png"></a> ';
				$red =		' <a href="/moves?participant_id='.$participant->id.'"><img style="height:15px; margin: 0 5px 0 0" src= "http://www.workn-sport.com/images/icon_red.png"> '.$activate_label.' </a> | <a href="#"  onClick="activate_moves(\''.$participant->id.'\',\''.$participant->email.'\');return false;">'.$activate_label_email.'</a>';
			
				$is_ok = $red;
				
				
				
				$token = $participant->access_token;
			
				//$caloriesAvailable ='';
				
				$platform ='';
								
				if($token!=''){
				
					
					$is_ok = $green;
					

					

				
					
					
					//check cache	
					$refresh_data = false;
					$now = date(time());
					$pts_updated = strtotime($participant->pts_updated);
					
					
					
					
					
					// if more than 6 hrs have passed //6*60*60 
					//$range = (1*60*60);	
					//if ($pts_updated < $now-$range){
					//	$refresh_data = true;
					//} 
					
					
					// lsm 12/20/16
					//always check if tokens are valid 
					$refresh_data = true;
					 
					 
					 
					 //never check tokens for these companies as teams page takes too long to load
					 
					 //Talan
					if($participant->id_user == 154 ){
						$refresh_data = false;
					}
					
					
					
					
				
					if($refresh_data){
						$isAccessTokenValid = $m->validate_token($token);	
								
						if(!$isAccessTokenValid){$is_ok = $red;}
						
						if($isAccessTokenValid){
						
							
							$profile = json_encode($m->get_profile($token));	
							$profile = json_decode($profile);				
						
							
							//$platform = "(".$profile->profile->platform.")";
							
							
							
							
							//$caloriesAvailable = $profile->profile->caloriesAvailable;
						
							/*
							if(!$caloriesAvailable){
								$caloriesAvailable='<span style="color:#FF0000">Calorie counter not activated in Moves App</span>';
							}else{
								$caloriesAvailable='<span style="color:#157e19">Calories activated</span>';
							}
							*/
						}else{
							// lsm 12/20/16
							// if token not valid
							$at_least_one_in_team_not_activated[$team->id]  = true;
						}
						
					}
				
				}else{
					//if any fields completed and there is no token show alert on main table
					if($participant->first_name !='' || $participant->last_name !='' || $participant->email !=''){
					$at_least_one_in_team_not_activated[$team->id]  = true;
					}
				}
	
	
				

			
				//NOT USED
				//$teams_participants[$team->id]['moves'.$c] 	= $is_ok." ".$caloriesAvailable." ".$platform;
				
				//do not show moves activate link if no name or email
				if($participant->first_name !='' && $participant->last_name !='' && $participant->email !=''){
				
					if($participant->pts ==0){
						$teams_participants[$team->id]['moves'.$c] 	= $is_ok;
					}else{
						$teams_participants[$team->id]['moves'.$c] 	= $is_ok." ".$participant->pts." pts";
					}
				
				}else{
					
					
					if (\Lang::getLocale() =='fr'){
						$teams_participants[$team->id]['moves'.$c] =' Le prénom, nom et email sont requis pour activer Moves';
					}else{
						$teams_participants[$team->id]['moves'.$c] =' First name, last name and email are required to activate Moves';
					}
				
				}
				
				
			
					$teams_participants[$team->id]['first_name'.$c] 	= $participant->first_name;
					$teams_participants[$team->id]['last_name'.$c] 		= $participant->last_name;
					$teams_participants[$team->id]['email'.$c] 			= $participant->email;
				
				
	
				
			}
		}
		
	
	
	
					////////*************
					////////*************
					//use main account user details for first participant defaults
					// IF NO TEAMS YET
					
					$participant1_default =Array();
					
					if(count($teams_participants) ==0){
					
						$user = DB::table('users')->where('users.id',Auth::user()->id)->first();
						$first_name_default = $user->first_name;
						$last_name_default = $user->last_name;
						$email_default = $user->email;
			
						$participant1_default['first_name1'] 		= $first_name_default;
						$participant1_default['last_name1'] 		= $last_name_default;
						$participant1_default['email1'] 			= $email_default;
					
					}
	
	
	  
	  
		
		
		return view('teams.index', [
			'teams' => $teams,
			'participant1_default' => $participant1_default,
			'teams_participants' => $teams_participants,
			'at_least_one_in_team_not_activated' => $at_least_one_in_team_not_activated,
		]);
		
    }
    
 
 


	//edit team
    //public function update(Request $request, $id)
    
    //aaaarg ->first(); needed to return result !!!!
    
    public function update(Request $request)
	{

		$id = $request->id;
		$team_to_edit = Team::where('id','=',$id)->first();
		

	    $participant1 = DB::table('participants')->where('pos', 1)->where('id_team', ($id))->orderby('id')->first();
	    $participant2 = DB::table('participants')->where('pos', 2)->where('id_team', ($id))->orderby('id')->first();
	    $participant3 = DB::table('participants')->where('pos', 3)->where('id_team', ($id))->orderby('id')->first();
	    
	
		$this->validate($request, [
        'title' => 'required|min:3|max:255',
    	]);
    
    
    	
    	if(isset($participant1->id)){
			$this->validate($request, [
			'email1' => 'required|email|max:255',
			]);
    	}
    	
    	if(isset($participant2->id)){
			$this->validate($request, [
			'email2' => 'email|max:255',
			]);
    	}
    	
    	if(isset($participant3->id)){
			$this->validate($request, [
			'email3' => 'email|max:255',
			]);
    	}

		
		
		
		
		
		
		$team_to_edit->title = $request->title;
		$team_to_edit->description = $request->description;
		
		$team_to_edit->save();
		
		
		
		
		//Update / create participants
		
		
		$id_user = Auth::user()->id;
		
		
		$first_name1 = trim($request->first_name1);
		$last_name1 = trim($request->last_name1);
		$email1 = trim($request->email1);
		
		if(isset($participant1->id)){	
			$row1 = DB::table('participants')->where('pos', 1)->where('id_team', $id)->update(
				['first_name' => $first_name1, 'last_name' => $last_name1, 'email' => $email1, 'updated_at' => date('Y-m-d H:i:s')]
			);			
		}else{
			$first_name1 = trim($request->first_name1);
			$last_name1 = trim($request->last_name1);
			$email1 = trim($request->email1);
			$row1 = DB::table('participants')->insert(
				['id_user' => $id_user, 'id_team' => $id, 'pos' => 1,'first_name' => $first_name1, 'last_name' => $last_name1, 'email' => $email1, 'created_at' => date('Y-m-d H:i:s')]
			);
		}

		
	
		$first_name2 = trim($request->first_name2);
		$last_name2 = trim($request->last_name2);
		$email2 = trim($request->email2);
		
		if(isset($participant2->id)){		
			$row1 = DB::table('participants')->where('pos', 2)->where('id_team', $id)->update(
				['first_name' => $first_name2, 'last_name' => $last_name2, 'email' => $email2, 'updated_at' => date('Y-m-d H:i:s')]
			);
		}else{
			$first_name2 = trim($request->first_name2);
			$last_name2 = trim($request->last_name2);
			$email2 = trim($request->email2);
			$row2 = DB::table('participants')->insert(
				['id_user' => $id_user, 'id_team' => $id, 'pos' => 2, 'first_name' => $first_name2, 'last_name' => $last_name2, 'email' => $email2, 'created_at' => date('Y-m-d H:i:s')]
			);
		}
		

		
		$first_name3 = trim($request->first_name3);
		$last_name3 = trim($request->last_name3);
		$email3 = trim($request->email3);
			
		if(isset($participant3->id)){
			$row3 = DB::table('participants')->where('pos', 3)->where('id_team', $id)->update(
				['first_name' => $first_name3, 'last_name' => $last_name3, 'email' => $email3, 'updated_at' => date('Y-m-d H:i:s')]
			);			
		}else{
			$first_name3 = trim($request->first_name3);
			$last_name3 = trim($request->last_name3);
			$email3 = trim($request->email3);
			$row3 = DB::table('participants')->insert(
				['id_user' => $id_user, 'id_team' => $id, 'pos' => 3, 'first_name' => $first_name3, 'last_name' => $last_name3, 'email' => $email3, 'created_at' => date('Y-m-d H:i:s')]
			);
		}
	

	}
	
	
	
	
	


	

	//new team
    public function store(Request $request)
	{
		//add custom field
		$request->merge(array('id_user' => Auth::user()->id));
		
	
		

		//|unique:participants DOES NOT WORK
	    $this->validate($request, [
        'title' => 'required|min:3|max:255',
        'email1' => 'required|email|max:255',
        'email2' => 'email|max:255',
        'email3' => 'email|max:255',
    	]);
    


		$input = $request->all();
		$team_created = Team::create($input);
		
		
		
		$id_user = Auth::user()->id;
		$id_team = $team_created->id;	//last insert id	
		
	
		
		//Add new participants
		
		$first_name1 = trim($request->first_name1);
		$last_name1 = trim($request->last_name1);
		$email1 = trim($request->email1);
		$row1 = DB::table('participants')->insert(
    		['id_user' => $id_user, 'id_team' => $id_team, 'pos' => 1,'first_name' => $first_name1, 'last_name' => $last_name1, 'email' => $email1, 'created_at' => date('Y-m-d H:i:s')]
		);
		
		$first_name2 = trim($request->first_name2);
		$last_name2 = trim($request->last_name2);
		$email2 = trim($request->email2);
		$row2 = DB::table('participants')->insert(
    		['id_user' => $id_user, 'id_team' => $id_team, 'pos' => 2, 'first_name' => $first_name2, 'last_name' => $last_name2, 'email' => $email2, 'created_at' => date('Y-m-d H:i:s')]
		);
		
		$first_name3 = trim($request->first_name3);
		$last_name3 = trim($request->last_name3);
		$email3 = trim($request->email3);
		$row3 = DB::table('participants')->insert(
    		['id_user' => $id_user, 'id_team' => $id_team, 'pos' => 3, 'first_name' => $first_name3, 'last_name' => $last_name3, 'email' => $email3, 'created_at' => date('Y-m-d H:i:s')]
		);



	}
	
	
	

	//delete team
    public function delete(Team $id)
	{

		
		
		//delete team participants  
		DB::table('participants')->where('id_team', ($id->id))->delete();

	
		//delete team
		$id->delete();

		
    	return redirect('/teams');
	}
	
	
}










