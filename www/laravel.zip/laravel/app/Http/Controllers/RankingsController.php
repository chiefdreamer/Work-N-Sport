<?php

namespace App\Http\Controllers;



use App\Http\Requests;
use Illuminate\Http\Request;


use Validator;
use Auth;


use DB;


//custom class in libraries folder
use App\Libraries\Moves;


use Lang;

use Route;

use View;



class RankingsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
     

			
					
    public function __construct()
    {
    	//login required    
       	//$this->middleware('auth');
       	
       	//required activate email account
        //$this->middleware('activated');
        
		
	

    }



	public function updating()
    {
        return view('rankings.updating');
    }
	
	
	//view 
	// lsm 7/10/17 added clientcode from routes.php
    public function index($my="",$clientcode="")
    {




 

		//********
		//********
		// MAIN SETTINGS
		//********
		$initial_start_date = '2016-04-01';
		
		//challenge 1
		if(date("Y-m-d") >= '2016-11-07'){
			$initial_start_date 	= '2016-11-07';
			$end_date				= '2016-12-31';
		}
				
		//challenge 2
		if(date("Y-m-d") >= '2017-01-10'){
			$initial_start_date 	= '2017-01-10';
			$end_date				= '2017-03-31';
		}
				
		//challenge 3
		if(date("Y-m-d") >= '2017-04-02'){
			$initial_start_date 	= '2017-04-01';
			$end_date				= '2017-06-30';
		}
		
		//challenge 4
		if(date("Y-m-d") >= '2017-07-02'){
			$initial_start_date 	= '2017-07-01';
			$end_date				= '2017-09-30';
		}
		
		
		
		//challenge 5
		if(date("Y-m-d") >= '2017-09-30'){
			$initial_start_date 	= '2017-07-01';
			$end_date				= '2017-31-31';
		}
		
		
		//OPEN / CURRENT
		if(date("Y-m-d") >= '2017-12-31'){
			$initial_start_date 	= '2018-01-01';
			$end_date				= date("Y-m-d");
		}
		
		
		
		
		
		
		
		//REED
		if($clientcode=="reed"){
			$initial_start_date 	= '2017-10-09';
			$end_date				= '2017-10-19';
		}
		
		
		  
		 
	  	
		//********
		$maxresultsCompanies = 200;
		$maxresultsTeams = 400;
		//********
		//********	
		
		
	
		
		// no login required
		// lsm 7/10/17
		
		// lsm 10/9/17 (reed)
		if($clientcode!="cnosf" && $clientcode!="reed"){
	
					
        
			//if not logged in 
			if($my=="my"){
		
				//if not logged in 
				// lsm 5/18/16
				//keep app to switch to smartphone
				if (!Auth::check()) {
					if( isset($_GET['app']) ){
						return redirect('login?app=1');
					}else{
						return redirect('login');
					}
				}
		
		
				//if email not verified    
				if (Auth::user()->confirmed == "0") { 
					if( isset($_GET['app']) ){
						return redirect('activate?app=1');
					}else{
						return redirect('activate');
					}	
				}  
			}
  
  
  		}
  
  	
				
      
        
        
        include(app_path() . '/Functions/movesConfig.php');
		$m = new Moves($client_id,$client_secret,$redirect_url);
		
		//$participants = DB::table('participants')->paginate(100);
		

		
		

		$participants = Array();
		
		$companies_ranking = Array();
		$teams_ranking = Array();
		

		
		//$participants = DB::table('participants')->where('access_token','!=', '')->orderBy('last_name', 'ASC')->orderBy('first_name', 'ASC')->get();


		//GET ALL PARTICIPANTS WHO HAVE TOKEN AND NOT IN PRIVATE MODE
		
		//->where('users.private_challenge','=',0)
		
		$participants = DB::table('participants')
		   ->join('users', 'participants.id_user', '=', 'users.id')	
		   ->selectRaw('participants.pts_updated, participants.access_token, participants.refresh_token, participants.id_team ,participants.id_user, participants.id as participant_id') 	   		   
		   ->where('participants.access_token','!=', '')
		   ->orderBy('participants.last_name', 'ASC')
		   ->orderBy('participants.first_name', 'ASC')
		   ->get();
		   
	



	

		
		if (count($participants)) {
		
			
			//********
			//********
			// NOTES 
			// IF MOVES PROFILE IS NULL MAIN LOOP SKIPS TO NEXT PARTICIPANT
			// PTS IS READ FROM MOVES EVERY 24 HRS
			
			foreach ($participants as $participant){	
				
			
				$teams = DB::table('teams')->where('id',($participant->id_team))->first();
				$participant->team = $teams->title;
				
				$users = DB::table('users')->where('id',($participant->id_user))->first();
				$participant->company = $users->company;
				
	
				
				$token = $participant->access_token;
				$refresh_token = $participant->refresh_token;


			
			
				//NO NEED TO CHECK ACCESS TOKEN HERE
				//$isAccessTokenValid = $m->validate_token($token);

				$isAccessTokenValid = true;
				
				
				
				//var_dump($isAccessTokenValid);
			
				
				//NOT APPLICABLE
				if($isAccessTokenValid==true){
				
				
					//check cache
					
					$refresh_data = false;
					$now = date(time());
					$pts_updated = strtotime($participant->pts_updated);
		
		
		
		
					
					 
					
					
					// *****************
					// *****************
					// *****************
					// MOVED TO public/cron_update_async.php
					// crontab runs at midnight everyday
					// *****************
					// *****************
					// *****************
					// *****************
					
					
					
					
					// VARIES PER PARTICIPANT
					// if more than 24 hrs have passed
					//24*60*60 
					
					//90 days
					$range = (90*24*60*60);	
					if ($pts_updated < $now-$range){
						$refresh_data = true;
		
					}
				


					//NO REFRESH OF POINTS
					// SEE cron_update_async_api.php
					$refresh_data = false;
					//******
					//******
					//******
					//******
					
					
					
					
					
					
		
				//******IMPORTANT MAX 31 DAYS PER RANGE QUERY
				
				//NOT OK
				//'2016-04-01',date('2016-05-31')
				
				//OK
				//'2016-05-01',date('2016-05-31')
				
				//date('Y-m-d')
				
				if($refresh_data){
				
				
				
				//REFRESH TOKEN CODE REMOVED !!!
				
				
				
				
					//LOOP THROUGH MONTHS	
				
					//RESET pts
					$pts = 0;
					
					//$firstDate="";
					
					//FIRST DATE DATA IS AVALABLE FOR USER
					$profile = json_encode($m->get_profile($token));	
					$profile = json_decode($profile);
				
		
					
					$firstDate = $profile->profile->firstDate;
					$firstDate = strtotime($firstDate);

					//if($token=="Cc1jK3CFI91h3m528MGwFg4XLFdL6D5MXlhcK9u96N16DvXthT4n7cy2IfUVh451"){
						    //var_dump ("firstDate ".$profile->profile->firstDate);
					//}
					
					//Cc1jK3CFI91h3m528MGwFg4XLFdL6D5MXlhcK9u96N16DvXthT4n7cy2IfUVh451  (access token)   
					//Xky4aCsRG6a4X9vpHiRcgYSV6AS9m5_494X71n_g06n457SMn0vl8928NifOhF78  (refresh token)
					
					$start = $month = strtotime($initial_start_date);	
					$end = time();//END IS NOW :)
					
					
					//REQUIRED FOR CORRECT DATA RANGE			
					//check if firstDate is more recent than start_date if so use firstDate as start_date
					 if ($firstDate > $start){
						//get the next month as firstDate could have any date in middle of month NO !!
						
						//var_dump($token." FirstDate: ".date('Y-m-d', $firstDate)."<br><br>");
						
						// DG! pay attention to timestamps vs dates !!!!
						//$start = $month = strtotime("+1 month", $firstDate);
						
						
						
						
						$start = $month = $firstDate;
						
						//switch to first of month DO NOT USE   !!!!!!!
						//on 16/5/2014
						//This error returned
						//{"error":"invalid date range: max 31 of days allowed and the requested range must be between user profiles first date and today"} 
						//$start = $month = strtotime(date('Y-m-01', $start)); 
						
				
						
						//var_dump($token." ".date('Y-m-d', $start)."  to ".date('Y-m-d', $end)."<br><br>");
					 }
					 
			
			
		
					
			
					//LOOP THROUGH MONTHS
					while($month < $end)
					{
					
							/*				
							Thirty days hath September,
							April, June, and November.
							All the rest have thirty-one,
							Except for February alone,
							Which hath but twenty-eight days clear
							And twenty-nine in each leap year. 
							*/
					
							 // 01 to (30) OF THE CURRENT ITERATED MONTH
							 
							 
						 	 //current month
							 $start_date =  date('Y-m-d', $month);
							 
				
							 
							 //last day of iterated month (t)
							 $end_date = date('Y-m-t', $month);
							 	
					
						
							 	
							 //check if iterated month is more recent than end if so use end as end_date					 
							 if ( date('Y-m-t',$month) > date('Y-m-d',$end) ){
					 			$end_date = date('Y-m-d', $end);
							 }
	 
	
						
							//if($token=="Cc1jK3CFI91h3m528MGwFg4XLFdL6D5MXlhcK9u96N16DvXthT4n7cy2IfUVh451"){
							//if($token=="_Wp0jCDeZAxJWKnzANCjASFpRCPHCpwZN1xmwW9kHKFfF1qpPefhrjX953EhMKLV"){
						    //var_dump ($start_date." ".$end_date."<br>");
						    //}
						    
						    
						
							//$summary = json_encode($m->get_range($token,'/user/summary/daily',$start_date, $end_date ));
							$summary = json_encode($m->get_range($token,'/user/summary/daily',$start_date, $end_date ));
							

							//if($token=="Cc1jK3CFI91h3m528MGwFg4XLFdL6D5MXlhcK9u96N16DvXthT4n7cy2IfUVh451"){
								//echo($summary);
							//}
							
							if (isset($summary)) {
				
										//get pts
										
										foreach (json_decode($summary) as $item){
										
												if (isset($item->summary[0])) {
													//if($token=="Cc1jK3CFI91h3m528MGwFg4XLFdL6D5MXlhcK9u96N16DvXthT4n7cy2IfUVh451"){
													//	var_dump($token." ".$pts."<br>");
													//}
													//var_dump($token." ".$pts."<br>");
													
													
														/*
														if (isset($item->summary[0]->calories)) {
															$pts_data = ($item->summary[0]->calories);
															$pts += $pts_data;
														}
														*/
													
														if (isset($item->summary[0])) {
													
													
															if($item->summary[0]->group != "transport"){
														
																$pts_data = ($item->summary[0]->duration);
															
																//$pts += $pts_data;
																$pts = $pts + $pts_data;
														
															}
													
											
														}
														
													
													
													
													
												}									
							
										}
						
							}
					
					
					
							 	// ITERATE TO NEXT MONTH
								// FIXED PROB OF PG points, next datedate was being set to +1 =31-05-2016 instead of 02-05-2016)
							
							 	
							 	// lsm 2/17/17
								$month = strtotime(date('Y-m-01', $month));
								$month = strtotime("+1 month", $month);
						
	
			
							 
					}
					//END LOOP THROUGH MONTHS
				
							
							//convert to minutes
							$pts = ($pts/60.0);
							
							
							//save pts to db (NEW PARTICIPANTS WILL HAVE DIFFERENT TIME STAMPS)
							if($pts>0){
								//var_dump($participant->participant_id." ".$token." ".$pts."<br>");
								$row = DB::table('participants')->where('id', $participant->participant_id)->update(
									['pts' => $pts, 'pts_updated' => date('Y-m-d H:i:s')]
								);
							}
				
		
				}//END IF REFRESH DATA
				//NOT APPLICABLE
				

				}//END IF TOKEN IS VALID
				//NOT APPLICABLE


	
													
			}//END MAIN PARTICIPANT LOOP
			
		
			
			//var_dump($companies_ranking);
			
			
		}//END IF THERE ARE PARTICIPANTS
		



		//GET ALL COMPANIES AND TEAMS
		if($my == ""){




		////////////////////
		////////////////////
		////////////////////
		////////////////////
		//MAIN LOOP FOR ALL COMPANIES
		
		/*
		DB::statement(DB::raw('set @row=0'));
		$companies_ranking = DB::table('participants')
		   ->join('users', 'participants.id_user', '=', 'users.id')
		   ->selectRaw('@row := @row + 1 as ranking, sum(pts) as pts_total, users.company as company_title, users.id as id_user')
		   ->where('users.private_challenge',0)
		   ->where('pts','!=',0)
		   ->orderBy('pts_total', 'desc')
		   ->orderBy('company_title', 'asc')
		   ->groupBy('id_user')
		   ->take($maxresultsCompanies)
		   ->get();
		*/
	
			DB::statement(DB::raw('set @row=0'));
			$companies_ranking = DB::select("
				
						SELECT *, @row := @row + 1 as ranking  FROM (SELECT  						 			
						p.id,
						p.id_user,
						u.company as company_title,
						u.id as company_id,
                        IFNULL(sum(p.pts) , 0) AS pts_total
                        FROM participants 
                        AS p                     
                                                  
                        JOIN  (SELECT id, company, private_challenge FROM users)
                        AS u ON p.id_user = u.id 
                        
                   		WHERE (p.pts !=-1   			
            			AND u.private_challenge =0)		
            			
            			GROUP BY id_user
            			ORDER BY pts_total DESC, p.id DESC
            			
            			LIMIT ".$maxresultsCompanies." 
      		
                   		) r ");  
                   			
	
		
		
		//INCORRECT RANKING !!!
		
		//MAIN LOOP FOR ALL TEAMS
	
		/*DB::statement(DB::raw('set @row=0'));
		$teams_ranking = DB::table('participants')
		   ->join('teams', 'participants.id_team', '=', 'teams.id')
		   ->join('users', 'participants.id_user', '=', 'users.id')		   
		   ->selectRaw('sum(pts) as pts_total, teams.title as team_title, users.company as team_company, users.private_challenge')
		   ->selectRaw('@row := @row + 1 as ranking')
		   ->where('users.private_challenge',0)
		   ->where('pts','!=',0)		   	   
		   ->groupBy('id_team')		
		   ->orderBy('pts_total', 'desc')	   
		   ->get();
		*/
		
		
		

		////////////////////
		////////////////////
		////////////////////
		////////////////////
		//MAIN LOOP FOR ALL TEAMS
		
		
		// WOW DID IT MANAGED TO GET #RANKING CORRECT !!!!!!!!!!!!!!!!!!!
		// lsm 5/15/16
		
		// lsm 4/7/17
		// do not show teams with 0 points 
		//WHERE (p.pts !=-1
		//WHERE (p.pts >0
		
		DB::statement(DB::raw('set @row=0'));
		$teams_ranking = DB::select("
				
						SELECT *, @row := @row + 1 as ranking  FROM (SELECT  						 
				
						p.id,
						p.id_user,
						p.id_team,					 
						t.title as team_title,
						t.id as team_id,  
						u.company as team_company,
						u.private_challenge, 
                        IFNULL(sum(p.pts) , 0) AS pts_total
                        FROM participants 
                        AS p
                        
                     
						JOIN (SELECT id, id_user, title FROM teams ) 
                        AS t ON p.id_team = t.id 
                                                  
                        JOIN  (SELECT id, company, private_challenge FROM users)
                        AS u ON p.id_user = u.id 
                        
                   		WHERE (p.pts >0   			
            			AND u.private_challenge = 0)		
            			
            			GROUP BY id_team
            			ORDER BY pts_total DESC, p.id DESC
            			
            			LIMIT ".$maxresultsTeams." 
      		
                   		) r ");  

		
		

	
		
			$initial_start_date_formatted = strtotime($initial_start_date);
			$initial_start_date_formatted = date('d/m/Y',$initial_start_date_formatted);
			
			$end_date_formatted = strtotime($end_date);
			$end_date_formatted = date('d/m/Y',$end_date_formatted);
			
	
				return view('rankings.index', [
					'companies_ranking' => $companies_ranking,
					'teams_ranking' => $teams_ranking,
					'initial_start_date' => $initial_start_date_formatted,
					'end_date' => $end_date_formatted,
					'current_date' => date('d/m/Y'),
				]);
			
	
			
			
	
			
			
			
			
			
			
			 
		}
		
		
		
		
		
		// START MY RANKINGS
		//////////////////////////
		//////////////////////////
		//////////////////////////
		//////////////////////////
		
		

		
		//GET ONLY TEAMS BELONGING TO USER
		if($my == "my"){
		
		
		//MY MY MY MY MY MY  
		//MY MY MY MY MY MY 
		
			
				// KEEP ->where('pts','!=',0)  !!! or RANKING IS WRONG By +1
				
				//GET USER'S COMPANY RANK
				//MAIN LOOP FOR ALL COMPANIES
				/*DB::statement(DB::raw('set @row=0'));
				$companies_ranking_RANK = DB::table('participants')
				   ->join('users', 'participants.id_user', '=', 'users.id')
				   ->selectRaw('@row := @row + 1 as ranking, sum(pts) as pts_total, users.company as company_title, users.id as user_id')
				   ->where('users.private_challenge',0)
				   ->where('pts','!=',0)
				   ->orderBy('pts_total', 'desc')
				   ->orderBy('company_title', 'asc')
				   ->groupBy('id_user')
				   ->get();
				   */
				   
				   		DB::statement(DB::raw('set @row=0'));
						$companies_ranking_RANK = DB::select("
				
						SELECT *, @row := @row + 1 as ranking  FROM (SELECT  						 			
						p.id,
						p.id_user,
						u.company as company_title,
						u.id as user_id, 
                        IFNULL(sum(p.pts) , 0) AS pts_total
                        FROM participants 
                        AS p                     
                                                  
                        JOIN  (SELECT id, company, private_challenge FROM users)
                        AS u ON p.id_user = u.id 
                        
                   		WHERE (p.pts !=-1   			
            			AND u.private_challenge = 0)		
            			
            			GROUP BY id_user
            			ORDER BY pts_total DESC, company_title ASC

      		
                   		) r ");  
                   		
                   
                   
                 // lsm 7/10/17 (cnosf) 	
                 
                 // lsm 10/9/17 (reed) 		 
				 if($clientcode=="cnosf"){
				 	$current_user_id = 140;
				 	$current_user_private_challenge = 1;
				 }elseif($clientcode=="reed"){
				 	$current_user_id = 234;
				 	$current_user_private_challenge = 1;
				}else{
				 	$current_user_id  = Auth::user()->id;
				 	$current_user_private_challenge = Auth::user()->private_challenge;
				 }
				 
				 
				   		 
				 $company_rank =0;
				 //match user id to get current rank
				 //loop through ALL companies
				 
				 foreach ($companies_ranking_RANK as $item){
				 	if($item->user_id == $current_user_id){
				 		$company_rank = $item->ranking; break;
				 	}
				 }  
				 
				 
				   
		
				
		
				//INCORRECT RANKING !!!
				
				//GET USER'S TEAM RANKINGS
				/*
				DB::statement(DB::raw('set @row=0'));
				$teams_ranking_RANK = DB::table('participants')
				   ->join('teams', 'participants.id_team', '=', 'teams.id')
				   ->join('users', 'participants.id_user', '=', 'users.id')
				   ->selectRaw('@row := @row + 1 as ranking,  sum(pts) as pts_total, teams.title as team_title, users.company as team_company, users.private_challenge, teams.id as team_id')
				   ->where('users.private_challenge',0)
				   ->where('pts','!=',0)
				   ->orderBy('pts_total', 'desc')
				   ->groupBy('id_team')
				   ->get();
				 */
				 
				 
				 
			 
				//MY MY MY MY MY MY  
				//MY MY MY MY MY MY 
				
				
				//GET THE TEAM RANK FROM GLOBAL LIST
				// p.pts >0 
				
				DB::statement(DB::raw('set @row=0'));
				$teams_ranking_RANK = DB::select("
				
						SELECT *, @row := @row + 1 as ranking  FROM (SELECT  						 
				
						p.id,
						p.id_user,
						p.id_team,					 
						t.title as team_title, 
						t.id as team_id, 
						u.company as team_company,					
						u.private_challenge, 						
                        IFNULL(sum(p.pts) , 0) AS pts_total
                        FROM participants 
                        AS p  
                     
						JOIN (SELECT id, id_user, title FROM teams ) 
                        AS t ON p.id_team = t.id 
                                                  
                        JOIN  (SELECT id, company, private_challenge FROM users)
                        AS u ON p.id_user = u.id 
                        
                   		WHERE (p.pts >0   			
            			AND u.private_challenge = 0)		
            			
            			GROUP BY id_team
            			ORDER BY pts_total DESC, title ASC
      		
                   		) r ");  
		
		
				$team_rank = Array();
				 //store all team id in array to get current rank
			
					 foreach ($teams_ranking_RANK as $item){		
						$team_rank[$item->team_id] = $item->ranking;				 				
					 } 
		

		
		
		//MAIN LOOP FOR USERS'S COMPANY WITH POINTS
		
		$companies_ranking = DB::table('participants')
		   ->join('users', 'participants.id_user', '=', 'users.id')
		   ->selectRaw('sum(pts) as pts_total, users.company as company_title, users.id as company_id')
		   ->where('users.id',$current_user_id) 
		   ->where('pts','>=',0)
		   ->orderBy('pts_total', 'desc')
		   ->orderBy('company_title', 'asc')
		   ->groupBy('id_user')
		   ->get();
		
		   
		

		
	 
		   
		   
		   
		//INCORRECT RANKING !!!
		   
		//MAIN LOOP FOR USERS'S TEAMS WITH POINTS
		/*DB::statement(DB::raw('set @row=0'));
		$teams_ranking = DB::table('participants')
		   ->join('teams', 'participants.id_team', '=', 'teams.id')
		   ->join('users', 'participants.id_user', '=', 'users.id')
		   ->selectRaw('@row := @row + 1 as ranking, sum(pts) as pts_total, teams.title as team_title, users.company as team_company, users.private_challenge, teams.id as team_id')
		   ->where('users.id',Auth::user()->id)  
		   ->where('pts','!=',0)
		   ->orderBy('pts_total', 'desc')
		   ->groupBy('id_team')
		   ->get();
		   */
		
		
		//MAIN LOOP FOR USERS'S TEAMS WITH POINTS
		
		DB::statement(DB::raw('set @row=0'));
				$teams_ranking = DB::select("
				
						SELECT *, @row := @row + 1 as ranking  FROM (SELECT  						 
				
						p.id,
						p.id_user,
						p.id_team,					 
						t.title as team_title, 
						t.id as team_id, 
						u.company as team_company,
						u.private_challenge, 
                        IFNULL(sum(p.pts) , 0) AS pts_total
                        FROM participants 
                        AS p  
                     
						JOIN (SELECT id, id_user, title FROM teams ) 
                        AS t ON p.id_team = t.id 
                                                  
                        JOIN  (SELECT id, company, private_challenge FROM users)
                        AS u ON p.id_user = u.id 
                        
                   		WHERE (p.pts !=-1   			
            			AND u.id = '".$current_user_id."')		
            			
            			GROUP BY id_team
            			ORDER BY pts_total DESC, t.title ASC
      		
                   		) r ");
                   		
                   		
		
		
			
			//MY MY MY MY MY MY  
			//MY MY MY MY MY MY 
		
			$initial_start_date_formatted = strtotime($initial_start_date);
			$initial_start_date_formatted = date('d/m/Y',$initial_start_date_formatted);
			
			$end_date_formatted = strtotime($end_date);
			$end_date_formatted = date('d/m/Y',$end_date_formatted);
			
			//PRIVATE CHALLENGE
			$private_challenge="";
			if($current_user_private_challenge==1){
			
				if(Lang::getLocale() =="fr"){
					$private_challenge ="Challenge privé";
				}else{
					$private_challenge ="Private Challenge ";
				}
				
				$company_rank ="";
				
				//use default 1,2,3 for private challenge ordered by points 
				//must be empty array for blade tmplate to use 1,2,3 rankings !!!!
				$team_rank =Array();
				
				//var_dump(Route::getCurrentRoute()->getPath());
			}
			
			
			
			//MY MY MY MY MY MY  
			//MY MY MY MY MY MY 
		
		
				return view('rankings.myrankings', [
					'private_challenge' => $private_challenge,
					'company_rank' => $company_rank,
					'team_rank' => $team_rank,
					'companies_ranking' => $companies_ranking,
					'teams_ranking' => $teams_ranking,
					'teams_ranking' => $teams_ranking,
					'initial_start_date' => $initial_start_date_formatted,
					'end_date' => $end_date_formatted,
					'current_date' => date('d/m/Y'),
				]);
			
			
			
			
	
	
			

		}

		
		
	
				

		
    }
    

    
    
    
    
    
    
    
    
    public function rankingsCX($CX="")
    {




		//********
		//********
		// MAIN SETTINGS
		//********

		//$initial_start_date = '2016-11-07';
		
		$CX = strtoupper($CX);
		
		
		

		
		
		if($CX=="C1"){
			$initial_start_date 	= '2016-11-07';
			$end_date 				= '2016-12-31';
		}
		
		if($CX=="C2"){
			$initial_start_date 	= '2017-01-01';
			$end_date 				= '2017-03-31';
		}

		
		if($CX=="C3"){
			$initial_start_date 	= '2017-04-01';
			$end_date 				= '2017-06-30';
		}

		
		if($CX=="C4"){
			$initial_start_date 	= '2017-07-01';
			$end_date 				= '2017-12-31';
		} 
		
		
		 
		 
		 
	  	
		//********
		$maxresultsCompanies = 200;
		$maxresultsTeams = 400;
		//********
		//********	
		
		
	
		

		$participants = Array();
		
		$companies_ranking = Array();
		$teams_ranking = Array();
		

		
		//$participants = DB::table('participants')->where('access_token','!=', '')->orderBy('last_name', 'ASC')->orderBy('first_name', 'ASC')->get();


		//GET ALL PARTICIPANTS WHO HAVE TOKEN AND NOT IN PRIVATE MODE
		
		//->where('users.private_challenge','=',0)
		
		$participants = DB::table('participants_'.$CX)
		   ->join('users_'.$CX, 'participants_'.$CX.'.id_user', '=', 'users_'.$CX.'.id')	
		   ->selectRaw('participants_'.$CX.'.pts_updated, participants_'.$CX.'.access_token, participants_'.$CX.'.refresh_token, participants_'.$CX.'.id_team ,participants_'.$CX.'.id_user, participants_'.$CX.'.id as participant_id') 	   		   
		   ->where('participants_'.$CX.'.access_token','!=', '')
		   ->orderBy('participants_'.$CX.'.last_name', 'ASC')
		   ->orderBy('participants_'.$CX.'.first_name', 'ASC')
		   ->get();
		   
	



	

		
		if (count($participants)) {
		
			
			//********
			//********
			// NOTES 
			// IF MOVES PROFILE IS NULL MAIN LOOP SKIPS TO NEXT PARTICIPANT
			// PTS IS READ FROM MOVES EVERY 24 HRS
			
			foreach ($participants as $participant){	
				
			
				$teams = DB::table('teams_'.$CX)->where('id',($participant->id_team))->first();
				$participant->team = $teams->title;
				
				$users = DB::table('users_'.$CX)->where('id',($participant->id_user))->first();
				$participant->company = $users->company;
				

	
													
			}//END MAIN PARTICIPANT LOOP
			
		
			
			//var_dump($companies_ranking);
			
			
		}//END IF THERE ARE PARTICIPANTS
		



		//GET ALL COMPANIES AND TEAMS
	




		////////////////////
		////////////////////
		////////////////////
		////////////////////
		//MAIN LOOP FOR ALL COMPANIES
		

	
			DB::statement(DB::raw('set @row=0'));
			$companies_ranking = DB::select("
				
						SELECT *, @row := @row + 1 as ranking  FROM (SELECT  						 			
						p.id,
						p.id_user,
						u.company as company_title,
						u.id as company_id,
                        IFNULL(sum(p.pts) , 0) AS pts_total
                        FROM participants_".$CX." 
                        AS p                     
                                                  
                        JOIN  (SELECT id, company, private_challenge FROM users_".$CX.")
                        AS u ON p.id_user = u.id 
                        
                   		WHERE (p.pts !=-1   			
            			AND u.private_challenge =0)		
            			
            			GROUP BY id_user
            			ORDER BY pts_total DESC, p.id DESC
            			
            			LIMIT ".$maxresultsCompanies." 
      		
                   		) r ");  
                   			
	
		
		
		//INCORRECT RANKING !!!
		
		//MAIN LOOP FOR ALL TEAMS

		

		////////////////////
		////////////////////
		////////////////////
		////////////////////
		//MAIN LOOP FOR ALL TEAMS
		
		
		
		
		// WOW DID IT MANAGED TO GET #RANKING CORRECT !!!!!!!!!!!!!!!!!!!
		// lsm 5/15/16
		
		
		// lsm 4/7/17
		// do not show teams with 0 points
		//WHERE (p.pts !=-1
		//WHERE (p.pts >0
		
		DB::statement(DB::raw('set @row=0'));
		$teams_ranking = DB::select("
				
						SELECT *, @row := @row + 1 as ranking  FROM (SELECT  						 
				
						p.id,
						p.id_user,
						p.id_team,					 
						t.title as team_title,
						t.id as team_id,  
						u.company as team_company,
						u.private_challenge, 
                        IFNULL(sum(p.pts) , 0) AS pts_total
                        FROM participants_".$CX." 
                        AS p
                        
                     
						JOIN (SELECT id, id_user, title FROM teams_".$CX." ) 
                        AS t ON p.id_team = t.id 
                                                  
                        JOIN  (SELECT id, company, private_challenge FROM users_".$CX.")
                        AS u ON p.id_user = u.id 
                        
                   		WHERE (p.pts >0   			
            			AND u.private_challenge = 0)		
            			
            			GROUP BY id_team
            			ORDER BY pts_total DESC, p.id DESC
            			
            			LIMIT ".$maxresultsTeams." 
      		
                   		) r ");  

		
		

	
		
			$initial_start_date_formatted = strtotime($initial_start_date);
			$initial_start_date_formatted = date('d/m/Y',$initial_start_date_formatted);
			
			$end_date_formatted = strtotime($end_date);
			$end_date_formatted = date('d/m/Y',$end_date_formatted);
			
	
				return view('rankings.rankingsCX', [
					'companies_ranking' => $companies_ranking,
					'teams_ranking' => $teams_ranking,
					'initial_start_date' => $initial_start_date_formatted,
					'end_date' => $end_date_formatted,
					'CX' => 'CX',
					'current_date' => date('d/m/Y'),
				]);
			
	
			

		
    }
    
    
    
   // public static function sortByPtsDesc($a, $b) {
		//if($a->pts == $b->pts){ return 0 ; }
		//return ($a->pts > $b->pts) ? -1 : 1;
	//}
     




	
	
}








