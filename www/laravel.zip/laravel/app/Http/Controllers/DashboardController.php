<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;




class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
    
  

   
    	//login required    
       	//$this->middleware('auth');
       	
       	//required activate email account
        //$this->middleware('activated');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        return view('dashboard.index');
    }
 
 


	
	
}
