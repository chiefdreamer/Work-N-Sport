<?php

namespace App\Http\Controllers;



use App\Http\Requests;
use Illuminate\Http\Request;


use Validator;
use Auth;

use Mail;


use App\Models\User;


use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;





use Illuminate\Contracts\Auth\Guard;






class ActivateController extends Controller {


public function __construct()
{


 	$this->middleware('auth');
	$this->middleware('activated');
			
        	
}

   
   
   
   
   
    
   
    
    public function checkToken($token)
    {
    
  
    
    
        if( ! $token)
        {
            //throw new InvalidConfirmationCodeException;
           // $request->session()->flash('status', 'Invalid Confirmation Code.');

           	return view('activate.index', [
				'message' => 'Ce code n’est plus valide, ou vous n’êtes pas connecté.',
			]);

        }

        //$user = User::whereConfirmationCode($token)->first();       
        $user = User::where('confirmation_code','=',$token)->first();

      

        if ( ! $user)
        {
            //throw new InvalidConfirmationCodeException;
           //$request->session()->flash('status', 'Invalid Confirmation Code.');
 
			return view('activate.index', [
				'message' => '<p>Ce code n’est plus valide, ou vous n’êtes pas connecté.</p>',
			]);
			
			//Confirmation code no longer valid.
        }

		if($user){
        $user->confirmed = 1;
        $user->confirmation_code = null;
        $user->save();
        }


       
        
        return view('activate.index', [
			'message' => '<p>Vous avez vérifié votre adresse email avec succès.</p><p><a href="http://www.workn-sport.com/account">Login / Mon Compte</a></p>',
		]);

    
        //return redirect('/activate');
    }
    
    
    
    
    
    
    /**
     * Show the  page.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
 
 
 
 			//copied from Middleware/UserConfirmed
 			//resends activation code at each page load
 			
 			
            //$user = $this->auth->getUser();
            $user = Auth::user();  
            $confirmed = $user->confirmed;
            
 
			//DEACTIVATED
			// lsm 8/2/16
			//if (isset($confirmed) && $confirmed == "0")
            if (isset($confirmed) && $confirmed == "999")
            {
                // If the user has not had an activation token set
                $confirmation_code = $user->confirmation_code;

                //if (empty($confirmation_code))
                //{
                    // generate a confirmation code
                    $key = \Config::get('app.key');
                    $confirmation_code = hash_hmac('sha256', str_random(40), $key);
                    $user->confirmation_code = $confirmation_code;
                    $user->save();
                    \Mail::send('emails.activate', ['token' => $confirmation_code, 'first_name' => $user->first_name], function($message) use ($user){
                        $message->to($user->getEmailForPasswordReset(), $user->first_name)
                                ->subject('Activer votre compte');
                    });
                    
                    
               // }
                //return redirect()->guest('/activate');
            }
            
            
            
                
        
		//Please check your email for activation link.
        return view('activate.index', [
			'message' => '<p>Merci de vérifier votre email pour le lien d’activation</p>',
		]);
		
    }
    
    

    
    
}
