<?php

namespace App\Http\Controllers;


use App\Http\Requests;
use Illuminate\Http\Request;


use Mail;


class ContactController extends Controller
{



    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //login required    
       	//$this->middleware('auth');
       	
       	//required activate email account
        //$this->middleware('activated');
    }

    /**
     * Show the moves page.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        return view('contact.index');
    }
 
 
    public function send(Request $request)
    {

		
	    $this->validate($request, [
             'company' => 'required|min:2|max:255',
            'first_name' => 'required|max:255',
            'last_name' => 'required|max:255',
            'email' => 'required|email|max:255',
    	]);
    	

		
		$from_email = $request['email'];
		$from_name = $request['first_name']." ". $request['last_name'];
		
       	Mail::send('emails.contact', 
       	['company' => $request['company'],     	
       	'first_name' => $request['first_name'], 
       	'last_name' => $request['last_name'], 
       	'email' => $request['email'], 
       	'position' => $request['position'], 
       	'telephone' => $request['telephone'], 
       	'email_message' => $request['email_message']],
       	function ($m) use ($request){
            $m->from($request['email'],$request['first_name']." ".$request['last_name']);
            $m->to('info@workn-sport.com', 'Work-n-Sport')->subject('Work-n-Sport | Contact');
        });

		//return Redirect::route('contact')->with('message', 'Thanks for contacting us!');
		return view('contact.index')->with('message','Merci pour votre message, à bientôt sur Work-n-Sport.');


  
        
        
    }



	
	
}
