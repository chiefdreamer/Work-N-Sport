<?php

namespace App\Http\Controllers;


use App\Http\Requests;
use Illuminate\Http\Request;



use DB;

use Auth;

class SubscribeController extends Controller
{



    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //login required    
       	//$this->middleware('auth');
       	
       	//required activate email account
        //$this->middleware('activated');
    }

    /**
     * Show the moves page.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

//personal details are available only if logged in
if(isset(Auth::user()->id)){
	$user = DB::table('users')->where('users.id',Auth::user()->id)->first();
	


			$cg_cities_unserialized = unserialize($user->cg_cities);	
			$js_array = json_encode($cg_cities_unserialized);


	
			//'1'  = 'Annecy-le-Vieux'
			//'2'  = 'Marseille'
			//'3'  = 'Puteaux'

			
			
		   
				return view('subscribe.index', [
					'vads_cust_id' => Auth::user()->id,
					'vads_cust_email' => $user->email,
					'vads_cust_first_name' => $user->first_name,
					'vads_cust_last_name' => $user->last_name,
					'vads_cust_phone' => $user->phone,
					'vads_cust_legal_name' => $user->company,
					'vads_cust_address' => $user->address,
					'vads_cust_city' => $user->city,
					'vads_cust_zip' => $user->postcode,
					'vads_cust_country' => $user->country,
					'vads_cg_cities' => $js_array,
					'vads_nb_products' => $request->vads_nb_products,
					'vads_order_info' => $request->vads_order_info,
					'vads_order_info2' => $request->vads_order_info2,
				]);
//page redirects to login if user tries to access payment gateway 
}else{
				return view('subscribe.index', [
					'vads_cust_id' => '',
					'vads_cust_email' => '',
					'vads_cust_first_name' => '',
					'vads_cust_last_name' => '',
					'vads_cust_phone' => '',
					'vads_cust_legal_name' => '',
					'vads_cust_address' => '',
					'vads_cust_city' => '',
					'vads_cg_cities' => '',
					'vads_cust_zip' => '',
					'vads_cust_country' => '',
					'vads_nb_products' => '',
					'vads_order_info' => '',
					'vads_order_info2' => '',
				]);
}

    }
 
 


	
	
}
