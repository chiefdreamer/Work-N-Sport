<?php

namespace App\Http\Controllers;



use App\Http\Requests;
use Illuminate\Http\Request;


use Validator;
use Auth;
use App\Models\User;

use DB;



class AccountController extends Controller
{




    public function __construct()
    {

        
    }





  public function index(Request $request)
	{
	
	}

 
  public function process(Request $request)
	{


    
		//add custom field
		//$request->merge(array('id_user' => Auth::user()->id));
		
	
		
		$id_user = Auth::user()->id;

	
		
		//Create new invoice
		
		$company = trim($request->company);
		$first_name = trim($request->first_name);
		$last_name = trim($request->last_name);
		$email = trim($request->email);
		$amount = trim($request->amount);
		
		
		$row = DB::table('participants')->insert(
    		['id_user' => $id_user, 'first_name' => $first_name, 'last_name' => $last_name, 'email' => $email, 'created_at' => date('Y-m-d H:i:s')]
		);
		

				

	}


	
	
}
