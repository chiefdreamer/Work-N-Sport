<?php


namespace App\Http\Controllers\Auth;


use Mail;

use Config;


use App\Models\User;
use Validator;
use App\Http\Controllers\Controller;


use Illuminate\Contracts\Auth\Guard;

use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;



use Auth;


//use Route;


use Illuminate\Support\Facades\Input;


use Illuminate\Http\Request;

class AuthController extends Controller
{



    
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;
   




		
		

    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */
     
  // lsm 5/18/16
  
	
		protected $redirectTo = '/account';
		protected $redirectAfterLogout = '/login';




			
   


    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct(Request $request)
    {



    $this->middleware('guest', ['except' => 'logout']);





	//$app = Route::current()->getParameter('app');
	
	
	
	//if(  Input::get('app')=='1'  ){
	//if( $app=='1' ){
	if($request->app=='1'){
		$this->redirectAfterLogout = '/login?app=1';
	}else{
		$this->redirectAfterLogout = '/login';
	}
	
	
	//THIS WAS NOT GETTING SET !!
	
	//THIS FIXED IT !!!!!!!!!!!!!!
	// added to login and account blade template pages
	//<form class="form-horizontal" role="form" method="POST" action="{{ url('/login?app=')}}{{ app('request')->input('app') }}"> 
	

	//if( Input::get('app')=='1' ){
	//if( $app=='1' ){
	if($request->app=='1'){
		$this->redirectTo = '/account?app=1';
	}else{
		$this->redirectTo = '/account';
	}

	
	
	
	
	



  
    }



  






    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
    
    

        
    
        return Validator::make($data, [
            'company' => 'required|min:2|max:255',
            'first_name' => 'required|max:255',
            'last_name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|confirmed|min:6',
        ]);
    
        
  
    }







    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
    
    	//send email to dg new registration (NOT YET CONFIRMED)
    	
       	Mail::send('emails.notify', ['email' => $data['email'], 'first_name' => $data['first_name'], 'last_name' => $data['last_name']], function ($m) use ($data){
            $m->from('info@workn-sport.com', 'workn-sport');
            $m->to('emmanuel@livevent.fr', 'Emmanuel Piegay')->subject('ADMIN: New registration at Work’n Sport');
            $m->to('liquidskyweb@gmail.com', 'David Giorgi')->subject('ADMIN: New registration at Work’n Sport');
            //$m->to('davide.giorgi@orange.fr', 'DG2')->subject('New registration at Work’n Sport   TEST');
            
        });
        

        
  
		// lsm 6/21/16
        if(!isset($data['non_commercial'])){
        	$data['non_commercial'] =0; 
        
        }          

		return User::create([
            'non_commercial' => $data['non_commercial'],
            'company' => $data['company'],
            'first_name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
        ]);
        
 

       
    }
    
    
    
    
   

    
    
    
}
