<?php

namespace App\Http\Controllers;


use App\Http\Requests;
use Illuminate\Http\Request;





class FaqController extends Controller
{



    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //login required    
       	//$this->middleware('auth');
       	
       	//required activate email account
        //$this->middleware('activated');
    }

    /**
     * Show the moves page.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        return view('faq.index');
    }
 
 


	
	
}
