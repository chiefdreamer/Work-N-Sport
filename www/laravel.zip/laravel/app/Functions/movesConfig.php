<?php

//Set client_id provided when you registered your Moves Apps
$client_id = "•••";
//Set client_secret provided when you registered your Moves Apps
$client_secret = "•••";

//Set your redirect url. For this demo it would be http://your-url/example/test.php  
//This is overridden by the url set for the App on the moves api interface
$redirect_url = "http://www.workn-sport.com/moves"; 


