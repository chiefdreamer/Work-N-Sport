<?php

return [
    'fr' => 'Français',
    'en' => 'English',
    
];