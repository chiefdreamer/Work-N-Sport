@extends($DEFAULT_VIEW)

@section('content')



<div class="container">


<div style="margin: 4px 0 4px 0; padding: 4px 0 4px 0; background-color:#660147; color:#ffffff; text-align:center; width:100%">
<b>{{ trans('wns.Non_lucratifs') }}</b>
</div>

    
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
    <li data-target="#carousel-example-generic" data-slide-to="3"></li>
    <li data-target="#carousel-example-generic" data-slide-to="4"></li>
    <li data-target="#carousel-example-generic" data-slide-to="5"></li>
    <li data-target="#carousel-example-generic" data-slide-to="6"></li>
    <li data-target="#carousel-example-generic" data-slide-to="7"></li>
  </ol>





  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
  
  @if (App::getLocale() =='fr') 
  
    <div class="item active">
      <img src="images/slide_1.jpg">
      <div class="carousel-caption">
      </div>
    </div>
    
    <div class="item">
      <img src="images/slide_2.jpg">
      <div class="carousel-caption">
      </div>
    </div>
    
    <div class="item">
       <img src="images/slide_3.jpg">
      <div class="carousel-caption">
      </div>
    </div>
    
    <div class="item">
       <img src="images/slide_4a.jpg">
      <div class="carousel-caption">
      </div>
    </div>
    
    <div class="item">
       <img src="images/slide_5.jpg">
      <div class="carousel-caption">
      </div>
    </div>
    
    <div class="item">
       <img src="images/slide_6.jpg">
      <div class="carousel-caption">
      </div>
    </div>
    
    <div class="item">
       <img src="images/slide_7.jpg">
      <div class="carousel-caption">
      </div>
    </div>
    
    <div class="item">
       <img src="images/slide_8.jpg">
      <div class="carousel-caption">
      </div>
    </div>
    
    @elseif (App::getLocale() =='en') 
   
   
     <div class="item active">
      <img src="images/slide_1_en.jpg">
      <div class="carousel-caption">
      </div>
    </div>
    
    <div class="item">
      <img src="images/slide_2_en.jpg">
      <div class="carousel-caption">
      </div>
    </div>
    
    <div class="item">
       <img src="images/slide_3_en.jpg">
      <div class="carousel-caption">
      </div>
    </div>
    
    <div class="item">
       <img src="images/slide_4a_en.jpg">
      <div class="carousel-caption">
      </div>
    </div>
    
    <div class="item">
       <img src="images/slide_5_en.jpg">
      <div class="carousel-caption">
      </div>
    </div>
    
    <div class="item">
       <img src="images/slide_6_en.jpg">
      <div class="carousel-caption">
      </div>
    </div>
    
    <div class="item">
       <img src="images/slide_7_en.jpg">
      <div class="carousel-caption">
      </div>
    </div>
    
    <div class="item">
       <img src="images/slide_8_en.jpg">
      <div class="carousel-caption">
      </div>
    </div>
     
    @endif 
    
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


    <div class="row">

         
          
          
            <div id="front_page" style="color: #ffffff; font-size: 16px;">   
			 
			@if (App::getLocale() =='fr') 
			<img src="/images/strip_under_carousel.jpg">
			@elseif (App::getLocale() =='en') 
			<img src="/images/strip_under_carousel_en.jpg">
			@endif	
	 
			</div>
	

    	
  
  </div>
          
          
        
          
         <!-- 
        <div class="col-md-10 col-md-offset-1">
  
        
            <div class="panel panel-default">
                <div class="panel-heading">Welcome</div>

                <div class="panel-body">
                    Your Application's Landing Page.
                </div>
            </div>
            
        </div>
        -->
        
    </div>
    

</div>
 
    
@endsection
