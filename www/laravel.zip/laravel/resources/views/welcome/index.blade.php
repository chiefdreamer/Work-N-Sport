@extends($DEFAULT_VIEW)

@section('content')



<div class="container" margin>


<!--
<div style="margin: 4px 0 4px 0; padding: 4px 0 4px 0; background-color:#660147; color:#ffffff; text-align:center; width:100%">
<b>{{ trans('wns.Non_lucratifs') }}</b>
</div>
-->






		<div class="row">
			
			<div id="front_page" style="color: #ffffff; font-size: 16px;"> 
			
			@if (App::getLocale() =='fr') 
			<img style="padding-top:0px;" src="images/wns_vertical_strip.jpg">
			@elseif (App::getLocale() =='en') 
			<img style="padding-top:0px;" src="images/wns_vertical_strip_en.jpg">
			@endif 

			</div>
			
		</div>






		<div class="row">


			<div id="front_page" style="color: #ffffff; font-size: 16px;">   

			@if (App::getLocale() =='fr') 
			<!--<img src="/images/strip_under_carousel.jpg">-->
			@elseif (App::getLocale() =='en') 
			<!--<img src="/images/strip_under_carousel_en.jpg">-->
			@endif	

			</div>

		</div>


          
        
          
         <!-- 
        <div class="col-md-10 col-md-offset-1">
  
        
            <div class="panel panel-default">
                <div class="panel-heading">Welcome</div>

                <div class="panel-body">
                    Your Application's Landing Page.
                </div>
            </div>
            
        </div>
        -->
        
    </div>
    

</div>
 
    
@endsection
