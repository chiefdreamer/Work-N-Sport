<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <h2><b>Work’n Sport | Move More, Play More!</b></h2>

        <div>
        

		
<p>Nous vous remercions pour votre inscription sur le site Work’n Sport. Votre facture est disponible sur le site : <a href='http://www.workn-sport.com/account/invoices'>www.workn-sport.com</a></p>


        </div>

    </body>
</html>



