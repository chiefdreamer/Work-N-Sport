<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title></title>
	
	<style>
	body{
	font-family: arial;
	}
	</style>
</head>
<body>
<table style="width:600px;" cellpadding="10">



<!-- FRENCH -->


<tr>
<td valign="top" colspan="2"><div><a href="http://www.workn-sport.com/"><img style="max-width:600px;" src="http://www.workn-sport.com/images/email_banner.png" border="0"></a></div></td>
</tr>

<tr>
<td valign="top" colspan="2">
<div style="font-weight: bold; font-size:26px; color: #5e0034;">Bonjour et bravo <?php echo  $first_name ?> 
</div>
</td>
</tr>


<tr>
<td valign="top">

<div style="font-weight: bold; font-size:21px; line-height:125%; color: #5e0034;">Move More,<br />
Play More avec<br />
Work’N Sport.</div>

<div style="font-size:14px; width:264px;">Work’n Sport est le 1er challenge connecté multi-sports et solidaire, intra ou inter-entreprises, en soutien à Handicap International.<br />
Les équipes sont constituées de 1 à 3 personnes qui peuvent pratiquer plus de 40 sports.<br />
<b style="color: #5e0034;">La règle est simple :</b> 1 minute de sport ou d’activité physique = 1 point!
<br /><br/>


<p style="color: #5e0034; font-weight: bold; font-size:21px; font-style: italic">
Le classement mondial de votre société <?php echo  $company ?> est :  <?php echo  $company_rank ?>; <span style="font-weight: bold; font-size:16px; font-style: italic"> avec <?php echo  $company_points ?> points</span>
<span style="color: #5e0034; font-weight: bold; font-size:16px; font-style: italic"><?php echo  $company_higher ?></span>
</p>

<p style="color: #5e0034; font-weight: bold; font-size:18px; font-style: italic">
Le classement mondial de votre équipe <?php echo  $team_title ?> est :  <?php echo  $team_rank ?>; <span style="font-weight: bold; font-size:16px; font-style: italic"> avec <?php echo  $team_points ?> points</span>
<span style="color: #5e0034; font-weight: bold; font-size:14px; font-style: italic"><?php echo  $team_higher ?></span>
</p>

<p>
<a href="http://workn-sport.com/rankings/">Retrouvez le classement intégral des sociétés et des équipes de Work’N Sport en cliquant ici.</a>
</p>


<p>
Publiez les photos de vos entrainements sur notre page Facebook: <a href="https://www.facebook.com/worknsport/?fref=ts">www.facebook.com/worknsport/?fref=ts</a> et partagez les avec #worknsport<br /><br />

Si vous avez besoin de reconnecter vos applications Moves et Work’N Sport, cliquez ici et renseignez votre email pour recevoir un nouveau code d’activation : <a href="http://www.workn-sport.com/moves/email">www.workn-sport.com/moves/email</a><br /><br />

Retrouvez toutes les réponses aux questions fréquentes en cliquant ici : <a href="http://www.workn-sport.com/faq">www.workn-sport.com/faq</a>
</p>



</div>


</td>


<td valign="top">
<div style="text-align:center;">
<a href="https://www.youtube.com/watch?v=m__IIf2V2MI&amp;feature=youtu.be"><img style="max-width:260px;" src="http://www.workn-sport.com/images/email_video.png" border="0"></a><br />
<div style="font-size:14px;">5% du CA reversé à</div>
<img style="max-width:600px;" src="http://www.workn-sport.com/images/email_handicap.png">
</div>

<div style="width:145px; margin: 30px auto 0 auto ;"><img style="max-width:145px;" src="http://www.workn-sport.com/images/email_movemore.png" /></div>


</td>


</tr>




<tr>
<td valign="top" colspan="2">
<div style="text-align:center;">

<div style="display:inline-block; margin:10px;">
<a href="https://twitter.com/worknsport/">
<img style="max-width:24px;" src="http://www.workn-sport.com/images/email_twitter.png" border="0"></a>
</div>

<div style="display:inline-block; margin:10px;">
<a href="https://www.facebook.com/WorkN-Sport-951584984895304/">
<img style="max-width:24px;" src="http://www.workn-sport.com/images/email_facebook.png" border="0"></a>
</div>

<div style="display:inline-block; margin:10px;">
<a href="https://www.linkedin.com/groups/8527807">
<img style="max-width:24px;" src="http://www.workn-sport.com/images/email_linkedin.png" border="0"></a>
</div>

<div style="font-size:12px; font-style:italic; color: #656565;">
Copyright © www.workn-sport.com, All rights reserved.<br />
Si vous ne voulez plus recevoir les emails hebdomadaire, <a href="http://www.workn-sport.com/account">allez sur votre compte en ligne</a> pour vous désinscrire.
</div>

</div>
</td>
</tr>



<tr>
<td valign="top" colspan="2">&nbsp;</td>
</tr>
 


<!-- ENGLISH -->




<tr>
<td valign="top" colspan="2"><div><a href="http://www.workn-sport.com/"><img style="max-width:600px;" src="http://www.workn-sport.com/images/email_banner.png" border="0"></a></div></td>
</tr>

<tr>
<td valign="top" colspan="2">
<div style="font-weight: bold; font-size:26px; color: #5e0034;">Hello and congratulations <?php echo  $first_name ?> 
</div>
</td>
</tr>


<tr>
<td valign="top">

<div style="font-weight: bold; font-size:21px; line-height:125%; color: #5e0034;">Move More,<br />
Play More with<br />
Work’N Sport.</div>

<div style="font-size:14px; width:264px;">Work’n Sport is the 1st corporate connected multisports challenge and inclusive, intra ou inter-company, in support of Handicap International.<br />
The teams are composed of 1 to 3 people who can partake in more than 40 sports.<br />
<b style="color: #5e0034;">The rule is simple :</b> 1 minute of sport or physical activity = 1 point!
<br /><br/>


<p style="color: #5e0034; font-weight: bold; font-size:21px; font-style: italic">The world ranking of your company <?php echo  $company ?> is :  <?php echo  $company_rank ?>; <span style="font-weight: bold; font-size:16px; font-style: italic"> with <?php echo  $company_points ?> points</span>
<span style="color: #5e0034; font-weight: bold; font-size:16px; font-style: italic"><?php echo  $company_higher_en ?></span>
</p>

<p style="color: #5e0034; font-weight: bold; font-size:18px; font-style: italic">
The world ranking of your team <?php echo  $team_title ?> :  <?php echo  $team_rank ?>; <span style="font-weight: bold; font-size:16px; font-style: italic"> with <?php echo  $team_points ?> points</span>
<span style="color: #5e0034; font-weight: bold; font-size:14px; font-style: italic"><?php echo $team_higher ?></span>
</p>

<p>
<a href="http://workn-sport.com/rankings/">Click here to follow the full Work’N Sport company and team rankings.</a>
</p>


<p>
Upload your training pictures to our Facebook page: <a href="https://www.facebook.com/worknsport/?fref=ts">www.facebook.com/worknsport/?fref=ts</a> and share them with #worknsport<br /><br />

If you need to reconnect your Work’N Sport apps, click here and enter your email to receive a new activation code: <a href="http://www.workn-sport.com/moves/email">www.workn-sport.com/moves/email</a><br /><br />

Click here to find all the answers to the frequently asked questions: <a href="http://www.workn-sport.com/faq">www.workn-sport.com/faq</a>
</p>


</div>


</td>


<td valign="top">
<div style="text-align:center;">
<a href="https://www.youtube.com/watch?v=m__IIf2V2MI&amp;feature=youtu.be"><img style="max-width:260px;" src="http://www.workn-sport.com/images/email_video.png" border="0"></a><br />
<div style="font-size:14px;">5% of the turnover is donated to</div>
<img style="max-width:600px;" src="http://www.workn-sport.com/images/email_handicap.png">
</div>

<div style="width:145px; margin: 30px auto 0 auto ;"><img style="max-width:145px;" src="http://www.workn-sport.com/images/email_movemore.png" /></div>


</td>


</tr>




<tr>
<td valign="top" colspan="2">
<div style="text-align:center;">

<div style="display:inline-block; margin:10px;">
<a href="https://twitter.com/worknsport/">
<img style="max-width:24px;" src="http://www.workn-sport.com/images/email_twitter.png" border="0"></a>
</div>

<div style="display:inline-block; margin:10px;">
<a href="https://www.facebook.com/WorkN-Sport-951584984895304/">
<img style="max-width:24px;" src="http://www.workn-sport.com/images/email_facebook.png" border="0"></a>
</div>

<div style="display:inline-block; margin:10px;">
<a href="https://www.linkedin.com/groups/8527807">
<img style="max-width:24px;" src="http://www.workn-sport.com/images/email_linkedin.png" border="0"></a>
</div>

<div style="font-size:12px; font-style:italic; color: #656565;">
Copyright © www.workn-sport.com, All rights reserved.<br />
If you no longer wish to receive the weekly emails, <a href="http://www.workn-sport.com/account">login to you account</a> to unsubscribe.
</div>

</div>
</td>
</tr>





</table>

</body>
</html>
