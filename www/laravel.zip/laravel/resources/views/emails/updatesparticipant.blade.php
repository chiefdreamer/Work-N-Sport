<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title></title>
	
	<style>
	body, td{
	border:0;
	margin:0;
	padding: 0;
	font-size: 12px;
	line-height: 1.5;
	font-family: arial;
	} 
	
	table {
	  border-collapse: collapse;
	}
	</style>
</head>
<body>


<!-- FRENCH NEW-->

<table style="width:600px; background-color: #5b0032" align ="left">


<tr><td style="background-color: #5b0032"><a href="http://www.workn-sport.com/"><img style="max-width:600px;" src="http://www.workn-sport.com/images/email2_header_top.png" border="0"></a></td></tr>


<tr><td valign="middle" style="height:65px;background-color: #5b0032; color: #ffffff; font-size:18px; text-align: center; font-weight: bold;">VOTRE CLASSEMENT HEBDOMADAIRE !</td></tr>


<tr><td style="background-color: #5b0032"><a href="http://www.workn-sport.com/"><img style="max-width:600px;" src="http://www.workn-sport.com/images/email2_header_bottom.png" border="0"></a></td></tr>


<tr><td style="height:75px; background-color: #5b0032; color: #ffffff;" valign="middle">
<table style="width:600px; background-color: #5b0032;">
<tr><td width="60%" valign="middle" style="padding: 10px 20px 10px 20px;"><span style="font-size:14px; color:#ffffff;">Le classement mondial de la société</span><br><b><span style="font-size:16px; color:#ffffff;"><?php echo  $company ?></span></b></td>
<td  width="20%" valign="middle" style="padding: 10px 20px 10px 20px; border-left: 1px solid #ffffff; font-size:16px;"><b><?php echo  $company_rank ?></b></td>
<td valign="middle" style="padding: 10px 20px 10px 20px; border-left: 1px solid #ffffff;"><nobr><i><?php echo  $company_points ?> pts</i></nobr></td></tr>
</table>
</td></tr>


<tr><td style="border-top: 1px solid #ffffff;"></td></tr>


<tr><td style="height:75px; background-color: #5b0032; color: #ffffff;" valign="middle">
<table style="width:600px; background-color: #5b0032;">
<tr><td width="60%" valign="middle" style="padding:10px 20px 10px 20px;"><span style="font-size:14px; color:#ffffff;" >Le classement mondial de l’équipe</span><br><b><span style="font-size:16px; color:#ffffff;"><?php echo  $team_title ?></span></b></td>
<td width="20%" valign="middle" style="padding: 10px 20px 10px 20px; border-left: 1px solid #ffffff; font-size:16px;"><b><?php echo  $team_rank ?></b></td>
<td valign="middle" style="padding: 10px 20px 10px 20px; border-left: 1px solid #ffffff;"><nobr><i><?php echo  $team_points ?> pts</i></nobr></td></tr>
</table>
</td></tr>



<tr>
<td>

<table style="width:600px; background-color: #ffffff;">


<tr>
<td rowspan="3" width="24%" valign="middle" style="padding: 20px; background-color:#3ab54a; color:#ffffff;font-size:11px; font-weight: bold;">VOUS ÊTES JUSTE<br>DERRIÈRE EUX !</td>
<td width="38%" valign="middle" style="padding: 5px; text-align: center; font-size:14px; color:#5b0032;"><b>SOCIÉTÉ</b></td>
<td width="38%" valign="middle" style="padding: 5px; text-align: center; font-size:14px; color:#5b0032;"><b>ÉQUIPE</b></td>
</tr>


<tr>
<td colspan="2" valign="middle" style="border-top: 1px solid #000000;"></td>
</tr>



<tr>
<td width="38%" valign="middle" style="padding: 0px; text-align: center; font-size:12px; color:#000000;"><b><?php echo  $company_higher ?></td>
<td width="38%" valign="middle" style="padding: 5px; text-align: center; font-size:12px; color:#000000;"><div style="border-left: 1px solid #000000; height: 100%"><b><?php echo  $team_higher ?></div></td>
</tr>


</table>

</td>
</tr>


<tr><td style="padding: 20px; background-color: #ffffff; font-size:10px; color: #000000;"><i>Retrouvez le classement intégral des sociétés et des équipes de Work’N Sport en <a href="http://www.workn-sport.com/rankings/" style="color:#5b0032;">cliquant ici</a>.</i></td></tr>




<tr><td style="text-align:center;"><div style="padding: 0px 20px 0px 20px; width: 560px; background-color: #ffffff;"><div style="width: 560px; height: 1px; border-top: 1px solid #5b0032"></div></div></td></tr>

<tr> 
<td style="background-color: #ffffff; text-align:center;">
<table style="width:590px; background-color: #ffffff; color:#000000;" align ="center" border="0">
<tr>
<td width="50%" valign="middle" style="padding: 15px; font-size:12px; text-align:left;">
<a href="http://www.workn-sport.com/faq/"><img style="padding: 8px; width:223px; border-bottom: 1px solid #5b0032;" src="http://www.workn-sport.com/images/email2_move_more.png" border="0"></a><br>

<p><b>WORK’N SPORT</b> est le 1er challenge
connecté multi-sports et solidaire, intra
ou inter-entreprises, en soutien à
Handicap International.</p>

<p>Les équipes sont constituées de 1 à 3
personnes qui peuvent pratiquer plus
de 40 sports.</p>

</td>

<td width="50%" valign="middle" style="padding: 15px;">
<a href="http://www.workn-sport.com/faq/"><img style="width:250px;" src="http://www.workn-sport.com/images/email2_woman.png" border="0"></a>
</td>

</tr></table>

</td></tr>


<tr><td style="padding: 20px; background-color: #ffffff; font-size:14px; color: #000000; text-align: center;"><b style="color:#ff6c00">La règle est simple :</b> <b>1 minute</b> de sport ou d’activité physique = <b>1 point!</b></td></tr>


<tr><td style="text-align:center;"><div style="padding: 0px 20px 0px 20px; width: 560px; background-color: #ffffff;"><div style="width: 560px; height: 1px; border-top: 1px solid #5b0032"></div></div></td></tr>



<tr>
<td valign="top">

<table style="width:600px; background-color: #ffffff; color:#000000;">
<tr>
<td width="50%" valign="top" style="padding: 20px; font-size:12px">

<p>Si vous avez besoin de reconnecter vos
applications <b>MOVES</b> et <b>WORK’N SPORT,</b>
cliquez ici et renseignez votre email pour
recevoir un nouveau code d’activation :
<a href="http://www.workn-sport.com/moves/email" style="color:#5b0032"><b><i>www.workn-sport.com/moves/email</i></b></a></p>



</td>

<td width="50%" valign="middle" style="padding: 20px; font-size:12px; text-align: center;">

<p><b>Retrouvez toutes les réponses
aux questions fréquentes en cliquant ici :</b></p>

<a href="http://www.workn-sport.com/faq/" ><img style="width:95px;" src="http://www.workn-sport.com/images/email2_faq.png" border="0"></a>

</td>


</tr></table>

</td></tr>



<tr><td style="background-color: #5b0032"><img style="max-width:600px;" src="http://www.workn-sport.com/images/email2_footer_top.png" border="0"></td></tr>


<tr><td valign="top" style="height:110px; background-color: #5b0032; color: #ffffff; font-size:9px; text-align: center; font-weight: normal;">


<table style="width:600px; background-color: #5b0032;">
<tr>
<td width="20%" valign="top" s style="padding: 0px;"></td>

<td width="60%" valign="top" style="padding: 0px; text-align:center;">
<a href="https://www.facebook.com/WorkN-Sport-951584984895304/"><img style="margin: 0 4px 10px 4px; width:27px;" src="http://www.workn-sport.com/images/email2_f.png" border="0"></a>
<a href="https://twitter.com/worknsport/"><img style="margin: 0 4px 10px 4px; width:27px;" src="http://www.workn-sport.com/images/email2_t.png" border="0"></a>
<a href="https://www.linkedin.com/groups/8527807"><img style="margin: 0 4px 10px 4px; width:27px;" src="http://www.workn-sport.com/images/email2_l.png" border="0"></a>

<div style="margin: 4px 0 0 0; font-size:9px;"><b>Copyright © <a href="http://www.workn-sport.com/" style="color:#ffffff;">www.workn-sport.com</a>, All rights reserved.</b><br>
Si vous ne voulez plus recevoir les emails hebdomadaire, <a href="http://www.workn-sport.com/account" style="color:#ffffff;">allez sur votre compte en ligne</a> pour vous désinscrire.</div>

</td>

<td width="20%" valign="top" style="padding: 0px; background-color:#5b0032; color:#ffffff; font-size:8px">

<div style="margin: 30px 0 0 0;">5% du CA reversé à<br>
<img style="margin: 4px 0 0px 0; width:64px;" src="http://www.workn-sport.com/images/email2_handicap.png" border="0"><br>
<nobr><i><a href="http://www.handicap-international.fr" style="color:#ffffff;">www.handicap-international.fr</a></i></nobr><br></div>

</td>

</tr></table>


</td></tr>


</table>


<!-- END FRENCH NEW-->

<br>
<br>
<br>

<!-- ENGLISH NEW-->

<table style="width:600px; background-color: #5b0032" align ="left">


<tr><td style="background-color: #5b0032"><a href="http://www.workn-sport.com/"><img style="max-width:600px;" src="http://www.workn-sport.com/images/email2_header_top_en.png" border="0"></a></td></tr>


<tr><td valign="middle" style="height:65px;background-color: #5b0032; color: #ffffff; font-size:18px; text-align: center; font-weight: bold;">YOUR WEEKLY RANKING !</td></tr>


<tr><td style="background-color: #5b0032"><a href="http://www.workn-sport.com/"><img style="max-width:600px;" src="http://www.workn-sport.com/images/email2_header_bottom.png" border="0"></a></td></tr>


<tr><td style="height:75px; background-color: #5b0032; color: #ffffff;" valign="middle">
<table style="width:600px; background-color: #5b0032;">
<tr><td width="60%" valign="middle" style="padding: 10px 20px 10px 20px;"><span style="font-size:14px; color:#ffffff;">The world ranking of the company</span><br><b><span style="font-size:16px; color:#ffffff;"><?php echo  $company ?></span</b></td>
<td  width="20%" valign="middle" style="padding: 10px 20px 10px 20px; border-left: 1px solid #ffffff; font-size:16px;"><b><?php echo  $company_rank_en ?></b></td>
<td valign="middle" style="padding: 10px 20px 10px 20px; border-left: 1px solid #ffffff;"><nobr><i><?php echo  $company_points ?> pts</i></nobr></td></tr>
</table>
</td></tr>


<tr><td style="border-top: 1px solid #ffffff;"></td></tr>


<tr><td style="height:75px; background-color: #5b0032; color: #ffffff;" valign="middle">
<table style="width:600px; background-color: #5b0032;">
<tr><td width="60%" valign="middle" style="padding:10px 20px 10px 20px;"><span style="font-size:14px; color:#ffffff;" >The world ranking of the team</span><br><b><span style="font-size:16px; color:#ffffff;"><?php echo  $team_title ?></span></b></td>
<td width="20%" valign="middle" style="padding: 10px 20px 10px 20px; border-left: 1px solid #ffffff; font-size:16px;"><b><?php echo  $team_rank_en ?></b></td>
<td valign="middle" style="padding: 10px 20px 10px 20px; border-left: 1px solid #ffffff;"><nobr><i><?php echo  $team_points ?> pts</i></nobr></td></tr>
</table>
</td></tr>



<tr>
<td>

<table style="width:600px; background-color: #ffffff;">


<tr>
<td rowspan="3" width="24%" valign="middle" style="padding: 20px; background-color:#3ab54a; color:#ffffff;font-size:11px; font-weight: bold;">VOUS ARE RIGHT <br>BEHIND THEM !</td>
<td width="38%" valign="middle" style="padding: 5px; text-align: center; font-size:14px; color:#5b0032;"><b>COMPANY</b></td>
<td width="38%" valign="middle" style="padding: 5px; text-align: center; font-size:14px; color:#5b0032;"><b>TEAM</b></td>
</tr>


<tr>
<td colspan="2" valign="middle" style="border-top: 1px solid #000000;"></td>
</tr>



<tr>
<td width="38%" valign="middle" style="padding: 0px; text-align: center; font-size:12px; color:#000000;"><b><?php echo  $company_higher ?></td>
<td width="38%" valign="middle" style="padding: 5px; text-align: center; font-size:12px; color:#000000;"><div style="border-left: 1px solid #000000; height: 100%"><b><?php echo  $team_higher ?></div></td>
</tr>


</table>

</td>
</tr>


<tr><td style="padding: 20px; background-color: #ffffff; font-size:10px; color: #000000;"><i><a href="http://www.workn-sport.com/rankings/" style="color:#5b0032;">Click here</a> to follow the full Work’N Sport company and team rankings.</i></td></tr>




<tr><td style="text-align:center;"><div style="padding: 0px 20px 0px 20px; width: 560px; background-color: #ffffff;"><div style="width: 560px; height: 1px; border-top: 1px solid #5b0032"></div></div></td></tr>

<tr> 
<td style="background-color: #ffffff; text-align:center;">
<table style="width:590px; background-color: #ffffff; color:#000000;" align ="center" border="0">
<tr>
<td width="50%" valign="middle" style="padding: 15px; font-size:12px; text-align:left;">
<a href="http://www.workn-sport.com/faq/"><img style="padding: 8px; width:223px; border-bottom: 1px solid #5b0032;" src="http://www.workn-sport.com/images/email2_move_more.png" border="0"></a><br>

<p><b>WORK’N SPORT</b> is the 1st corporate connected 
multisports challenge and inclusive, intra ou 
inter-company, in support of Handicap International.</p>

<p>The teams are composed of 1 to 3 
people who can partake in more than 
40 sports.</p>




</td>

<td width="50%" valign="middle" style="padding: 15px;">
<a href="http://www.workn-sport.com/faq/"><img style="width:250px;" src="http://www.workn-sport.com/images/email2_woman.png" border="0"></a>
</td>

</tr></table>

</td></tr>


<tr><td style="padding: 20px; background-color: #ffffff; font-size:14px; color: #000000; text-align: center;"><b style="color:#ff6c00">The rule is simple :</b> <b>1 minute</b> of sport or physical activity = <b>1 point!</b></td></tr>


<tr><td style="text-align:center;"><div style="padding: 0px 20px 0px 20px; width: 560px; background-color: #ffffff;"><div style="width: 560px; height: 1px; border-top: 1px solid #5b0032"></div></div></td></tr>



<tr>
<td valign="top">

<table style="width:600px; background-color: #ffffff; color:#000000;">
<tr>
<td width="50%" valign="top" style="padding: 20px; font-size:12px">

<p>If you need to reconnect
your <b>MOVES</b> and <b>WORK’N SPORT apps</b>
click here and enter your email pour
receive a new activation code :
<a href="http://www.workn-sport.com/moves/email" style="color:#5b0032"><b><i>www.workn-sport.com/moves/email</i></b></a></p>



</td>

<td width="50%" valign="middle" style="padding: 20px; font-size:12px; text-align: center;">

<p><b>Click here to find all the answers 
to the frequently asked questions :</b></p>

<a href="http://www.workn-sport.com/faq/" ><img style="width:95px;" src="http://www.workn-sport.com/images/email2_faq.png" border="0"></a>

</td>


</tr></table>

</td></tr>



<tr><td style="background-color: #5b0032"><img style="max-width:600px;" src="http://www.workn-sport.com/images/email2_footer_top.png" border="0"></td></tr>


<tr><td valign="top" style="height:110px; background-color: #5b0032; color: #ffffff; font-size:9px; text-align: center; font-weight: normal;">


<table style="width:600px; background-color: #5b0032;">
<tr>
<td width="20%" valign="top" s style="padding: 0px;"></td>

<td width="60%" valign="top" style="padding: 0px; text-align:center;">
<a href="https://www.facebook.com/WorkN-Sport-951584984895304/"><img style="margin: 0 4px 10px 4px; width:27px;" src="http://www.workn-sport.com/images/email2_f.png" border="0"></a>
<a href="https://twitter.com/worknsport/"><img style="margin: 0 4px 10px 4px; width:27px;" src="http://www.workn-sport.com/images/email2_t.png" border="0"></a>
<a href="https://www.linkedin.com/groups/8527807"><img style="margin: 0 4px 10px 4px; width:27px;" src="http://www.workn-sport.com/images/email2_l.png" border="0"></a>

<div style="margin: 4px 0 0 0; font-size:9px;"><b>Copyright © <a href="http://www.workn-sport.com/" style="color:#ffffff;">www.workn-sport.com</a>, All rights reserved.</b><br>
If you no longer wish to receive the weekly emails,<a href="http://www.workn-sport.com/account" style="color:#ffffff;">login to you account</a> to unsubscribe.</div>


</td>

<td width="20%" valign="top" style="padding: 0px; background-color:#5b0032; color:#ffffff; font-size:8px">

<div style="margin: 30px 0 0 0;">5% of the turnover is donated to<br>
<img style="margin: 4px 0 0px 0; width:64px;" src="http://www.workn-sport.com/images/email2_handicap.png" border="0"><br>
<nobr><i><a href="http://www.handicap-international.fr" style="color:#ffffff;">www.handicap-international.fr</a></i></nobr><br></div>

</td>

</tr></table>


</td></tr>


</table>

<!-- END ENGLISH NEW-->





</body>
</html>



