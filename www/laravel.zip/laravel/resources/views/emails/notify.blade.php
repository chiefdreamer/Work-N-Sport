
<?php 
echo 'ADMIN: New registration at Work’n Sport: '. $email.' '. $first_name." ".$last_name ."<br>";
echo '<a href="http://www.workn-sport.com/moves-status/">Latest participant activations</a>';
?>

