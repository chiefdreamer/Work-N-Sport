<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <h2><b>Work’n Sport | Contact</b></h2>

        <div>
        
		<p><b>Société</b> : {{ $company }}</p>
		<p><b>Prénom</b> : {{ $first_name }}</p>
		<p><b>Nom</b> : {{ $last_name }}</p>
		<p><b>Désignation d’emploi</b> : {{ $position }}</p>
		<p><b>Email</b> : {{ $email }}</p>
		<p><b>Téléphone</b> : {{ $telephone }}</p>
		<p><b>Message</b> : {{ $email_message }}</p>

        </div>

    </body>
</html>

