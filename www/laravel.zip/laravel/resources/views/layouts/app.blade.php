<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

<meta name="description" content="The Corporate Connected Multi-sports Challenge. D’abord, inscrivez-vous sur notre site Internet et remplissez vos informations personnelles nécessaires à votre inscription et réglez votre inscription. Enfin, vous devez autoriser l’accès de Work’N Sport à vos données de l’application Moves. C’est bon, vous pouvez maintenant accéder à votre profil pour le Challenge ainsi qu’aux pages vous permettant de voir l’ensemble des classements des compétitions.">

<meta name="keywords" content="Corporate, Connected, Multi-sports, Challenge, Moves, app, smartphone, health, fitness, santé mentale, forme physique">

    <title>WORK N SPORT</title>



		@section('facebook_url', 'https://www.facebook.com/WorkN-Sport-951584984895304/')
		@section('twitter_url',  'https://twitter.com/worknsport/')
		@section('linkedin_url', 'https://www.linkedin.com/groups/8527807/')
		
		@section('flag_url_fr', "http://www.workn-sport.com/pdf/worknsport_fr.pdf")
		@section('flag_url_es', "http://www.workn-sport.com/pdf/worknsport_es.pdf")
		@section('flag_url_gb', "http://www.workn-sport.com/pdf/worknsport_gb.pdf")
		@section('flag_url_de', "http://www.workn-sport.com/pdf/worknsport_de.pdf")
		@section('flag_url_cn', "http://www.workn-sport.com/pdf/worknsport_cn.pdf")
		@section('flag_url_fi', "http://www.workn-sport.com/pdf/worknsport_fi.pdf")
		@section('flag_url_se', "http://www.workn-sport.com/pdf/worknsport_se.pdf")
		@section('flag_url_it', "http://www.workn-sport.com/pdf/worknsport_it.pdf")
		@section('flag_url_ru', "http://www.workn-sport.com/pdf/worknsport_ru.pdf")	
	
		
		
		
		
    <!-- Fonts -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700" rel='stylesheet' type='text/css'>

    <!-- Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet">




    <link href="{{ asset('css/flag-icon.css') }}" rel="stylesheet">
    
 
    <link href="{{ asset('css/custom.css') }}" media="all" rel="stylesheet" type="text/css" />
     
        {{-- <link href="{{ elixir('css/app.css') }}" rel="stylesheet"> --}}

    <style>
        body {
            font-family: 'Lato';
        }

        .fa-btn {
            margin-right: 6px;
        }
        
        .moves-icon{
        	background: url('http://www.workn-sport.com/images/icon_moves.png') no-repeat 10px 15px / 20px 20px; 
        
   
        
 
        
        
    </style>
    
    
    
	<script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-591135-8', 'auto');
	  ga('send', 'pageview');

	</script>

</head>
<body id="app-layout">
    

 
         <div class="navbar-header-top">
			 <div>
					<div class="pull-left">
						<div style="margin: 0 20px 0 0">
						
					
						<!--<i style="color: #ffffff" class="fa fa-question-circle" aria-hidden="true"></i>-->
						
					
						
						<!--<a href="http://www.workn-sport.com/smartphone">--><i style="margin: 0 5px 0 0; color: #ffffff" class="fa fa-phone" aria-hidden="true"></i><!--</a>-->
						+33 9 83 29 82 73
						
					</div>
				
					
					
					</div>
					
					<div class="tagline">The Corporate Connected Multi-sports Challenge</div>
		
					
					<div class="pull-right">
					
					<!--
                    @if (Auth::guest())
                        <div><a href="{{ url('/login') }}">Sign in</a></div>
                    @else
                    	<div><a href="{{ url('/logout') }}">Sign out</a></div>
                    @endif
                    -->
                        
						
				
					<div class="header_social">
					   <div><a href="@yield('facebook_url')"><img src="/images/icon_facebook.png"></a></div>  
					   <div><a href="@yield('twitter_url')"><img src="/images/icon_twitter.png"></a></div> 
					   <div><a href="@yield('linkedin_url')"><img src="/images/icon_linkedin.png"></a></div>  
					</div>
		
					</div>
		
			</div>
        </div>




    <nav class="navbar navbar-default navbar-static-top" style="margin-bottom:0px;">
        <div class="container">
        
  

            <div class="navbar-header">

                <!-- Collapsed Hamburger -->
                
         
                 <!--
                 <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                    <span class="sr-only">Toggle Navigation</span>                
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>                 
                </button>
                -->
                
                <span type="image" value='' class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                    <span class="sr-only">Toggle Navigation</span>                              
                </span>
          
            
			
                <!-- Branding Image -->
                <a class="navbar-brand" href="{{ url('/') }}">
                   <!--WORK N SPORT-->
                   
                   		
                   		
                 	    <div class="menu_logo">
                 	
                 	    @if (Auth::user() && Auth::user()->id =='134') 
                 	    <img src="/images/logo_worknsport_sodexo.png">
                 	    @elseif (Auth::user() && Auth::user()->id =='140') 
                 	    <img src="/images/logo_worknsport_cnosf.png">
                 	    @else  
                 	    <img src="/images/logo_worknsport.png">
                 	    @endif
                 	    </div>  
                 	                  
                  
                </a>
            
            </div>

            <div class="collapse navbar-collapse" id="app-navbar-collapse">
                <!-- Left Side Of Navbar -->
                <ul class="nav navbar-nav wns_uppercase">
            
            
            
          
             
              <li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
							@if (App::getLocale() =='fr') 
							<span class="flag-icon flag-icon-fr"></span> 
							@elseif (App::getLocale() =='en') 
							<span class="flag-icon flag-icon-gb"></span>
							@endif 
							<!--{{ Config::get('languages')[App::getLocale()] }}-->&nbsp;&nbsp;<span class="caret"></span>
				</a>
				
				<ul class="dropdown-menu">
					@foreach (Config::get('languages') as $lang => $language)
						@if ($lang != App::getLocale())
							<li>

								<a href="{{ route('lang.switch', $lang) }}">{{$language}}</a>
							</li>
						@endif
					@endforeach
				</ul>
			</li>




              
                    <li class="dropdown" style="white-space:nowrap">
    
                            
        			<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"><i class="fa fa-trophy" aria-hidden="true"></i>&nbsp{{ trans('wns.CLASSEMENTS') }}&nbsp;&nbsp;<span class="caret"></span></a>

							<ul class="dropdown-menu" role="menu" >
								<li><a href="{{ url('/rankings') }}">{{ trans('wns.Societes / Equipes') }}</a></li>
								<li><a href="{{ url('/my/rankings') }}">{{ trans('wns.Mon Classement') }}</a></li>
								<!--<li><a href="{{ url('/dashboard') }}">Dashboard</a></li>-->
							</ul>
                    </li>
            
       
       			
   
					<!-- set in routes.php --> 
					<!-- show register link if on mobile browser -->  
					<!-- hide register link if in mobile app -->  
					@if ($INCLUDE_SUB_MENU)
						@if (Auth::guest())
						<li><a class="red" href="{{ url('/register') }}"><i class="fa fa-pencil" aria-hidden="true"></i>&nbsp;{{ trans('wns.Inscriptions') }}</a></li>
						@endif  
					@endif  
					
					@if (!Auth::guest())
                     <li><a href="{{ url('/account') }}"><i class="fa fa-btn fa-user"></i>{{ trans('wns.Compte') }}</a></li>
                    @endif  
				
		
		
		
				
   
        			<li class="dropdown moves-icon" style="padding: 0 0 0 20px;">
      
        			
        			<a href="#" style="white-space: nowrap;" class="dropdown-toggle" data-toggle="dropdown" role="button">{{ trans('wns.Moves') }}&nbsp;&nbsp;<span class="caret"></span></a>
        			
							<ul class="dropdown-menu" role="menu" style="margin: 0 0 0 20px;">
								<li><a href="{{ url('/moves') }}" aria-expanded="false">{{ trans('wns.Activation') }}</a></li>
								<li><a href="{{ url('/moves/faq') }}">{{ trans('wns.Faq') }}</a></li>
							</ul>
                    </li>
                    
                    
                    

             	
        			<li style="padding: 0 0 0 0px;">
        			<a href="#" style="white-space: nowrap;" class="dropdown-toggle" data-toggle="dropdown" role="button"><i class="fa fa-life-ring"></i>&nbsp;{{ trans('wns.Aide') }}&nbsp;&nbsp;<span class="caret"></span></a>
        		
							<ul class="dropdown-menu" role="menu" style="margin: 0 0 0 0px;">
								<li><a href="{{ url('/about') }}">{{ trans('wns.Tutoriel') }}</a></li>
								<li><a href="/pdf/{{ trans('wns.brochure') }}.pdf">Brochure</a></li>
								<li><a href="{{ url('/faq') }}">{{ trans('wns.QUESTIONS FRÉQUENTES') }}</a></li>
							</ul>
                    </li>
                    
     
     
  <li><a href="http://www.youtube.com/watch_popup?v={{ trans('wns.Video_URL') }}"><i class="fa fa-youtube-play" style="color:#df291e"></i>&nbsp;{{ trans('wns.Video') }}</a></li>
                                   
                    
                   
                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                			
				<!--
				<li style="font-size:11px; padding: 18px 0 0 10px">	
				@if (App::getLocale() =='fr') 
				En soutien à
				@elseif (App::getLocale() =='en') 
				We support 
				@endif	
				</li> 
				-->

				<!--<li><a href="http://www.handicap-international.fr"><img class="handicap_international" src="/images/logo_handicap_international.png" /></a></li>-->
               
                 
            
            
            	
                 
                    <!-- Authentication Links -->
                    <li></li>
                    @if (Auth::guest())
                        <li><a href="{{ url('/login') }}"><i class="fa fa-lock" aria-hidden="true"></i>&nbsp;Login</a></li>
                        <!--<li><a href="{{ url('/register') }}">Register</a></li>-->
                    @else
                        <li class="dropdown">
                       
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                {{ Auth::user()->first_name }} {{ Auth::user()->last_name }}<span class="caret"></span>
                            </a>

								<ul class="dropdown-menu" role="menu">
									<li><a href="{{ url('/account') }}"><i class="fa fa-btn fa-user"></i>{{ trans('wns.Compte') }}</a></li>
									<li><a href="{{ url('/logout') }}"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
       
									@if (Auth::check())
									<!--<li class="nav-divider"></li>-->
									<!--<li><a href="{{ url('/teams') }}">{{ trans('wns.Equipes / Participants') }}</a></li>-->
									<!--<li><a href="{{ url('/participants') }}">Participants</a></li>-->
									@endif
								</ul>
                        </li>
                    @endif
                </ul>
            </div>
        </div>
    </nav>


    @yield('content')

    <!-- JavaScripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
 
 
 
     
     <!-- Multiselect -->
	<script type="text/javascript" src="http://davidstutz.github.io/bootstrap-multiselect/dist/js/bootstrap-multiselect.js"></script>
	<link rel="stylesheet" href="http://davidstutz.github.io/bootstrap-multiselect/dist/css/bootstrap-multiselect.css" type="text/css"/>



   
	<!--for croppic-->
    <link rel="stylesheet" href="{{ asset('js/croppic/assets/css/main.css') }}"/> 
    <link rel="stylesheet" href="{{ asset('js/croppic/assets/css/croppic.css') }}"/> 
    <script src="{{ asset('js/croppic/croppic.min.js') }}"></script>
    
    
    
    
   <script type="text/javascript" src="{{ asset('js/custom.js') }}"></script>
    
    
    <!--for carousel swipe-->
	<script src="{{ asset('js/carousel-swipe.js') }}"></script> 
	

    
    {{-- <script src="{{ elixir('js/app.js') }}"></script> --}}
 
 

     
 
       <div class="menu_logo_footer">
       
       <div><img src="/images/googleplay.png" style="width:125px"></div>
       
      <div class="footer_apps">{{ trans('wns.wns_apps') }}</div>
            
            
       
       <div>
       <img src="/images/logo_worknsport_footer.png">
       </div>
       
 
   
   
       
     <div class="footer_byline">The Corporate Connected Multi-sports Challenge</div> 
    
     
     
     
        <div class="footer_social">
		   <div><a href="@yield('facebook_url')"><img src="/images/icon_facebook.png"></a></div>  
		   <div><a href="@yield('twitter_url')"><img src="/images/icon_twitter.png"></a></div> 
		   <div><a href="@yield('linkedin_url')"><img src="/images/icon_linkedin.png"></a></div>  
		</div>
		
		
		
	 <div  class="footer_menu">     
	 <div>
	 @if (App::getLocale() =='fr')<a href="/@yield('flag_url_fr')">@endif
	 @if (App::getLocale() =='en')<a href="/@yield('flag_url_gb')">@endif
	 {{ trans('wns.WORK’N SPORT') }}</a>
	 </div> 
	 
	      
     <div><a href="{{ url('/contact') }}">{{ trans('wns.CONTACT') }}</a></div>
     <!--<div><a href="mailto:info@workn-sport.com">{{ trans('wns.CONTACT') }}</a></div>-->
     <div><a href="{{ url('/faq') }}">{{ trans('wns.QUESTIONS FRÉQUENTES') }}</a></div> 
     <div><a href="{{ url('/subscribe') }}">{{ trans('wns.INSCRIPTIONS') }}</a></div> 
     </div>

    
    
           
       
      	<div class="footer_flags">   
		
			   <div><a href="@yield('flag_url_fr')"><span class="flag-icon flag-icon-fr"></span></a></div>
			   <div><a href="@yield('flag_url_es')"><span class="flag-icon flag-icon-es"></span></a></div>
			   <div><a href="@yield('flag_url_gb')"><span class="flag-icon flag-icon-gb"></span></a></div>
			   <div><a href="@yield('flag_url_de')"><span class="flag-icon flag-icon-de"></span></a></div>
			   <div><a href="@yield('flag_url_cn')"><span class="flag-icon flag-icon-cn"></span></a></div>
			   <div><a href="@yield('flag_url_fi')"><span class="flag-icon flag-icon-fi"></span></a></div>
			   <div><a href="@yield('flag_url_se')"><span class="flag-icon flag-icon-se"></span></a></div>
			   <div><a href="@yield('flag_url_it')"><span class="flag-icon flag-icon-it"></span></a></div>
			   <div><a href="@yield('flag_url_ru')"><span class="flag-icon flag-icon-ru"></span></a></div>

       </div> 
    
  
		
		<div class="footer_menu2">   
		
		   <div class="footer_terms"><a href="{{ url('/privacy') }}">{{ trans('wns.Politique de confidentialité') }}</a></div>
		   
		   <div class="footer_email">info@workn-sport.com</div>
		   
		   <div class="footer_terms"><a href="{{ url('/terms') }}">{{ trans('wns.Conditions d’utilisation') }}</a></div>
       </div>
       
		<div style="width:100%; text-align: center"><img class="move_more" style="width: 100px; margin: 20px 0 0 8px" src="/images/move_more.png" /></div>
		  
       <div class="footer_trademark">{{ trans('wns.wns_trademark') }}</div>
       
       <div class="footer_trademark">Corporate Games France | <a href="http://www.corporate-games.fr" target="_blank">www.corporate-games.fr</a></div>
       
       
       <div class="footer_trademark">      
       <div style="margin: 20px 0 0 8px">{{ trans('wns.Partenaire Stratégique') }}</div>
       
       <a href="http://www.corporate-games.fr" target="_blank"><img class="move_more" style="width: 150px; margin: 20px 0 0 8px" src="/images/cg_logo.png" /></a>
       
       </div>
       
       
       <?php $laravel = app();$version = $laravel::VERSION;?>

		 <div style="font-size:8px; color:#c2c2c2;margin: 15px 0 0 0">Laravel version {{$version}}</div>
       
       
    </div>
       

</div>      
       
</body>
</html>
