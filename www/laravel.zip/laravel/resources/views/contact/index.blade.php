@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
            
               
                
                
                <div class="panel-body">
           
                <p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png">Contact</p>
                
                     
                
                @if (!empty($message))
                 <div class="panel-heading">{{ $message }}</div>   
                 
                 
                 
				@else


     
                
                    <form class="form-horizontal" role="form" method="POST" action="{{ url('/contact/send') }}">
                        {!! csrf_field() !!}


						<div class="form-group{{ $errors->has('company') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">* {{ trans('wns.Contact_Société') }}</label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="company" value="{{ old('company') }}">

                                @if ($errors->has('company'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('company') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                   
                        
                        
                        <div class="form-group{{ $errors->has('first_name') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">* {{ trans('wns.Contact_Prénom') }}</label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="first_name" value="{{ old('first_name') }}">

                                @if ($errors->has('first_name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('first_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                        <div class="form-group{{ $errors->has('last_name') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">* {{ trans('wns.Contact_Nom') }}</label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="last_name" value="{{ old('last_name') }}">

                                @if ($errors->has('last_name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('last_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                        
                        <div class="form-group{{ $errors->has('position') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">{{ trans('wns.Contact_Position') }}</label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="position" value="{{ old('position') }}">

                                @if ($errors->has('position'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('position') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">* {{ trans('wns.Contact_Email') }}</label>

                            <div class="col-md-6">
                                <input type="email" class="form-control" name="email" value="{{ old('email') }}">

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>


                     	<div class="form-group{{ $errors->has('telephone') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">{{ trans('wns.Contact_Phone') }}</label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="telephone" value="{{ old('telephone') }}">

                                @if ($errors->has('telephone'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('telephone') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                        
                        
                        <div class="form-group{{ $errors->has('email_message') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">{{ trans('wns.Contact_Message') }}</label>

                            <div class="col-md-6">
                                <textarea class="form-control" name="email_message" style="height:60px">{{ old('email_message') }}</textarea>

                                @if ($errors->has('email_message'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email_message') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                        
    

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary" style="width:100%; background-color: FF0000;">
                                    <i class="fa fa-paper-plane"></i>&nbsp;Send
                                </button>
                            </div>
                        </div>
                    </form>
                    
                    
                    @endif
                    
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

