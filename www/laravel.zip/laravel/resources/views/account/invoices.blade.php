@extends($DEFAULT_VIEW)


@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        	<div class="panel panel-default">
        	
        	
            		 @if ($INCLUDE_SUB_MENU)
					<div class="panel-heading">
						@include('shared.menu_tabs')
					</div>
                	@endif
					
<p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png">{{ trans('wns.FACTURES_SUB') }}</p>



			@if (count($invoices) > 0)
			


					<div class="panel-body">
						<table class="table invoices-striped invoices-table" style="font-size:14px;">

							<!-- Table Headings -->
							<thead>
							<tr>
								<th style="text-align:left">{{ trans('wns.invoices_title') }}</th>
								<th style="text-align:right">{{ trans('wns.invoices_product') }}</th>
								<th style="text-align:right">{{ trans('wns.invoices_participants') }}</th>
								<th style="text-align:right">{{ trans('wns.invoices_total') }}</th>
								<th style="text-align:right">HTML</th>
								<th style="text-align:right">PDF</th>
							</tr>
							</thead>
				
				

							<!-- Table Body -->
							<tbody>
								@foreach ($invoices as $invoice)
									<tr>
							
										<td style="text-align:left">
											<div>{{ $invoice->created_at }}</div>
										</td>
										
										<td style="text-align:right">
											<div>{{ $invoice->product }}</div>
										</td>

										
										<td style="text-align:right">
											<div>{{ $invoice->qty }}</div>
										</td>
										
										<td style="text-align:right">
											<div>{{ number_format(($invoice->amount/100), 2, '.', '') }} €</div>
										</td>
										
										
										<td style="text-align:right">
											<div><a href="/facture.php?id={{$invoice->id}}&user_id={{Auth::user()->id}}"><i class="fa fa-file-o" style="color:#0000ff"></i></a></div>
										</td>
										
										<td style="text-align:right">
											<div><a href="/facture_pdf.php?id={{$invoice->id}}&user_id={{Auth::user()->id}}"><i class="fa fa-file-pdf-o" style="color:#0000ff"></i></a></div>
										</td>
										
										
										
										
									</tr>
								@endforeach
							</tbody>
						</table>
					</div>
				</div>
				
				
			@else
			<div class="panel panel-body">{{ trans('wns.invoices_none') }}</div>
				
			@endif
   
		 </div>
	
	 </div>
		
   
    </div>
</div>




@endsection


