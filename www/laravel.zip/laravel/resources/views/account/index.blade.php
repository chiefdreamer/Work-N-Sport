@extends($DEFAULT_VIEW)

@section('content')
<div class="container" style="margin: 10px auto 0 auto">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
            		
            		 @if ($INCLUDE_SUB_MENU)
					<div class="panel-heading">
						@include('shared.menu_tabs')
					</div>
                	@endif
                
                
         				@if(Session::has('flash_message'))
							<div class="alert alert-success"><span class="glyphicon glyphicon-ok"></span><em> {!! session('flash_message') !!}</em></div>
						@endif
				
				
				<div>
    

 
</div>

<p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png">{{ trans('wns.Compte') }}</p>



                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="{{ url('/account/update?app=') }}{{ app('request')->input('app') }}" onSubmit= "return validatePasswordCheck();">
                        {!! csrf_field() !!}
					<p>{{ trans('wns.La personne clé de votre société qui sera notre interlocutrice.') }}</p>

                        <div class="form-group{{ $errors->has('non_commercial') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">{{ trans('wns.Non_lucratifs_form') }}</label>
                            <div class="col-md-6">
                                <input style="margin: 20px 0 0 0; width:20px; height:20px;" type="checkbox" class="form-control" name="non_commercial" value="1" {{ $is_checked2 or '' }}>

                                @if ($errors->has('non_commercial'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('non_commercial') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div> 
                        
                        
                         <div class="form-group{{ $errors->has('company') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">* {{ trans('wns.Société') }}</label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" id="company" name="company" value="{{ $company }}">

                                @if ($errors->has('company'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('company') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                       



                        <div class="form-group{{ $errors->has('first_name') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">* {{ trans('wns.Prénom') }}</label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" id="first_name" name="first_name" value="{{ $first_name }}">

                                @if ($errors->has('first_name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('first_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                        <div class="form-group{{ $errors->has('last_name') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">* {{ trans('wns.Nom') }}</label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" id="last_name" name="last_name" value="{{ $last_name }}">

                                @if ($errors->has('last_name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('last_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                        
                        
                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">* {{ trans('wns.Email') }}</label>

                            <div class="col-md-6">
                                <input type="email" class="form-control" id="email" name="email" value="{{ $email }}">

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                        <div class="form-group{{ $errors->has('phone') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">* {{ trans('wns.Téléphone') }}</label>

                            <div class="col-md-6">
                                <input type="phone" class="form-control" id="phone" name="phone" value="{{ $phone }}">

                                @if ($errors->has('phone'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('phone') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>


                        <div class="form-group{{ $errors->has('address') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">{{ trans('wns.Adresse') }}</label>

                            <div class="col-md-6">
                                <input type="address" class="form-control" id="address" name="address" value="{{ $address }}">

                                @if ($errors->has('address'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('address') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                        
                        <div class="form-group{{ $errors->has('city') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">{{ trans('wns.Ville') }}</label>

                            <div class="col-md-6">
                                <input type="city" class="form-control" id="city" name="city" value="{{ $city }}">

                                @if ($errors->has('city'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('city') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                        <div class="form-group{{ $errors->has('postcode') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">{{ trans('wns.Postal') }}</label>

                            <div class="col-md-6">
                                <input type="postcode" class="form-control" id="postcode" name="postcode" value="{{ $postcode }}">

                                @if ($errors->has('postcode'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('postcode') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                        <div class="form-group{{ $errors->has('country') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">* {{ trans('wns.Pays') }}</label>

                            <div class="col-md-6">
                 
                                <select id="country" name="country" class="form-control" id="country">
                                <option selected value="">{{ trans('wns.Pays') }}</option>
				    			
				    			<option @if ($country  == 'Australia') selected @endif value="{{ 'Australia'}}">{{ 'Australia' }}</option>
				    			<option @if ($country  == 'Austria') selected @endif value="{{ 'Austria'}}">{{ 'Austria' }}</option>
				    			<option @if ($country  == 'Belgium') selected @endif value="{{ 'Belgium'}}">{{'Belgium' }}</option>
				    			<option @if ($country  == 'Canada') selected @endif value="{{ 'Canada'}}">{{ 'Canada' }}</option>
								<option @if ($country  == 'Chile') selected @endif value="{{ 'Chile'}}">{{ 'Chile' }}</option>
								<option @if ($country  == 'China') selected @endif value="{{ 'China'}}">{{ 'China' }}</option>
								<option @if ($country  == 'Czech Republic') selected @endif value="{{ 'Czech Republic'}}">{{ 'Czech Republic' }}</option>
								
								<option @if ($country  == 'Denmark') selected @endif value="{{ 'Denmark'}}">{{ 'Denmark' }}</option>
								<option @if ($country  == 'Estonia') selected @endif value="{{ 'Estonia'}}">{{ 'Estonia' }}</option>
								
								<option @if ($country  == 'Ecuador') selected @endif value="{{ 'Ecuador'}}">{{ 'Ecuador' }}</option>
								
								<option @if ($country  == 'Finland') selected @endif value="{{ 'Finland'}}">{{ 'Finland' }}</option>
								
								
								<option @if ($country  == 'France') selected @endif value="{{ 'France'}}">{{ 'France' }}</option>
								
								<option @if ($country  == 'Germany') selected @endif value="{{ 'Germany'}}">{{ 'Germany' }}</option>
								<option @if ($country  == 'Greece') selected @endif value="{{ 'Greece'}}">{{ 'Greece' }}</option>
								<option @if ($country  == 'Hungary') selected @endif value="{{ 'Hungary'}}">{{ 'Hungary' }}</option>
								
								<option @if ($country  == 'Iceland') selected @endif value="{{ 'Iceland'}}">{{ 'Iceland' }}</option>
								<option @if ($country  == 'Ireland') selected @endif value="{{ 'Ireland'}}">{{ 'Ireland' }}</option>
								<option @if ($country  == 'Israel') selected @endif value="{{ 'Israel'}}">{{ 'Israel' }}</option>
								
								<option @if ($country  == 'Italy') selected @endif value="{{ 'Italy'}}">{{ 'Italy' }}</option>
								<option @if ($country  == 'Japan') selected @endif value="{{ 'Japan'}}">{{ 'Japan' }}</option>
								<option @if ($country  == 'Korea') selected @endif value="{{ 'Korea'}}">{{ 'Korea' }}</option>
								
								<option @if ($country  == 'Luxembourg') selected @endif value="{{ 'Luxembourg'}}">{{ 'Luxembourg' }}</option>
								<option @if ($country  == 'Mexico') selected @endif value="{{ 'Mexico'}}">{{ 'Mexico' }}</option>
								<option @if ($country  == 'Netherlands') selected @endif value="{{ 'Netherlands'}}">{{ 'Netherlands' }}</option>	
								
								<option @if ($country  == 'New Zealand') selected @endif value="{{ 'New Zealand'}}">{{ 'New Zealand' }}</option>
								<option @if ($country  == 'Norway') selected @endif value="{{ 'Norway'}}">{{ 'Norway' }}</option>
								<option @if ($country  == 'Poland') selected @endif value="{{ 'Poland'}}">{{ 'Poland' }}</option>	
								
								<option @if ($country  == 'Portugal') selected @endif value="{{ 'Portugal'}}">{{ 'Portugal' }}</option>
								
								<option @if ($country  == 'Romania') selected @endif value="{{ 'Romania'}}">{{ 'Romania' }}</option>
								
								<option @if ($country  == 'Slovak Republic') selected @endif value="{{ 'Slovak Republic'}}">{{ 'Slovak Republic' }}</option>
								<option @if ($country  == 'Slovenia') selected @endif value="{{ 'Slovenia'}}">{{ 'Slovenia' }}</option>	
								
								<option @if ($country  == 'South Africa') selected @endif value="{{ 'South Africa'}}">{{ 'South Africa' }}</option>	
								
								<option @if ($country  == 'Spain') selected @endif value="{{ 'Spain'}}">{{ 'Spain' }}</option>
								<option @if ($country  == 'Sweden') selected @endif value="{{ 'Sweden'}}">{{ 'Sweden' }}</option>
								<option @if ($country  == 'Switzerland') selected @endif value="{{ 'Switzerland'}}">{{ 'Switzerland' }}</option>
								
								<option @if ($country  == 'Turkey') selected @endif value="{{ 'Turkey'}}">{{ 'Turkey' }}</option>
								
								<option @if ($country  == 'United Arab Emirates') selected @endif value="{{ 'United Arab Emirates'}}">{{ 'United Arab Emirates' }}</option>
								
								<option @if ($country  == 'United Kingdom') selected @endif value="{{ 'United Kingdom'}}">{{ 'United Kingdom' }}</option>					
								
								<option @if ($country  == 'United States') selected @endif value="{{ 'United States'}}">{{ 'United States' }}</option>	
 	





								</select>
					

                                @if ($errors->has('country'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('country') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>


						 <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">* {{ trans('wns.Mot de passe') }}</label>

                            <div class="col-md-6">
                                <input type="password" class="form-control" id="password" name="password">

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        

                        <div class="form-group{{ $errors->has('password_confirmation') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">* {{ trans('wns.Confirmation de mot de passe') }}</label>

                            <div class="col-md-6">
                                <input type="password" class="form-control" name="password_confirmation"  id="password_confirmation">

                                @if ($errors->has('password_confirmation'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password_confirmation') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
             
                        

     
     
                         <div class="form-group{{ $errors->has('cg_cities') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">{{ trans('wns.Je participe aux Corporate Games') }}</label>
                            <div class="col-md-6">
                               
						 {!! $html_multselect  !!}
					
					
					
					
                                @if ($errors->has('cg_cities'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('cg_cities') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        


  
  
                        
                        <div class="form-group{{ $errors->has('private_challenge') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">{{ trans('wns.« Challenge Privé ». Votre entreprise et ses participants n’apparaissent plus sur les classements publics') }}</label>
                            <div class="col-md-6">
                                <input style="margin: 20px 0 0 0; width:20px; height:20px;" type="checkbox" class="form-control" name="private_challenge" value="1" {{ $is_checked or ''}}>

                                @if ($errors->has('private_challenge'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('private_challenge') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>


						 <div class="form-group{{ $errors->has('email_updates') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">{{ trans('wns.Email hebdomadaire des classements publics') }}</label>
                            <div class="col-md-6">
                                <input style="margin: 20px 0 0 0; width:20px; height:20px;" type="checkbox" class="form-control" name="email_updates" value="1" {{ $is_checked3 or ''}}>

                                @if ($errors->has('email_updates'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email_updates') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        


                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-sign-in"></i>Save
                                </button>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@if (session()->has('message'))
    <div class="alert alert-info">{{ session('message') }}</div>
@endif

@endsection
