@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2  col-lg-8 col-lg-offset-2">
        
        <div style="padding: 0 15px 30px 15px;">
					{!! trans('wns-terms.terms') !!}
		</div>
		
        </div>
    </div>
</div>
@endsection



