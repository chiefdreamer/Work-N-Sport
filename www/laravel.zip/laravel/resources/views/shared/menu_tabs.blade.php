
<ul class="nav nav-pills">


<li role="presentation" class="nav-pills-first">
<a href="{{ url('/account') }}"><i class="fa fa-btn fa-user"></i>{{ trans('wns.Compte') }}</a>
</li>

<li role="presentation" class="nav-pills-first">
<a href="{{ url('/teams') }}"><i class="fa fa-btn fa-list"></i>{{ trans('wns.Equipes / Participants') }}</a>
</li>


<li role="presentation" class="nav-pills-first">
<a href="{{ url('/moves') }}"><i class="fa fa-btn fa-bolt"></i>&nbsp;{{ trans('wns.ACTIVATION_SUB') }}</a>
</li>




<!--
<li role="presentation" class="nav-pills-second" style="margin: 3px 0 0 50px;">
<a href="{{ url('/subscribe') }}"><i class="fa fa-credit-card"></i>&nbsp;{{ trans('wns.INSCRIPTIONS_SUB') }}</a>
</li>
-->

<!--
<li role="presentation" class="nav-pills-second" style="margin: 3px 0 0 0px;">
<a href="{{ url('/account/invoices') }}"><i class="fa fa-file-o"></i>&nbsp;{{ trans('wns.FACTURES_SUB') }}</a>
</li>
-->


<li role="presentation" class="nav-pills-second" style="margin: 3px 0 0 0px;">
<a href="{{ url('/about') }}"><i class="fa fa-info-circle"></i>&nbsp;{{ trans('wns.Tutoriel') }}</a>
</li>

</ul>

