@extends($DEFAULT_VIEW)

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
            
            
            		 @if ($INCLUDE_SUB_MENU)
					<div class="panel-heading">
						@include('shared.menu_tabs')
					</div>
                	@endif


     		<p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png">{{ trans('wns.ACTIVATION_SUB') }}</p>



                <div class="panel-body">
                
                	<div>
                	 <!--<div style="margin: 20px 0 20px 0"><img style="margin: -3px 3px 0 5px; height:20px;" src="/images/icon_moves.png" /> {{ strtoupper(trans('wns.Activation')) }}</div>-->
                	 
                	 
     			
     			
                	@if (count($participants) > 0)
						<select  class="form-control" id="id_participant" style="font-size: 21px; height:38px;">               	
						<option value="">{{ trans('wns-moves.moves_activation_select') }} </option>
						@foreach ($participants as $participant)
							@if ($participant->first_name !='' && $participant->last_name !='' && $participant->email !='' )
							<option value="{{ $participant->id}}" @if ($participant_selected == $participant->id ) selected @endif>{{ $participant->first_name}} {{$participant->last_name }} {{$participant->email }}</option>					
							@endif
						@endforeach
						</select>
						<input onClick="getCode('{{ $request_url }}');" type="button" value="{{ trans('wns-moves.moves_activation_code') }}" style="background-color: #00d45b; color: #ffffff; width: 100%; font-size: 21px;" class="btn">
					
					@else
						<a style="font-size:21px;" href="{{ url('/teams') }}">{{ trans('wns-moves.moves_activation_ajouter') }}...</a>
					
					 
					 
					@endif
			
					</div>
				
				
					
                		<div style="margin: 20px 0 0 0">1: <a href="http://www.moves-app.com/">{{ trans('wns-moves.moves_activation_etape1') }}</a></div>               				
						<div>2: {!! trans('wns-moves.moves_activation_etape2') !!}</div>
						<div>3: {{ trans('wns-moves.moves_activation_etape3') }}</div>
						<div style="color: #ff0000">{{ trans('wns-moves.moves_activation_etape4') }}</div>
						
                
						<div style="color:#FF0000"><!-- {{ trans('wns-moves.moves_activation_etape4') }}--></div>


			

                </div>
            </div>
        </div>
    </div>
</div>
@endsection


