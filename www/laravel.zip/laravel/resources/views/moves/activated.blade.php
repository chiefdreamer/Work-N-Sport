@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading"><img style="margin: -3px 10px 0 5px; height:20px;" src="/images/icon_moves.png" /> MOVES APP</div>

                <div class="panel-body">
                
                		<div>{{ trans('wns-moves.ACTIVATION COMPLETEE') }}</div>    
                		
                	
             				


                </div>
            </div>
        </div>
    </div>
</div>
@endsection


