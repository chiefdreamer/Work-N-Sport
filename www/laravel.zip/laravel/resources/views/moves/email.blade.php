@extends($DEFAULT_VIEW)

<!-- Main Content -->
@section('content')
<div class="container" style="margin: 10px auto 0 auto">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">{{ trans('wns-moves.Activez Moves') }}</div>
                <div class="panel-body">
                

  
                    <form class="form-horizontal" role="form" method="POST" action="">
	               

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label class="col-md-4 control-label">Email</label>

                            <div class="col-md-6">
                                <input type="email" class="form-control" id="email" name="email" value="{{ old('email') }}">

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="button" class="btn btn-primary" onClick="activate_moves_not_logged_in();return false;">
                                    <i class="fa fa-btn fa-envelope"></i>{{ trans('wns-moves.Envoyez l’activation par email') }}
                                </button>
                                <p style="font-size:12px;" >{{ trans('wns-moves.L’adresse email doit être déjà renseignée dans une équipe.') }}</p>
                                <p style="font-size:12px;" ><i class="fa fa-btn fa-bolt"></i><a style="cursor:pointer;" onClick="test_moves_token_not_logged_in();return false;">{{ trans('wns-moves.Tester mon activation Moves.') }}</a></p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
