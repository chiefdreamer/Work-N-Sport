<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title></title>
	
	<style>
	body{font-family: arial;}
	p{font-size:15px}
	p.title1{font-size:18px}
	p.title2{font-size:22px}
	</style>
</head>
<body>





<div style="width:100%; max-width: 600px;">
<p>
<a href="http://www.workn-sport.com/"><img style="max-width:600px;" src="http://www.workn-sport.com/images/email_banner.png" border="0"></a>
</p>







<p class="title1">
<b>Bonjour à toutes et à tous,</b>
</p>




<p>Notre société va participer à Work’N Sport, le 1er challenge connecté multisports solidaire pour entreprises au profit de Handicap International, en mode challenge privé. Vous pourrez consulter votre classement à partir de l’adresse suivante: <a href="http://www.workn-sport.com/my/rankings/reed/">Votre classement</a> 
</p>

<p>Notre challenge débutera le 9 octobre 2017 à 00:01 et se terminera le 19 octobre 2017 à minuit. 
</p>

<p>Le principe est simple, vous êtes par équipe de 3 et 1 minute de sport = 1 point. Votre activité physique est suivie à partir de l’Application gratuite Moves, dont l’application Work’N Sport récupère les données pour ensuite générer un classement inter et intra entreprises. Pour ce premier challenge, afin de favoriser la prise en compte d’activités physiques pour tous, nous limitons la prise en compte de 3 sports: la marche, le vélo et la course à pied. A noter qu’en venant simplement au travail à pied ou au vélo, vous comptabilisez des points pour votre équipe!</p>


<p>
Veuillez trouver ci-dessous toutes les informations vous permettant de connecter MOVES et Work’N Sport sur votre mobile. Pour que toutes nos équipes soient bien comptabilisées sous un seul et unique compte que nous avons déjà créé, nous vous remercions de ne pas vous inscrire directement sur le site internet de Work’n Sport.</p>




<p class="title2"><b>Pour vous inscrire, veuillez s’il vous plait :</b></p>



<p>1] <b>TELECHARGER et ACTIVER MOVES sur votre téléphone</b> (https://moves-app.com). Inutile de vous inscrire sur work-n-sport.com, nous l’avons déjà fait. </p>

<p>2] <b>CLIQUER SUR LE LIEN</b> ci-dessous pour recevoir votre code d’activation Moves:
<br />
<a href="<?php echo  $activate_url ?>">OBTENIR LE CODE</a>
</p>

<p>3] <b>SAISIR LE CODE</b> dans Moves (Logo Moves en bas à droite > App Connectée > Enter PIN/CODE). Attention : le code d’activation perd sa validité après 5 minutes. Après activation de votre code dans Moves, revenez sur votre navigateur sur lequel doit s’afficher le message "activation complétée".

<br />
<span style="color:#ff0000">Important: Le Code perd sa validité après écoulement d’un délai de cinq minutes. Lorsque vous utilisez un navigateur mobile, n’oubliez pas de revenir au navigateur après la boîte de dialogue de confirmation de Moves.</span>
</p>



 
<p>Vous pouvez à présent rejoindre le challenge et suivre votre classement sur www.workn-sport.com.</p>

<p>En vous souhaitant la bienvenue sur Work’N Sport, nous restons à votre disposition pour tout complément d’information au 0674119757 ou par email à info@workn-sport.com.</p>

<p>Move More, Play More</p>

<p>L’équipe de Work’n Sport</p>
 
 
 
<div style="display:inline-block; margin: 0 20px 0 0;"><a href="https://twitter.com/worknsport/"><img src="http://www.workn-sport.com/images/icon_twitter.png" style="width:48px;" border="0"/></a></div>

<div style="display:inline-block; margin: 0 20px 0 0;"><a href="https://www.facebook.com/WorkN-Sport-951584984895304/"><img src="http://www.workn-sport.com/images/icon_facebook.png" style="width:48px;" border="0"/></a>
</div>

<div style="display:inline-block; margin: 0 0 0 0;"><a href="https://www.linkedin.com/groups/8527807/"><img src="http://www.workn-sport.com/images/icon_linkedin.png" style="width:48px;" border="0"/></a></div>

</div>

</body>
</html>
