<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title></title>
	
	<style>
	body{font-family: arial;}
	</style>
</head>
<body>




<p>Bonjour et bienvenue sur Work’N Sport, le 1er challenge connecté multisports solidaire pour entreprises,</p>

<p>Afin de participer à Work’N Sport, le 1er challenge connecté multisports solidaire pour entreprises, veuillez télécharger puis activer l’application Moves sur votre smartphone pour que Work’N Sport puisse accéder à vos données. Pour ce faire, veuillez s’il vous plait:</p>

<p>1] <b>TELECHARGER l’application</b> MOVES sur votre téléphone. </p>

<p>2] <b>CLIQUER SUR LE LIEN</b> ci-dessous pour recevoir votre code d’activation Moves:
<br />
<a href="<?php echo  $activate_url ?>">OBTENIR LE CODE</a>
</p>

 <p>3] <b>SAISIR LE CODE</b> dans l’application Moves (Logo Moves en bas à droite > App Connectée > Enter PIN/CODE) <span style="color:#ff0000">Important: Le Code perd sa validité après écoulement d’un délai de cinq minutes. Lorsque vous utilisez un navigateur mobile, n’oubliez pas de revenir au navigateur après la boîte de dialogue de confirmation de Moves.</span>


<p>Vous pouvez dès à présent rejoindre le challenge et suivre votre classement par équipe et par société sur <a href="http://www.workn-sport.com/rankings">www.workn-sport.com</a> ou en téléchargeant l’application work’N sport, disponible sur Android. </p>

<p>En vous souhaitant la bienvenue sur Work’N Sport, nous restons à votre disposition pour tout complément d’information.</p>

<p>Move More, Play More
L’équipe de Work’n Sport</p>



<p>
&nbsp;
</p>


<p>Hello and welcome to Work’N Sport, the first multi-sport inclusive challenge for companies,</p>

<p>In order to participate in Work’N Sport, the first multi-sport inclusive challenge for companies, please download and activate the Moves application on your smartphone so that Work’N Sport can access your data. To do this, please:</p>

<p>1] <b>DOWNLOAD </b> the MOVES app on your smartphone. </p>

<p>2] <b>CLICK THE LINK</b> below to receive your activation code for Moves:
<br />
<a href="<?php echo  $activate_url ?>">GET THE CODE</a>
</p>

<p>3] <b>ENTER THE CODE</b> in the Moves app (Moves logo bottom right  > Connected Apps > Enter PIN/CODE)
<br />
<span style="color:#ff0000">Important: The Code expires after five minutes. When using a mobile browser, do not forget to return to the browser after the Moves confirmation dialog.</span>
</p>


<p>You can now join the challenge and follow your ranking by team and company on <a href="http://www.workn-sport.com/rankings"> www.workn-sport.com </a> or By downloading the application work’N sport, available on Android.</p>

<p>We welcome you to Work’N Sport, and remain at your service for any further information.</p>

<p>Move More, Play More<br />
The Work’n Sport team</p>



</body>
</html>
