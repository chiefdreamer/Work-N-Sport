<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title></title>
	
	<style>
	body{font-family: arial;}
	</style>
</head>
<body>






<p>Bonjour cher participant de Work’N Sport, le 1er challenge connecté multisports solidaire pour entreprises,</p>

<p>Nous vous présentons tous nos meilleurs vœux sportifs pour vous et vos proches et vous souhaitons une excellente année 2017!</p>

<p>Le challenge 2016 s’achèvera le 9 janvier 2017 à minuit, avec la société Reed Expositions toujours en tête du challenge.</p>

<p>Le prochain challenge débutera le 10 janvier 2017 à 00:01 et se terminera le 31 mars à minuit.</p>

<p>Move More, Play More en 2017.</p>

<p>L’équipe de Work’N Sport</p>
 

<p>Pour participer à Work’N Sport:</p>

<p><b>1] TELECHARGEZ l’application</b> MOVES sur votre téléphone.</p>

<p><b>2] CLIQUEZ SUR LE LIEN</b> ci-dessous pour recevoir votre code d’activation Moves:
<br />
<a href="<?php echo  $activate_url ?>">OBTENIR LE CODE</a></p>

<p><b>3] SAISISSEZ LE CODE</b>, dans l’application Moves (Logo Moves en bas à droite > App Connectée > Enter PIN/CODE) </p>

<p><b>4] SUIVEZ VOTRE CLASSEMENT</b> sur <a href="http://www.workn-sport.com/rankings">www.workn-sport.com</a> ou en téléchargeant l’application Work’N Sport, disponible sur Android.</p>


 





</body>
</html>
