@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading"><img style="margin: -3px 10px 0 5px; height:20px;" src="/images/icon_moves.png" /> MOVES APP | FAQ</div>

                <div class="panel-body">
                
     
  				{!! trans('wns-moves.faq') !!}   

  
			

                </div>
            </div>
        </div>
    </div>
</div>
@endsection


