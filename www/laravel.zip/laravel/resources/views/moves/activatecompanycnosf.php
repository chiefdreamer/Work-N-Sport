<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title></title>
	
	<style>
	body{font-family: arial;}
	p{font-size:15px}
	p.title1{font-size:18px}
	p.title2{font-size:22px}
	</style>
</head>
<body>





<div style="width:100%; max-width: 600px;">
<p>
<a href="http://www.workn-sport.com/"><img style="max-width:600px;" src="http://www.workn-sport.com/images/email_banner.png" border="0"></a>
</p>







<p class="title1">
<b>Bonjour</b>
</p>


<p>En tant que collaborateurs du Comité National Olympique et Sportif Français, nous vous proposons de participer à Work’N Sport, le challenge connecté multisports solidaire pour entreprises, partenaire du CNOSF.
</p>

<p>A compter du 1er juillet vous pourrez vous challenger par équipes de trois dans le cadre de 2 challenges qui auront lieu du 1er juillet à fin septembre, puis du 1er octobre à fin décembre. A vous de jouer pour devenir l’équipe connectée la plus sportive ! </p>  



<p class="title2"><b>Pour vous inscrire, veuillez s’il vous plait :</b></p>




<p>1] <b>TELECHARGER et ACTIVER MOVES sur votre téléphone</b> (https://moves-app.com). Inutile de vous inscrire sur work-n-sport.com, nous l’avons déjà fait. </p>

<p>2] <b>CLIQUER SUR LE LIEN</b> ci-dessous pour recevoir votre code d’activation Moves:
<br />
<a href="<?php echo  $activate_url ?>">OBTENIR LE CODE</a>
</p>

<p>3] <b>SAISIR LE CODE</b> dans Moves (Logo Moves en bas à droite > App Connectée > Enter PIN/CODE). Attention : le code d’activation perd sa validité après 5 minutes. Après activation de votre code dans Moves, revenez sur votre navigateur sur lequel doit s’afficher le message "activation complétée".

<br />
<span style="color:#ff0000">Important: Le Code perd sa validité après écoulement d’un délai de cinq minutes. Lorsque vous utilisez un navigateur mobile, n’oubliez pas de revenir au navigateur après la boîte de dialogue de confirmation de Moves.</span>
</p>



 
<p>Vous pouvez à présent rejoindre le challenge et suivre votre classement sur www.workn-sport.com.</p>

<p>En vous souhaitant la bienvenue sur Work’N Sport, nous restons à votre disposition pour tout complément d’information au 0674119757 ou par email à info@workn-sport.com.</p>

<p>Move More, Play More</p>

<p>L’équipe de Work’n Sport</p>
 
 
 
<div style="display:inline-block; margin: 0 20px 0 0;"><a href="https://twitter.com/worknsport/"><img src="http://www.workn-sport.com/images/icon_twitter.png" style="width:48px;" border="0"/></a></div>

<div style="display:inline-block; margin: 0 20px 0 0;"><a href="https://www.facebook.com/WorkN-Sport-951584984895304/"><img src="http://www.workn-sport.com/images/icon_facebook.png" style="width:48px;" border="0"/></a>
</div>

<div style="display:inline-block; margin: 0 0 0 0;"><a href="https://www.linkedin.com/groups/8527807/"><img src="http://www.workn-sport.com/images/icon_linkedin.png" style="width:48px;" border="0"/></a></div>

</div>

</body>
</html>
