<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title></title>
	
	<style>
	body{font-family: arial;}
	p{font-size:15px}
	p.title1{font-size:18px}
	p.title2{font-size:22px}
	</style>
</head>
<body>





<div style="width:100%; max-width: 600px;">
<p>
<a href="http://www.workn-sport.com/"><img style="max-width:600px;" src="http://www.workn-sport.com/images/email_banner.png" border="0"></a>
</p>


<p class="title1">
<b>Bonjour chers collaborateurs de MONEXT!</b>
</p>


<p>Toute l’équipe de Work’N Sport vous souhaite la bienvenue dans 1er challenge connecté multisports solidaire pour entreprises.</p>


<p>Le prochain challenge débutera le 1 avril 2017 à 00:01 et se terminera le 30 juin à minuit. Veuillez trouver ci-dessous les informations nécessaires pour pouvoir participer!</p>

<p>Move More, Play More en 2017.<br />
L’équipe de Work’N Sport</p>


<p class="title2"><b>Pour participer à Work’N Sport :</b></p>





<p>1] <b>TELECHARGEZ l’application</b> MOVES sur votre téléphone. </p>


<p>2] <b>CLIQUER SUR LE LIEN</b> ci-dessous pour recevoir votre code d’activation Moves:
<br />
<a href="<?php echo  $activate_url ?>">OBTENIR LE CODE</a>
</p>

<p>3] <b>SAISISSEZ LE CODE</b> dans l’application Moves (Logo Moves en bas à droite ou 3 petits points en haut à droite > App Connectée > Enter PIN/CODE)
<br />
<span style="color:#ff0000">Important: Le Code perd sa validité après écoulement d’un délai de cinq minutes. Lorsque vous utilisez un navigateur mobile, n’oubliez pas de revenir au navigateur après la boîte de dialogue de confirmation de Moves.</span>
</p>


<p>4] <b>SUIVEZ VOTRE CLASSEMENT</b> sur <a href="http://www.workn-sport.com/rankings">www.workn-sport.com</a>  ou en téléchargeant l’application Work’N Sport, disponible sur Android.</p>

 
<div style="display:inline-block; margin: 0 20px 0 0;"><a href="https://twitter.com/worknsport/"><img src="http://www.workn-sport.com/images/icon_twitter.png" style="width:48px;" border="0"/></a></div>

<div style="display:inline-block; margin: 0 20px 0 0;"><a href="https://www.facebook.com/WorkN-Sport-951584984895304/"><img src="http://www.workn-sport.com/images/icon_facebook.png" style="width:48px;" border="0"/></a>
</div>

<div style="display:inline-block; margin: 0 0 0 0;"><a href="https://www.linkedin.com/groups/8527807/"><img src="http://www.workn-sport.com/images/icon_linkedin.png" style="width:48px;" border="0"/></a></div>

</div>

</body>
</html>
