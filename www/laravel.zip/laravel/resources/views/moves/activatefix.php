<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title></title>
	
	<style>
	body{font-family: arial;}
	</style>
</head>
<body>


<!--
<p>Chère participante, cher participant de Work’n Sport, 
</p>
-->

<p>
Bonjour <?php echo  $first_name ?>
</p>

<p>
<span style="color:#ff0000"><b>IMPORTANT: </b></span>Suite à une évolution technique pour faciliter l’utilisation de Work’N Sport, nous vous remercions de bien vouloir activer de nouveau l’application Moves sur votre smartphone pour que Work’N Sport puisse accéder à vos données et de calculer vos points. Pour ce faire, veuillez s’il vous plait:
</p>

<p>1] <b>CLIQUER SUR LE LIEN</b> ci-dessous pour recevoir votre code d’activation Moves:
<br />
<a href="<?php echo  $activate_url ?>">OBTENIR LE CODE</a>
</p>

<p>2] <b>SAISIR LE CODE</b> dans l’application Moves (Logo Moves en bas à droite  > App Connectée > Enter PIN/CODE)
<br />
<span style="color:#ff0000">Important: Le Code perd sa validité après écoulement d’un délai de cinq minutes. Lorsque vous utilisez un navigateur mobile, n’oubliez pas de revenir au navigateur après la boîte de dialogue de confirmation de Moves.</span>
</p>
 
<p>Nous vous prions de bien vouloir nous excuser pour cette mise à jour et restons à votre disposition pour tout complément d’information.
</p>

<p>Move More, Play More<br />
L’équipe de Work’n Sport</p>

<p>
<a href="http://www.workn-sport.com/"><img style="max-width:600px;" src="http://www.workn-sport.com/images/email_banner.png" border="0"></a>
</p>


<p>
&nbsp;
</p>

<p>
Hello <?php echo  $first_name ?>
</p>

<p>
<span style="color:#ff0000"><b>IMPORTANT: </b></span>Following a technical update to facilitate the use of Work’N Sport, please reactivate the Moves application on your smartphone so that Work’N Sport can access your data and calculate your points. To do this, please:
</p>

<p>1] <b>CLICK THE LINK</b> below to receive your activation code for Moves:
<br />
<a href="<?php echo  $activate_url ?>">GET THE CODE</a>
</p>

<p>2] <b>ENTER THE CODE</b> in the Moves app (Moves logo bottom right  > Connected Apps > Enter PIN/CODE)
<br />
<span style="color:#ff0000">Important: The Code expires after five minutes. When using a mobile browser, do not forget to return to the browser after the Moves confirmation dialog.</span>
</p>
 
<p>We apologize for this update and remain at your disposal for any further information.
</p>

<p>Move More, Play More<br />
The Work’n Sport team</p>

<p>
<a href="http://www.workn-sport.com/"><img style="max-width:600px;" src="http://www.workn-sport.com/images/email_banner.png" border="0"></a>
</p>



</body>
</html>
