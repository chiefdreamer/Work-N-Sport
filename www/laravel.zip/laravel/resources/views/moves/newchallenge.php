<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title></title>
	
	<style>
	body, td{
	border:0;
	margin:0;
	padding: 0;
	font-size: 12px;
	line-height: 1.5;
	font-family: arial;
	color: #ffffff; 
	} 
	
	table {
	  border-collapse: collapse;
	}
	</style>
</head>
<body>




<table style="width:600px; background-color: #5b0032" align ="left">


<tr><td style="background-color: #5b0032"><a href="http://www.workn-sport.com/"><img style="max-width:600px;" src="http://www.workn-sport.com/images/email2_header_top.png" border="0"></a></td></tr>


<tr><td valign="middle" style="background-color: #5b0032; font-size:13px; padding: 15px">


<p>Bonjour à tous,</p>

<p>Nous vous remercions d’avoir participé au challenge du 1er trimestre 2017 de Work’N Sport. Les 3 sociétés en tête sont Talan, Avril et le Centre Hospitalier Annecy Genevois. Le challenge du 2ème trimestre a déjà débuté et se terminera le 30 juin prochain à minuit! Retrouvez tous les résultats du 1er challenge <a href="http://www.workn-sport.com/rankings/C2" style="color:#ffffff;"><u>en cliquant ici</u></a>. </p> 

<p>Move More, Play, More!</p>

<p>L’équipe de Work’N Sport</p>

</td></tr>



</table>





</body>
</html>



