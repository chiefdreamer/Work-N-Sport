@extends($DEFAULT_VIEW)


@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        	<div class="panel panel-default">
        	
        	
            		 @if ($INCLUDE_SUB_MENU)
					<div class="panel-heading">
						@include('shared.menu_tabs')
					</div>
                	@endif
					
					
			<!-- Display My Teams -->
			@if (count($teams) > 0)
			


     		<p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png">{{ trans('wns.Equipes') }}</p>


					<div class="panel-body">
						<table class="table table-striped teams-table">

							<!-- Table Headings -->
			
			

							<!-- Table Body -->
							<tbody>
								@foreach ($teams as $team)
									<tr>
										<!-- Team Name -->
										<td class="table-text" width="25%">
											<div>{{ $team->title }}</div>
										</td>
										
										<td class="table-text" width="25%">
											<div>{{ $team->description }}</div>
										</td>
										
										<td class="table-text" width="25%">
											<div>
											@if ($at_least_one_in_team_not_activated[$team->id])
												
												
												
												<form action="{{ url('teams/update') }}" method="POST">
										        {!! csrf_field() !!}
										        {!! method_field('PATCH') !!}
												
		
												<button type="button" class="btn btn-success_OFF  btn-xs AddEditButton" 																															
												data-toggle="modal"												 
												data-target="#confirmUpdate__TARGET" 
												data-id="{{ $team->id  or ''}}" 
												data-title="{{ $team->title  or ''}}" 
												data-description="{{ $team->description  or ''}}" 
												 
												
												data-moves1="{{ $teams_participants[$team->id]['moves1'] or ''}}"							
												data-first_name1="{{ $teams_participants[$team->id]['first_name1'] or '' }}" 
												data-last_name1="{{ $teams_participants[$team->id]['last_name1'] or '' }}" 
												data-email1="{{ $teams_participants[$team->id]['email1'] or '' }}"												
												
												data-moves2="{{ $teams_participants[$team->id]['moves2'] or '' }}"
												data-first_name2="{{ $teams_participants[$team->id]['first_name2'] or '' }}" 
												data-last_name2="{{ $teams_participants[$team->id]['last_name2'] or '' }}" 
												data-email2="{{ $teams_participants[$team->id]['email2'] or '' }}"
												
												data-moves3="{{ $teams_participants[$team->id]['moves3'] or '' }}"
												data-first_name3="{{ $teams_participants[$team->id]['first_name3'] or '' }}" 
												data-last_name3="{{ $teams_participants[$team->id]['last_name3'] or '' }}" 
												data-email3="{{ $teams_participants[$team->id]['email3'] or '' }}" > 
												
										
												<i class="fa fa-edit"></i> 
													
												@if (App::getLocale() =='fr') 
												<span style="color:#ff0000;"><i>Activez Moves</i></span>
												@elseif (App::getLocale() =='en') 
												<span style="color:#ff0000;"><i>Activate Moves</i></span>
												@endif

													
												</button>
												
												</form>
												
												
											@endif
											</div>
										</td>
										

										
										<td>
										    <form action="{{ url('teams/delete/'.$team->id) }}" method="POST">
												{!! csrf_field() !!}
												{!! method_field('DELETE') !!}
				
												
											@if (App::getLocale() =='fr') 
											<button type="button" class="btn btn-danger  btn-xs" data-toggle="modal" data-target="#confirmDelete__TARGET" data-title="Supppimer l'équipe" data-message="Etes-vous sûr de vouloir supprimer définitivement cette équipe ?">
											<i class="fa fa-trash"></i> Supprimer
											</button>
											@elseif (App::getLocale() =='en') 
											<button type="button" class="btn btn-danger  btn-xs" data-toggle="modal" data-target="#confirmDelete__TARGET" data-title="Delete Team" data-message="Are you sure you want to permanently delete this team?">
											<i class="fa fa-trash"></i> Delete
											</button>
											@endif 
											
											</form>
										</td>
										
										
										
										<td>
											<form action="{{ url('teams/update') }}" method="POST">
										        {!! csrf_field() !!}
										        {!! method_field('PATCH') !!}
												
		
												<button type="button" class="btn btn-success  btn-xs AddEditButton" 																															
												data-toggle="modal"												 
												data-target="#confirmUpdate__TARGET" 
												data-id="{{ $team->id  or ''}}" 
												data-title="{{ $team->title  or ''}}" 
												data-description="{{ $team->description  or ''}}" 
												
												
												data-moves1="{{ $teams_participants[$team->id]['moves1'] or ''}}"							
												data-first_name1="{{ $teams_participants[$team->id]['first_name1'] or '' }}" 
												data-last_name1="{{ $teams_participants[$team->id]['last_name1'] or '' }}" 
												data-email1="{{ $teams_participants[$team->id]['email1'] or '' }}"												
												
												data-moves2="{{ $teams_participants[$team->id]['moves2'] or '' }}"
												data-first_name2="{{ $teams_participants[$team->id]['first_name2'] or '' }}" 
												data-last_name2="{{ $teams_participants[$team->id]['last_name2'] or '' }}" 
												data-email2="{{ $teams_participants[$team->id]['email2'] or '' }}"
												
												data-moves3="{{ $teams_participants[$team->id]['moves3'] or '' }}"
												data-first_name3="{{ $teams_participants[$team->id]['first_name3'] or '' }}" 
												data-last_name3="{{ $teams_participants[$team->id]['last_name3'] or '' }}" 
												data-email3="{{ $teams_participants[$team->id]['email3'] or '' }}" > 
												
										
													<i class="fa fa-edit"></i> 
													
													@if (App::getLocale() =='fr') 
													Modifier 
													@elseif (App::getLocale() =='en') 
													Edit
													@endif 

													
												</button>
											</form>
										</td>
										
									</tr>
								@endforeach
							</tbody>
						</table>
					</div>
				</div>
			@endif
   
	
	
        
        
        
            <div class="panel panel-default">
           

                <div class="panel-body">
					<button type="button" class="btn btn-primary AddEditButton" 
					data-toggle="modal" 
					data-target="#confirmAdd__TARGET"
					
					
					data-first_name1="{{ $participant1_default['first_name1'] or '' }}" 
					data-last_name1="{{ $participant1_default['last_name1'] or '' }}" 
					data-email1="{{ $participant1_default['email1'] or '' }}"	
					
					data-first_name2="" 
					data-last_name2="" 
					data-email2="" 
					
					data-first_name3="" 
					data-last_name3="" 
					data-email3="" 		
					> 
					
						<i class="fa fa-plus-square"></i> {{ trans('wns.Nouvelle équipe') }}
					</button>


				</div>
        
        </div>
    </div>
</div>



<!-- Modal Dialog For Deleting-->
<div class="modal fade" id="confirmDelete__TARGET" role="dialog" aria-labelledby="confirmDeleteLabel" aria-hidden="true">
  <div class="modal-dialog modal-teams">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Supprimer</h4>
      </div>
      <div class="modal-body">
        <p>Are you sure ?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
        <button type="button" class="btn btn-danger" id="confirm">Supprimer</button>
      </div>
    </div>
   
  </div>
</div>







<!-- Modal Dialog For Update-->
<div class="modal fade" id="confirmUpdate__TARGET" class="confirmAdd" role="dialog" aria-labelledby="confirmAddLabel" aria-hidden="true">
  <div class="modal-dialog modal-teams">
    <div class="modal-content">
    
       {!! Form::open(array('url' => 'teams/update','class' => 'confirmTeamForm')) !!}
       
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">
        @if (App::getLocale() =='fr') 
		Modifier 
		@elseif (App::getLocale() =='en') 
		Edit
		@endif
		</h4>
      </div>
      
   
      <div class="modal-body">


				<div class="form-group">
			
					{!! Form::label('title', 'Title *', ['class' => 'control-label']) !!}
					{!! Form::text('title', null, ['class' => 'form-control']) !!}
					
					{!! Form::hidden('id', null,array('id' => 'id')) !!}
					
					
		
                                
				</div>

				<div class="form-group">
					{!! Form::label('description', 'Description', ['class' => 'control-label']) !!}
					{!! Form::textarea('description', null, ['size' => '50x3','class' => 'form-control']) !!}
				</div>	
				
				<div class="form-group">	
					{!! Form::label('title', 'Participant 1 : *', ['class' => 'control-label, team_participant_label']) !!}<span id="moves1"></span><br />
					{!! Form::text('first_name1', null, ['id' => 'first_name1','class' => 'form-control, team_participant_input', 'placeholder' => 'Prénom']) !!}
					{!! Form::text('last_name1', null, ['id' => 'last_name1','class' => 'form-control, team_participant_input', 'placeholder' => 'Nom']) !!}
					{!! Form::text('email1', null, ['id' => 'email1','class' => 'form-control, team_participant_input', 'placeholder' => 'Email']) !!}
					
					{!! Form::label('title', 'Participant 2 :', ['class' => 'control-label, team_participant_label']) !!}<span id="moves2"></span><br />
					{!! Form::text('first_name2', null, ['id' => 'first_name2', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Prénom']) !!}
					{!! Form::text('last_name2', null, ['id' => 'last_name2', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Nom']) !!}
					{!! Form::text('email2', null, ['id' => 'email2', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Email']) !!}
					
					{!! Form::label('title', 'Participant 3 :', ['class' => 'control-label, team_participant_label']) !!}<span id="moves3"></span><br />
					{!! Form::text('first_name3', null, ['id' => 'first_name3', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Prénom']) !!}
					{!! Form::text('last_name3', null, ['id' => 'last_name3', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Nom']) !!}
					{!! Form::text('email3', null, ['id' => 'email3', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Email']) !!}
					
		
		
				
					
				</div>

		
				
      </div>
      <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
              

				{!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
      </div>

      			{!! Form::close() !!}
      			
    </div>
    
    
    			
  </div>
</div>
</div>






<!-- Modal Dialog For Add-->
<div class="modal fade" id="confirmAdd__TARGET" class="confirmAdd" role="dialog" aria-labelledby="confirmAddLabel" aria-hidden="true">
  <div class="modal-dialog  modal-teams">
    <div class="modal-content">
    
       {!! Form::open(array('url' => 'teams/store','class' => 'confirmTeamForm')) !!}
       
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Nouvelle Equipe</h4>
      </div>
      
   
      <div class="modal-body">


				<div class="form-group">  
				
					{!! Form::label('title', 'Titre *', ['class' => 'control-label']) !!}
					{!! Form::text('title', null, ['class' => 'form-control']) !!}
					
	                   
                                     
				</div>

				<div class="form-group">
					{!! Form::label('description', 'Description', ['class' => 'control-label']) !!}
					{!! Form::textarea('description', null, ['size' => '50x2','class' => 'form-control']) !!}
				</div>	
				
				<div class="form-group">
				
					{!! Form::label('title', 'Participant 1 : *', ['class' => 'control-label, team_participant_label']) !!}<br />
					{!! Form::text('first_name1', null, ['id' => 'first_name1', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Prénom']) !!}
					{!! Form::text('last_name1', null, ['id' => 'last_name1', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Nom']) !!}
					{!! Form::text('email1', null, ['id' => 'email1', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Email']) !!}
					
					{!! Form::label('title', 'Participant 2 :', ['class' => 'control-label, team_participant_label']) !!}<br />
					{!! Form::text('first_name2', null, ['id' => 'first_name2', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Prénom']) !!}
					{!! Form::text('last_name2', null, ['id' => 'last_name2', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Nom']) !!}
					{!! Form::text('email2', null, ['id' => 'email2', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Email']) !!}
					
					{!! Form::label('title', 'Participant 3 :', ['class' => 'control-label, team_participant_label']) !!}<br />
					{!! Form::text('first_name3', null, ['id' => 'first_name3', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Prénom']) !!}
					{!! Form::text('last_name3', null, ['id' => 'last_name3', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Nom']) !!}
					{!! Form::text('email3', null, ['id' => 'email3', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Email']) !!}
					
	
	
	
			
			
					
				</div>

		
				
      </div>
      <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
              

				{!! Form::submit('Add New Team', ['class' => 'btn btn-primary']) !!}
      </div>

      			{!! Form::close() !!}
      			
    </div>
    
    
    			
  </div>
</div>
</div>


@endsection


