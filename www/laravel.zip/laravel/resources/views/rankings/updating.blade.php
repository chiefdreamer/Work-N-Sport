@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">INFORMATION</div>

                <div class="panel-body">
                    Le rapport des classements est en cours, merci de réessayer dans 20 minutes.
                </div>
            </div>
        </div>
    </div>
</div>
@endsection


