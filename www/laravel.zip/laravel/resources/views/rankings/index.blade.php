@extends($DEFAULT_VIEW)

@section('content')
<div class="container" style="background-color: #ffffff;">
    <div class="row" style="text-align: center;"> 
        <div>
            <div>
            
            
                <div class="ranking_main">   <div class="trophy"><i class="fa fa-trophy" aria-hidden="true"></i></div>
				{{ trans('wns.CLASSEMENT MONDIAL') }} : {{ $initial_start_date }} - {{ $end_date }}<!--{{ $current_date }}-->
				</div>
				<div>CORPORATE DIVISION: 1</div>


   
				    <div class="container">
					
						<div class="ranking_category">{{ trans('wns.SOCIETES') }}</div>
						<div>
						@foreach ($companies_ranking as $company)
							<div style="clear: both;" class="@if( Auth::id()  == $company->id_user){{"ranking_SELECTED"}}@endif">
							
							@if($company->pts_total>0)
								<div class="ranking_c" style="width:40px;">{{ $company->ranking }}</div>
									
								<div class="ranking_company_main">
								@if (file_exists(public_path('/images/company_logo_'.$company->company_id.'.jpg')))					
									<img alt="{{ $company->company_title }}" title="{{ $company->company_title }}" style="margin: 0 0 0 10px; max-width:150px;" src="{{ asset('/images/company_logo_'.$company->company_id.'.jpg') }}">
								@else
									<span style="margin: 0 0 0 10px;">{{ $company->company_title }}</span>	
								@endif
								</div>
							@else
								<div class="ranking_c" style="width:40px;"></div> 
								
								<div class="ranking_company_main_grey">
								@if (file_exists(public_path('/images/company_logo_'.$company->company_id.'.jpg')))
									<img alt="{{ $company->company_title }}" title="{{ $company->company_title }}" style="margin: 0 0 0 10px; max-width:150px;" src="{{ asset('/images/company_logo_'.$company->company_id.'.jpg') }}">
								@else
									<span style="margin: 0 0 0 10px;">{{ $company->company_title }}</span>
								@endif
								</div>
							@endif
							
							<div class="ranking_points_company">{{ $company->pts_total }} pts </div>
							</div>	
							<hr>					
						@endforeach
						</div>
						
						

						<div style="font-size:11px; color: #c2c2c2;">{{ trans('wns.Les entreprises sans équipes ou en mode « Challenge Privé » ne sont pas inclus dans le classement') }}</div>
					
					
					
						<div class="ranking_category"><b>{{ trans('wns.EQUIPES') }}</div>
						<div>
						@foreach ($teams_ranking as $team)
							<div style="clear: both;" class="@if( Auth::id()  == $team->id_user){{"ranking_SELECTED"}}@endif">
							
						
								
								
								@if($team->pts_total>0)
								<div class="ranking_t" style="width:40px;">{{ $team->ranking }}</div>
								<div class="ranking_team_main">{{ $team->team_title }}
								@else
								<div class="ranking_t" style="width:40px;"></div>
								<div class="ranking_team_main_grey">{{ $team->team_title }}
								@endif
								
								
								<div class="ranking_company">{{ $team->team_company }}</div>
								
								
						
								
								
							</div>
						
							<div  class="ranking_points_team">{{ $team->pts_total }} pts</div>
						
							</div>	
							<hr>						
						@endforeach
						</div>
						
	



					</div>

	
	

            </div>
        </div>
    </div>
</div>
@endsection





