<?php

return [

'privacy' => '

<p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png">Politique de confidentialité</p>

<p>Lorsque vous vous inscrivez sur le site ou l’application mobile, nous recueillons les informations personnelles que vous nous donnez comme votre nom, adresse et adresse e-mail.
</p>

<p>Nous recevons également automatiquement le protocole Internet (IP) l’adresse de votre ordinateur afin de nous fournir des informations qui nous aide à en apprendre d’avantage sur votre navigateur et système d’exploitation.
</p>

<p>Email marketing: Avec votre permission, nous pouvons vous envoyer des courriels au sujet de services, de nouveaux produits et d’autres mises à jour.</p>

<p><a href="http://www.moves-app.com/privacy">Veuillez vous référer également à la politique de confidentialité Moves.</a>
</p>
',

];
