<?php


return [
'tutoriel' => 'Tutoriel Work’N Sport',

'steps' => '
<p>Téléchargez l’application Moves et créez votre profile.</p>

<p>Téléchargez l’application Work’N Sport.</p>

<p>
<b>Etape 1</b> : cliquez sur « <b>Register</b> » et renseignez les champs de « <b>Mon compte</b> ».<br />
<b>Etape 2</b> : créez vos équipes dans « <b>Gérer mes Équipes</b> », en cliquant sur « <b>Nouvelle Equipe</b> ».<br />
<b>Etape 3</b> : chacun de vos participants active l’application Moves, en cliquant sur « <b>Activez Moves</b> ».
</p>


<p>Move More, Play More,</p>

<p>L’équipe de Work’N Sport</p>',

];