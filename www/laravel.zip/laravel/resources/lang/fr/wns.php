<?php

return [
	

	'Non_lucratifs' => 'Work’N Sport',		
	'Non_lucratifs_form' => 'Association à but non lucratif ou groupe gouvernemental',	
	
	
	'La personne clé de votre société qui sera notre interlocutrice.' => 'La personne clé de votre société qui sera notre interlocutrice.',
	'Doublons' => 'Si votre société est déjà inscrite et visible dans les <a href="/rankings">classements</a>, merci de ne pas inscrire de nouveaux comptes. Ils seront supprimés. <b>Merci de ne pas utiliser ce formulaire si vous êtes un participant.</b>',
	'Reg_Société' => 'Société / Organisation',	
	'Reg_Prénom' => 'Prénom',	
	'Reg_Nom' => 'Nom',	
	'Reg_Email' => 'Email',	
	'Reg_Mot de passe' => 'Mot de passe',
	'Reg_Confirmation de mot de passe' => 'Confirmation de mot de passe',

	'Contact_Société' => 'Société / Organisation',	
	'Contact_Prénom' => 'Prénom',	
	'Contact_Nom' => 'Nom',		
	'Contact_Position' => 'Désignation d’emploi',
	'Contact_Email' => 'Email',	
	'Contact_Phone' => 'Téléphone',
	'Contact_Adresse' => 'Adresse',
	'Contact_Ville' => 'Ville',
	'Contact_Postal' => 'Code Postal',
	'Contact_Pays' => 'Pays',
	'Contact_Message' => 'Message',	
		
	
	'Compte' => 'Mon Compte',	
		
	'Société' => 'Société / Organisation',	
	'Prénom' => 'Prénom',	
	'Nom' => 'Nom',	
	'Email' => 'Email',	
	'Téléphone' => 'Téléphone',	
	'Adresse' => 'Adresse',
	'Ville' => 'Ville',
	'Postal' => 'Code Postal',
	'Pays' => 'Pays',
	'Mot de passe' => 'Mot de passe',	
	'Confirmation de mot de passe' => 'Confimation de mot de passe',
	'Je participe aux Corporate Games' => 'Je participe aux Corporate Games',
	'« Challenge Privé ». Votre entreprise et ses participants n’apparaissent plus sur les classements publics' => '« Challenge Privé ». Votre entreprise et ses participants n’apparaissent plus sur les classements publics',
	
	'Email hebdomadaire des classements publics' => 'Email hebdomadaire des classements publics',	
	
	'Votre compte a été sauvegardé.' => 'Votre compte a été sauvegardé.',
	
	
	'MON CLASSEMENT' => 'MON CLASSEMENT',
	'Mon Classement' => 'Mon Classement',
	

	
	'CLASSEMENT MONDIAL' => 'CLASSEMENT MONDIAL',
	'CLASSEMENT MONDIAL CX' => 'CHALLENGE ',
	'Societes / Equipes' => 'CLASSEMENT MONDIAL : Societes / Equipes',
	
	'Les entreprises sans équipes ou en mode « Challenge Privé » ne sont pas inclus dans le classement' => 'Les entreprises sans équipes ou en mode « Challenge Privé » ne sont pas inclus dans le classement',
			
	'Inscriptions' => 'Inscription',
	
	'Moves' => 'Activer Moves',
	
	'Activation' => 'Activer l\'app Moves',
	'Faq' => 'FAQ',
	
	'Aide' => 'Aide',
	'Tutoriel' => 'Tutoriel',
	'brochure' => 'worknsport_brochure_fr',
	
	'Video' => 'Vidéo',
	'Video_URL' => 'm__IIf2V2MI',
	
	
	
	'Equipes / Participants' => 'Gérer mes Equipes',
	'Equipes' => 'Equipes',
	'Nouvelle équipe' => 'Nouvelle Equipe',
	
	'CLASSEMENTS' => 'CLASSEMENTS',
	'SOCIETES' => 'SOCIETES',
	'EQUIPES' => 'EQUIPES',
	
	'STEP1' => 'Inscrivez vos collaborateurs sur le site',
	'STEP2' => 'Télécharger les deux applications gratuites Work’N Sport et Moves',
	'STEP3' => 'Encouragez vos collaborateurs à pratiquer une activité physique et sportive',

	
    'Inscriptions et le paiement se font en ligne directement.' => 'Les Inscriptions et le paiement se font en ligne directement. Si vous souhaitez utiliser un autre mode de paiement, contactez-nous.',
     
    'Inscriptions_info_team' => 'Les équipes sont constituées de 3 personnes. ',
 

    
     'Inscriptions_info' => ' En 2016, le premier mois d’inscription est offert. A partir du 2ème mois, les frais d’inscription par participant sont fixés suivant le barème ci-dessous. Ces frais peuvent être pris en charge par le participant lui-même, par son entreprise ou le comité d’entreprise. Les inscriptions et le paiement se font en ligne directement. Lors de votre inscription vous choisissez et payez la durée de votre inscription.',
 
  	'Nombre d’équipes inscrites au sein de votre entreprise.' => 'Nombre d’équipes inscrites au sein de votre entreprise.',
  	'Prix HT en € par participant et par mois (si paiement mensuel)' => 'Prix HT en € par participant et par mois (si paiement mensuel)',
  	'Prix HT en € par participant pour l’année 2016 (si paiement annuel pour la période du 1er mai 2016 au 31 décembre 2016)' => 'Prix HT en € par participant pour l’année 2016 (si paiement annuel pour la période du 1er mai 2016 au 31 décembre 2016)',
  	'Prix HT en € par participant pour l’année 2017 (si paiement annuel)' => 'Prix HT en € par participant pour l’année 2017 (si paiement annuel)',
  	'Prix HT en € par participant pour l’année 2017 (si paiement annuel et participant Corporate Games)' => 'Prix HT en € par participant pour les années 2016-2017 (si paiement annuel et vous avez participé ou vous aller participer a un événement Corporate Games en France)',
	'Jusqu’à' => 'Jusqu’à',
  	'Plus de' => 'Plus de',
  	'Merci de nous contacter' => 'Merci de nous contacter',
  	'Paiement par carte bancaire' => 'Paiement par carte bancaire',
  	'1,9' => '1,9',
  	'1,8' => '1,8',
  	
  	  	
  	
	'WORK’N SPORT' => 'WORK’N SPORT',
	'INSCRIPTIONS' => 'TARIFS',
	'CONTACT' => 'CONTACT',
	'QUESTIONS FRÉQUENTES' => 'QUESTIONS FRÉQUENTES',
  	'Conditions d’utilisation' => 'Conditions d’utilisation',
  	'Politique de confidentialité' => 'Politique de confidentialité',
  	
  	'ACTIVATION_SUB' => 'Activez l\'app Moves',
  	
  	'INSCRIPTIONS_SUB' => 'Tarifs / Paiements',
  	
  	'FACTURES_SUB' => 'Factures',
  	
  	'invoices_title' => 'Facture',
  	'invoices_product' => 'Inscription',
  	'invoices_participants' => 'Participants',
  	'invoices_total' => 'Total HT',
  	'invoices_none' => 'Aucune facture disponible.',
  	
  	
  	'wns_apps' => 'Work’N Sport est disponible via notre site internet ou notre application Android. Notre application iPhone sera bientôt disponible.',
  	
  	'wns_trademark' => '&reg; Work’N Sport est une marque déposée de QYD Cathay',
  	
  	'Partenaire Stratégique' => 'Partenaire Stratégique',
  
];




