<?php

return [





'terms' => '

<p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png">Conditions d’utilisation</p>

<p class="terms_title">Conditions d’utilisation à compter du 1er janvier 2016</p>

<p>Work’N Sport est la propriété exclusive de QYD Cathay, 6C Impasse des Michaudes 74940 Annecy le Vieux –
France. Work’N Sport est une marque déposée appartenant à QYD Cathay.</p>

<p class="terms_subtitle">1. Work’N Sport - Introduction.</p>
<p>La présente réglementation fait référence aux conditions d’utilisation applicables à tous les participants de
Work’N Sport.</p>

<p class="terms_subtitle">2. Droit du participant au challenge Work’N Sport.</p>
<p>En s’inscrivant à Work’N Sport, le participant autorise QYD Cathay et Work’N Sport à :<br />
• Accéder aux performances sportives du participant enregistrées sur l’application Moves ou sur toute autre
application sportive connectée au site de Work’N Sport.<br />
• Publier les résultats des activités sportives dans le cadre de Work’N Sport sur l’application et le site
www.workn-sport.com grâce à des classements individuels, par équipe et par entreprise, au niveau national et
mondial.<br />
• Envoyer des mails au participant concernant Work’N Sport et ses partenaires sauf si la personne a coché la
case « Pas d’email ».<br />
• Enlever des points à un participant si celui-ci a enregistré des activités physiques avec des informations erronées
évidentes. Face à un tel problème, les parties concernées tenteront d’abord de trouver un compromis.
</p>

<p class="terms_subtitle">3. Accès internet.</p>
<p>Pour participer à Work’N Sport, les participants doivent avoir une connexion internet qui fonctionne ainsi qu’une
adresse mail valide. Le coût d’accès à Internet et le coût de trafic des données sont à la charge du participant.</p>

<p class="terms_subtitle">4. Marque et application Work’N Sport.</p>
<p>La marque et l’application Work’N Sport sont détenues exclusivement par QYD Cathay. Il est interdit d’utiliser la
marque et l’application Work’n Sport à d’autres fins que la participation au challenge. Le participant ne doit pas :<br />
• Utiliser la marque d’une autre façon que celle décrite par les conditions d’utilisation.<br />
• Transmettre ses informations personnelles et ses codes d’accès à des tiers.<br />
• Détourner les moyens technologiques et techniques mis en oeuvre par le service afin d’éviter tout reproduction
et/ou commercialisation de ce service.<br />
• Utiliser ce service dans un cadre contraire à celui évoqué par cette règlementation.<br />
<p>QYD Cathay se réserve le droit de bloquer ou fermer l’accès d’un participant à Work’N Sport si celui-ci n’utilise
pas le service correctement ou ne respecte pas la présente réglementation.</p>

<p class="terms_subtitle">5. Traitement des données personnelles des participants.</p>
<p>En s’inscrivant à Work’N Sport, le participant accepte cette règlementation et permet à Work’N Sport et à QYD
Cathay de stocker ses informations personnelles. Ces renseignements sont gardés en accord avec la règlementation
française en vigueur sur le stockage des données. Work’N Sport et QYD Cathay ne peuvent pas vendre ces
données à un tiers. Ces informations seront uniquement utilisées dans le cadre de la compétition pour gérer les
accès du participant à la compétition et pour permettre une perpétuelle amélioration du service et de Work’N
Sport.<br />
Le participant accepte que ses informations concernant ses performances sportives (niveaux, résultats, points
accumulés, participation aux challenges…) soient publiées dans le cadre de classements de Work’N Sport.</p>

<p class="terms_subtitle">6. Informations concernant Work’N Sport.</p>
<p>Le participant accepte que Work’N Sport lui envoie des informations pertinentes concernant la compétition, des
offres des partenaires par email, par sms et/ou par des messages push ou notifications.</p>

<p class="terms_subtitle">7. Clause de non-responsabilité.</p>
<p>Work’N Sport vous est proposé dans sa version à date et QYD Cathay ne garantit aucunement que les informations,
contenus, produits et services proposés sont parfaitement corrects. QYD Cathay fera tout son possible
pour améliorer le système grâce notamment aux enquêtes de satisfaction demandées aux participants et à leur
retour sur leur expérience.<br />
QYD Cathay n’est pas responsable en cas de blessures ou autre dommage d’un participant au cours de l’une de
ses activités physiques.<br />
QYD Cathay se réserve le droit de modifier en permanence et de développer le service commercialisé sous le
nom de Work’N Sport. QYD Cathay pourra être uniquement tenu responsable pour le montant payé par le participant
pour le service actuel. Les légers dysfonctionnements techniques doivent être considérés comme inhérents
au système ne pourront donc en aucun cas être avancés comme des motifs de rupture de contrat.
Sur les forums de partage pour les participants ou les plateformes sociales connectés à Work’N Sport, les participants
s’engagent à ne pas tenir ou écrire de propos illégaux, insultants, racistes, menaçants, obscènes, homophobes
ou plus généralement de propos contraires à la loi.<br />
Les participants s’engagent également à ne pas recourir au forum à des fins commerciales. Par exemple, le participant
ne peut pas y faire de publicité pour un produit ou un service.</p>

<p class="terms_subtitle">8. Désaccord / Conflit.</p>
<p>En cas de désaccord ou de conflit entre un participant et QYD Cathay, les parties concernées tâcheront d’abord
de trouver un compromis. Si le désaccord persiste, la société QYD Cathay se réserve le droit d’amener l’affaire en
justice, au tribunal de commerce d’Annecy, France. Le présent contrat est régi sous loi française.

<p class="terms_subtitle">9. Changement des conditions d’utilisation</p>
<p>QYD Cathay se réserve le droit de changer les conditions d’utilisation en cas de besoin. Les participants seront tenus informés des éventuelles modifications au niveau des conditions d’utilisation soit par email soit via la plateforme en ligne de discussion du service.</p>





',

];
