<?php

return [



'faq' => 

'<p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png">Questions Fréquentes</p>

<p class="terms_subtitle">• Combien de personnes ou d’équipes puis-je inscrire ?</p>
<p>Toute entité peut inscrire autant d’équipes qu’elle le souhaite. Une équipe est composée de 3 personnes obligatoirement.</p>

<p class="terms_subtitle">• Quand se déroulent les compétitions ?</p>
<p>Il y a quatre périodes de compétition par an. La première période va du 1er janvier jusqu’au 31 mars. Le second
challenge court lui du 1er avril au 30 juin. La troisième période de compétition a lieu du 1er juillet au 30 septembre.
Enfin, la dernière période se déroule du 1er octobre au 31 décembre. Il y aura des gagnants à chaque
fin de période et un classement annuel sera aussi calculé en tenant compte des 4 challenges.</p>

<p class="terms_subtitle">• Comment sont calculés les points ?</p>
<p>Les points sont calculés en fonction du nombre de calories consommées, enregistrées via l’application Moves et
consolidées sur Work’N Sport. Chaque calorie brûlée vaut 1 point. Chaque participant rapporte des points à son
équipe. Le total de points pour une équipe est donc la somme des points rapportés par chaque collaborateur de
l’équipe. Pour les points d’une entreprise, il suffit de faire la somme des points de chaque équipe. Plus vous avez
de participants et plus ils font du sport, plus vous avez de chances de remporter la compétition !</p>

<p class="terms_subtitle">• Puis-je utiliser n’importe quelle application sportive pour participer au challenge ?</p>
<p>Pour le moment, vous ne pouvez utiliser que l’application Moves que vous pouvez télécharger gratuitement en
cliquant ici <a href="https://www.moves-app.com">https://www.moves-app.com</a></p>

<p class="terms_subtitle">• Comment m’inscrire et commencer à relever le défi ?</p>
<p>D’abord, inscrivez-vous sur notre site Internet et remplissez vos informations personnelles nécessaires à votre
inscription et réglez votre inscription. Enfin, vous devez autoriser l’accès de Work’N Sport à vos données de l’application Moves. C’est bon, vous pouvez maintenant accéder à votre profil pour le Challenge ainsi qu’aux pages
vous permettant de voir l’ensemble des classements des compétitions.</p>

<p class="terms_subtitle">• Dois-je payer pour télécharger l’application Moves ?</p>
<p>Non, cette application est entièrement gratuite et vous pouvez dès à présent la télécharger sur 
<a href="https://www.moves-app.com">https://www.moves-app.com</a></p>

<p class="terms_subtitle">• Mon entreprise a-t-elle accès à mes données personnelles ?</p>
<p>Non, votre entreprise n’a pas accès à vos données personnelles qui restent confidentielles.
</p>

<p class="terms_subtitle">• Comment mon entreprise peut-elle gagner le Challenge ?</p>
<p>Pour gagner l’une des quatre compétitions organisées pendant l’année, une entreprise doit accumuler le plus
grand nombre de points. Ses points sont calculés grâce au nombre total de calories brûlées par chacune de ses
équipes.</p>

<p class="terms_subtitle">• Doit-on participer à toutes les compétitions tout au long de l’année?</p>
<p>Une équipe peut participer à une, deux, trois ou quatre compétitions car il y a un classement par compétition.
Un classement annuel est aussi établi sur la base des quatre compétitions trimestrielles.</p>

<p>• Comment sont déterminées les divisions sportives ?</p>
<p>La division sportive dans laquelle concourt votre société dépend du nombre total de collaborateurs de votre entreprise inscrits à Work’N Sport. Les 8 divisions possibles sont les suivantes :<br />
- Division 1 : de 1 à 9 équipes inscrites<br />
- Division 2 : de 10 à 19 équipes inscrites<br />
- Division 3 : de 20 à 39 équipes inscrites<br />
- Division 4 : de 40 à 59 équipes inscrites<br />
- Division 5 : de 60 à 89 équipes inscrites<br />
- Division 6 : de 90 à 139 équipes inscrites<br />
- Division 7 : de 140 à 299 équipes inscrites<br />
- Division 8 : plus de 300 équipes inscrites</p>

<p class="terms_subtitle">• Qui paye l’inscription ?</p>
<p>Le paiement peut être réalisé soit par les participants eux-mêmes, soit par l’entreprise à laquelle appartient
l’équipe ou encore par l’un des membres de l’équipe. Le moyen de transaction accepté est le paiement en ligne
grâce à une carte bancaire s’il n’y a qu’une seule équipe à payer. Quand une entreprise règle l’inscription de plusieurs équipes, elle peut effectuer le paiement par virement bancaire.</p>

<p class="terms_subtitle">• Quel est le prix pour participer ?</p>
<p>Le premier mois de participation est offert, sous réserve que chaque participant transfère un email de présentation de Work’N Sport à 3 amis. A partir du 2ème mois, les tarifs d’inscription sont les suivants : <a href="/subscribe">Tarifs Work’N Sport.</a>
</p>






<p class="terms_subtitle">• Dois-je payer la TVA ou puis-je la récupérer ?</p>
<p>Work’N Sport est organisé et détenu par la SASU française QYD Cathay, située au 6C impasse des Michaudes
74940 Annecy-le-Vieux.<br />
Les personnes morales ayant leur siège social en France paieront la TVA française.<br />
Les personnes morales ayant leur siège social en-dehors de la France seront facturées hors taxes.<br />
Les personnes physiques ayant leur résidence fiscale en France ou dans l’un des pays de la communauté européenne
devront payer la TVA au taux de leur pays de résidence.<br />
Les personnes physiques ayant leur résidence fiscale en dehors de la communauté européenne seront exonérées
de TVA.</p>

<p class="terms_subtitle">• Comment vérifiez-vous qu’un participant appartient bien à une entreprise ?</p>
<p>Nous faisons confiance à nos participants et partons du principe qu’ils s’inscrivent bien sous le nom de l’entreprisepour laquelle ils travaillent. Etant donné le nombre important de participants, nous ne pouvons pas vérifierla véracité de cette information pour chaque participant. Néanmoins, si une entreprise nous demande officiellement de retirer une équipe qui ne devrait pas concourir sous son nom, nous procèderons à la suppression de cette équipe après vérification et nous ne rembourserons pas les frais engagés par cette équipe.</p>

<p class="terms_subtitle">• Puis-je annuler mon inscription ?</p>
<p>Une fois que vous avez choisi et payé le nombre de mois pendant lesquels vous souhaitez participer à Work’N
Sport, vous ne pouvez pas récupérer les sommes payées. Votre inscription s’arrête automatiquement après expiration
du nombre de mois payés.</p>

<p class="terms_subtitle">• Que se passe-t-il s’il y a problème au niveau de Work’N Sport ou de l’application Moves pendant quelques temps ?</p><p>Si le Challenge ou l’application rencontrent un problème temporaire, cela concernera tous les participants en
même temps donc la compétition restera juste pour tous. Ni remise ni remboursement ne pourront être réclamés
par les participants.</p>

<p class="terms_subtitle">• Que dois-je faire si je rencontre un quelconque problème (connexion, utilisation ou autre) avec l’application Moves ou avec Work’N Sport ?</p>
<p>En cas de problème avec le site de Work’N Sport, merci d’envoyer un mail à : info@worknsport.com .<br />
Si le problème concerne l’application Moves, merci de bien vouloir contacter directement le service de l’application sur  <a href="https://www.moves-app.com">https://www.moves-app.com</a>.</p>

'
];
