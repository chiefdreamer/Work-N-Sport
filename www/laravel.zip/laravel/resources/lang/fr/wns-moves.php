<?php

return [


'moves_activation_ajouter' => 'Ajouter des Equipes et participants',
'moves_activation_select' => 'Veuillez sélectionner un participant',
'moves_activation_code' => 'OBTENIR LE CODE',
'moves_activation_etape1' => 'LE PARTICIPANT INSTALLE MOVES SUR IOS OU ANDROID',
'moves_activation_etape2' => 'LE PARTICIPANT SAISIT <b>LE CODE</b> SUR SON SMARTPHONE (App Connectée > Enter PIN/CODE)',
'moves_activation_etape3' => 'ATTENDRE LA PAGE ACTIVATION COMPLETEE',
'moves_activation_etape4' => 'Important:  Le Code perd sa validité après écoulement d’un délai de cinq minutes.',


'Activez Moves' => 'Activez Moves',
'Envoyez l’activation par email' => 'Envoyez l’activation par email',
'L’adresse email doit être déjà renseignée dans une équipe.' =>'L’adresse email doit être déjà renseignée dans une équipe.',
                                
'Tester mon activation Moves.' => 'Tester mon activation Moves.',

	
'ACTIVATION COMPLETEE' => 'ACTIVATION COMPLETEE',	


'faq' => '<h1>Questions fréquentes</h1>

<h3>Comment fonctionne Moves ?</h3>

<p>Moves utilise le capteur et la géolocalisation de votre iPhone pour reconnaître vos activités, vos trajets et vos lieux. Les données sont sauvegardées sur nos serveurs qui réalisent alors un processus complexe pour vous donner vos statistiques quotidiennes et votre évolution.</p>

<h3>Où dois-je placer mon iPhone pour que Moves fonctionne correctement</h3>

<p>Moves marche quand votre iPhone se trouve dans votre poche, votre sac, votre portemonnaie, votre main ou dans votre brassard- le principal étant que vous ayez votre iPhone sur vous. L’application ne peut pas enregistrer vos données si vous marchez, courez ou roulez en laissant votre iPhone chez vous :).</p>

<h3>Quelles sont les activités reconnues par Moves ?</h3>

<p>Moves reconnaît la marche, le vélo, la course à pied. L’application reconnaît aussi tous les trajets motorisés comme dans les transports par exemple. Pour le moment, les autres activités ne sont pas détectées mais nous y travaillons.</p>

<h3>Quel est le degré de précision du podomètre ?</h3>

<p>Moves enregistre les pas à partir du moment où vous marchez ou courez de façon continue. La précision est bonne pour suivre quotidiennement les changements au niveau de votre activité physique ou pour comparer les pas comptabilisés par rapport à votre objectif du jour. Afin de garder de la batterie, les très courtes marches (durant moins de 30 secondes) ne sont pas toujours enregistrées. Si vous avez un trajet en voiture ou en train quelque peu agité et que vous voyez vos pas augmentés sur l’application, ne vous inquiétez pas : ils peuvent être déduits du total journalier de pas effectués quand les données sont analysées plus en détails (contrairement à d’autres podomètres et gadgets). </p>

<h3>Est-ce que Moves reconnaît la marche ou la course sur tapis roulant ? </h3>

<p>Si vous avez votre iPhone sur vous, l’application enregistrera les données. Toutefois, le calcul de la distance est moins précis et nous cherchons à améliorer cela pour la suite. </p>

<h3>Comment l’application fonctionne-t-elle en arrière-plan ?</h3>

<p>L’application enregistre automatiquement votre activité en arrière-plan. Si vous la retirez de votre liste des applications récentes (en double cliquant sur le bouton d’accueil), Moves s’arrêtera pour un moment mais redémarrera automatiquement quand vous vous trouverez dans un nouvel endroit. </p>

<h3>Comment puis-je sauvegarder/transférer mes données à un autre iPhone ? </h3>

<p>Créez un compte gratuitement sur l’application en renseignant une adresse mail et un mot de passe. Quand vous utiliserez Moves avec un autre iPhone pour la première fois, connectez-vous avec ce compte soit au niveau de l’écran de démarrage soit en allant dans Paramètres > Compte. </p>

<h3>Puis-je arrêter l’application ?</h3>

<p>Oui vous pouvez via les paramètres de l’application (Tracking). Cependant, nous pensons que vous exploiterez vraiment toutes les possibilités de l’application si vous enregistrez quotidiennement vos activités physiques.</p>

<h3>Pourquoi n’est-il pas possible d’utiliser la fonction podomètre ou la reconnaissance d’activité physique sans utiliser la géolocalisation ?</h3>

<p>Sur iPhone, il n’est pas possible de collecter des données du capteur en arrière-plan sans recourir à la géolocalisation. De plus, sans cela, la reconnaissance de l’activité serait moins fiable et les lieux ne pourraient pas être reconnus sans cette géolocalisation. </p>

<h3>Est-ce que le GPS doit-être tout le temps allumé ? </h3>

<p>Non. Le GPS n’est pas utilisé quand le téléphone ne bouge pas et il est juste utilisé occasionnellement pour détecter la vitesse des mouvements et les parcours empruntés. A noter que l’icône représentant une flèche dans la barre de statut ne veut pas forcément dire que le GPS est activé. Cela indique juste que la géolocalisation est activée. </p>

<h3>L’application Moves utilise-t-elle beaucoup de batterie ?</h3>

<p>L’application fonctionne en permanence en arrière-plan, ce qui consomme inévitablement de la batterie. Notre objectif a été de créer une application qui permet à votre téléphone de fonctionner sans problème toute une journée et de devoir ne le charger que le soir.  Lors des tests, nous avions atteint cet objectif mais ces résultats peuvent varier d’un téléphone à l’autre. En effet, plusieurs facteurs peuvent affecter l’utilisation de la batterie et c’est un point que nous sommes perpétuellement en train d’optimiser.</p>

<h3>Pourquoi Moves n’identifie pas correctement certains lieux ou activités ?</h3>

 <p>Moves est basé sur des algorithmes de pointe pour la détection d’activités et de géolocalisation, mais des dysfonctionnements peuvent arriver. Vous pouvez facilement les corriger en cliquant sur la partie incorrecte de votre évolution du jour et en en tapant ensuite sur l’icône du crayon. L’application se perfectionne au fur et à mesure donc toute correction apportée dans un premier temps améliorera l’application dans le futur. </p>

<h3>Est-ce que Moves fonctionne à l’étranger lorsque la connexion Internet depuis l’étranger est désactivée ?</h3>

<p>Moves peut collecter des données sans connexion internet et ces dernières seront analysées dès que vous aurez de nouveau accès à Internet. Néanmoins, si vous voyagez dans un nouveau pays et que vous n’avez pas de connexion à vos données, la géolocalisation de votre téléphone sera moins fiable tant que vous n’aurez pas établi une connexion au réseau. Ainsi, vous connecter au moins une fois par jour à un point Wifi permet au téléphone de mieux faire son travail de géolocalisation.</p>

<h3>Qui peut accéder à mes données ?</h3>

<p>Voir notre <a href="http://www.moves-app.com/privacy">Politique de confidentialité</a>.</p>

<h3>Y a-t-il un API (Application Programming Interface) ? </h3>

<p>Oui ! Pour en savoir davantage : <a href="https://dev.moves-app.com">Moves Developer Site</a>.</p>

<h3>Puis-je exporter mes données ?</h3>

<p>Si vous êtes connaisseur en informatique, vous pouvez utiliser <a href="https://dev.moves-app.com">l’API</a> pour exporter vos données. Nous prévoyons de faciliter cet export de données par la suite et ainsi rendre la manipulation accessible à tous. </p>

<h3>Qui détient Moves ? </h3>

<p>
Moves est développée et gérée par ProtoGeo Oy. Nous sommes une équipe de 8 personnes menées par notre PDG et Designer Sampo KARJALAINEN et réparties entre Helsinki (Finlande), Londres (Royaume-Uni) et Pittsburgh (Etats-Unis). ProtoGeo a reçu des fonds pour ces investissements de <a href="http://www.lifelineventures.com">Lifeline Ventures</a>, <a href="http://www.profounderscapital.com">PROfounders</a>, de business angels et <a href="http://www.tekes.fi">Tekes</a>. Pour entrer en contact avec l’équipe, écrire à <a href="mailto:sampo@protogeo.com">contact Sampo</a>.</p>

<h3>Existe-t-il une version pour Androïd ? </h3>

<p>Oui, allez voir sur la <a href="http://moves-app.com">page d’accueil de Moves</a>.</p>

<h3>Comment puis-je donner mon avis ? </h3>

<p>Nous vous recommandons d’utiliser la fonction Avis dédiée à cela dans l’application. Vous pouvez aussi nous envoyer votre retour par mail à : <a href="mailto:feedback@moves-app.com">feedback@moves-app.com</a></p>
',

];
