<?php

return [





'faq' => 


'<p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png">Frequently Asked Questions</p>


<p class="terms_subtitle">• How many people or teams can I register?</p>
<p>A company or any kind of organization can register as many teams as it wants. Each team shall be composed of
3 people.</p>

<p class="terms_subtitle">• When do the challenges take place?</p>
<p>There are 4 challenges per year. The first challenge runs from 1st of January till end of March, the second
challenge runs from first of April till the end of June. The third one runs from 1st of July till end of September and
the last Challenge from 1st of October till end of December. There will be winners per challenge and a yearly
winner, taking into account rankings from all 4 challenges.</p>

<p class="terms_subtitle">• How are the points calculated?</p>
<p>Points are calculated on consumed calories, registered in your Moves App and transferred to Work’N Sport. One
calorie equals one point. Each team member collects points. The team’s points are the addition of each
member’s points. The company’s points are the sum of all teams’ points. The more people you register and the
more they practice sports, the more chances you have to win the challenge.</p>

<p>• Can I use all connected sport Apps?</p>
<p>For the time being, you can only use Moves App, that you can download from free by clicking here
<a href="https://www.moves-app.com">https://www.moves-app.com</a></p>

<p class="terms_subtitle">• How can I register and get started?</p>
<p>First, register on our website, fill in your contact details and fulfill payment. Then, you have to allow access to the
Moves App installed on your smartphone. You can now access your personal Work’N Sport page that will display
the dashboard of all your sport activities as well as all competitions’ rankings.</p>

<p class="terms_subtitle">• Is the Moves App free to download?</p>
<p>Yes, it is. You can download it from <a href="https://www.moves-app.com">https://www.moves-app.com</a>.</p>

<p class="terms_subtitle">• Will my company have access to my personal data?</p>
<p>No, your company will not have access to your personal data which are confidential and we ensure to respect
this privacy.
</p>

<p class="terms_subtitle">• How can my company win the challenge?</p>
<p>To win any challenge, your company has to get the highest number of points. Points are calculated on the total consumed calories from all teams of the company.</p>

<p class="terms_subtitle">• Do we have to participate to all challenges?</p>
<p>A team can participate to one, two, three and/or four challenges since there is a ranking per challenge and a yearly ranking for the 4 challenges.</p>


<p class="terms_subtitle">• How are the divisions defined ?</p>
<p>Your corporate division will depend on the number of teams your company will register to the Work’N Sport challenge. There are 8 divisions as follow:<br />
- Division 1: from 1 to 9 teams<br />
- Division 2: from 10 to 19 teams<br />
- Division 3: from 20 to 39 teams<br />
- Division 4: from 40 to 59 teams<br />
- Division 5: from 60 to 89 teams<br />
- Division 6: from 90 to 139 teams<br />
- Division 7: from 140 to 299 teams<br />
- Division 8: over 300 teams</p>

<p class="terms_subtitle">• Who can pay for the registration fees?</p>
<p>Payment can be done by the team members, the company or their works council. The means of transaction
which is accepted is the online payment thanks to a credit card. When a company pays for various teams, it can
realize a bank transfer.</p>

<p class="terms_subtitle">• What are the registration fees?</p>
<p>In 2016, the first month of participation is offered. To register, participants will just to have to inform 3 friends about Work’N Sport. From the 2nd month, participants will be charged as follows <a href="/subscribe">Work’N Sport Pricing.</a>
</p>




<p class="terms_subtitle">• Do I have to pay VAT or how can I get it back?</p>
<p>Work’N Sport – the Corporate Connected Sport Challenge is powered by the French Limited Company QYD
Cathay, located 6C Impasse des Michaudes, 74940 Annecy-le-Vieux, France. French companies can get back VAT
normally. Non-European Community companies will be invoiced without VAT and thus do not need to pay nor to
get it back. European Companies will be charged their own local VAT and can claim it back to their own authorities.</p>

<p class="terms_subtitle">• How do you check that a participant well belongs to a company?</p>
<p>We trust that people who register under a company name effectively works for this company. Due to the large number of participants, we cannot check this point. Nonetheless, if a company officially asks us to eliminate a team who does not belong to its company, we will eliminate this team after verification and we will not reimburse the team whose team members did not have the right to participate to Work’N Sport.</p>

<p class="terms_subtitle">• Can I cancel my registration?</p>
<p>You can stop participating to the challenge Work’N Sport at any time but registration fees cannot be reimbursed.
</p>

<p class="terms_subtitle">• What happens if Work’N Sport or the Moves App do not work for a few days?</p>
<p>If the Challenge or the app do not work, it will impact at the same time all participants so the competition willremain fair for all. No discounts nor reimbursement can be claimed.
</p>

<p class="terms_subtitle">• What do I do if I encounter problems to register or use the Work’N Sport website or the Moves App or anything else?</p>
<p>If you encounter problems by using the Work’N Sport-CCSC website, please contact us by email at:
info@worknsport.com or by phone at: +33 674119757.
If you face problems by using the Moves App, please contact Moves App at <a href="https://www.moves-app.com">https://www.moves-app.com</a>.</p>

',

];


