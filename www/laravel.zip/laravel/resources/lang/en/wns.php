<?php


return [

	'Non_lucratifs' => 'Work’N Sport',	
	'Non_lucratifs_form' => 'Non-profit or government agency',	
	
	'La personne clé de votre société qui sera notre interlocutrice.' => 'The key person from your company that will be our main contact person.',
	'Doublons' => 'If your company is already registered and listed in the <a href="/rankings">rankings</a>, please do not register any new accounts. They will be deleted. <b>Please do not use this form if you are a participant.</b>',
	'Reg_Société' => 'Company / Organisation',	
	'Reg_Prénom' => 'First name',	
	'Reg_Nom' => 'Last name',	
	'Reg_Email' => 'Email',	
	'Reg_Mot de passe' => 'Password',
	'Reg_Confirmation de mot de passe' => 'Password confirmation',

	'Contact_Société' => 'Company / Organisation',	
	'Contact_Prénom' => 'First name',	
	'Contact_Nom' => 'Last name',		
	'Contact_Position' => 'Job title',
	'Contact_Email' => 'Email',	
	'Contact_Phone' => 'Telephone',
	'Contact_Adresse' => 'Address',
	'Contact_Ville' => 'City',
	'Contact_Postal' => 'Postcode',
	'Contact_Pays' => 'Country',
	'Contact_Message' => 'Message',

		
	
	'Compte' => 'My Account',
	
	'Société' => 'Company / Organisation',	
	'Prénom' => 'First name',	
	'Nom' => 'Last name',	
	'Email' => 'Email',	
	'Téléphone' => 'Telephone',
	'Adresse' => 'Address',
	'Ville' => 'City',
	'Postal' => 'Postcode',
	'Pays' => 'Country',	
	'Mot de passe' => 'Password',	
	'Confirmation de mot de passe' => 'Password confirmation',
	'Je participe aux Corporate Games' => 'I participate in the Corporate Games',
	'« Challenge Privé ». Votre entreprise et ses participants n’apparaissent plus sur les classements publics' => '"Private Challenge". Your company’s participants will not be listed in the public rankings',
	
	'Email hebdomadaire des classements publics' => 'Weekly email of public rankings',	
	 

	'Votre compte a été sauvegardé.' => 'Your account has been saved.',
	
	
	'MON CLASSEMENT' => 'MY RANKINGS',
	'Mon Classement' => 'My Rankings',
	
	
	'CLASSEMENT MONDIAL' => 'WORLD RANKINGS',
	'CLASSEMENT MONDIAL CX' => 'CHALLENGE 1',
	'Societes / Equipes' => 'WORLD RANKINGS: Companies / Teams', 
	
	'Les entreprises sans équipes ou en mode « Challenge Privé » ne sont pas inclus dans le classement' => 'Companies with no teams or set as "Private Challenge" are not included in the rankings',


	'Inscriptions' => 'Register',
	
	'Moves' => 'Activate Moves',
	
	'Activation' => 'Activate Moves App',
	'Faq' => 'FAQ',
	
	'Aide' => 'help',
	'Tutoriel' => 'Tutorial',
	'brochure' => 'worknsport_brochure_gb',
	
	'Video' => 'Video',
	'Video_URL' => 'sCQ_13IEKyk',
	
	
	'Equipes / Participants' => 'Manage my Teams',
	'Equipes' => 'Teams',
	'Nouvelle équipe' => 'New Team',
	
	
	
	'CLASSEMENTS' => 'RANKINGS',
	'SOCIETES' => 'COMPANIES',
	'EQUIPES' => 'TEAMS',
		
	'STEP1' => 'your collaborators on our website',
	'STEP2' => 'Download the two free Apps Work’N Sport and Moves',
	'STEP3' => 'Encourage your collaborators to practice a physical and sporting activity',


	
    'Inscriptions et le paiement se font en ligne directement.' => 'Subscriptions and payments are completed online. Please contact us for alternative payment options.',  
    
    'Inscriptions_info_team' => 'The teams are comprised of 3 participants. ',
    
    'Inscriptions_info' => 'In 2016, the first month of subscription is free. From the 2nd month the subscription fees per participant is set according to the pricing below. These fees can be paid by the participant himself, his company or the works council. Subscription and payment are made directly online. When you Subscribe you choose and pay for the duration of your subscription.',
    
    
  	'Nombre d’équipes inscrites au sein de votre entreprise.' => 'Number of teams subscribed in your company.',
	'Prix HT en € par participant et par mois (si paiement mensuel)' => 'Price ex-tax per participant and per month (if paid monthly)',
  	'Prix HT en € par participant pour l’année 2016 (si paiement annuel pour la période du 1er mai 2016 au 31 décembre 2016)' => 'Price ex-tax in € per participant for the year 2017 (if paid annually from 1st May 2016 to 31 December 2016)',
  	'Prix HT en € par participant pour l’année 2017 (si paiement annuel)' => 'Price ex-tax in € per participant for the year 2017 (if paid annually)',
  	'Prix HT en € par participant pour l’année 2017 (si paiement annuel et participant Corporate Games)' => 'Price ex-tax in € per participant for the years 2016 to 2017 (if paid annually and you participated in, or will participate in a Corporate Games Event in France )',
	'Jusqu’à' => 'Up to',
  	'Plus de' => 'More than',
  	'Merci de nous contacter' => 'Please contact us',
  	'Paiement par carte bancaire' => 'Payment by credit card',
  	 '1,9' => '1.9',
  	'1,8' => '1.8',
  	
  	
  	
	'WORK’N SPORT' => 'WORK’N SPORT',
	'INSCRIPTIONS' => 'PRICING',
	'CONTACT' => 'CONTACT',
	'QUESTIONS FRÉQUENTES' => 'FAQ',
	'Conditions d’utilisation' => 'Terms of use',
	'Politique de confidentialité' => 'Privacy policy',
	
  	'ACTIVATION_SUB' => 'Activate Moves App',
  	
  	'INSCRIPTIONS_SUB' => 'Pricing / Payments',	 	
  	
  	'FACTURES_SUB' => 'Invoices',
  	
  	'invoices_title' => 'Invoice',
  	'invoices_product' => 'Subscription',
  	'invoices_participants' => 'Participants',
  	'invoices_total' => 'Total HT',
  	'invoices_none' => 'No invoices available.',
  	
  	'wns_apps' => 'Work’N Sport is available on this website or on the Android app. The iPhone app will soon be available.',
  	
  	'wns_trademark' => '&reg; Work’N Sport is a registered trademark of QYD Cathay',
  	
  	 'Partenaire Stratégique' => 'Strategic Partner',
  	
  	


];



