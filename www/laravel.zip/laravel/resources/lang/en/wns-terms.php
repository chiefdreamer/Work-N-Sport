<?php

return [





'terms' => '

<p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png">Terms of use</p>

<p class="terms_title">Terms of use from 1/1-2016</p>


<p>Work’N Sport, the Company Connected Challenge is powered by QYD Cathay, 6C Impasse des Michaudes,
74 940 Annecy-le-Vieux, France. Work’N Sport – CCSC is a registered trademark belonging to QYD Cathay.
</p>

<p class="terms_subtitle">1. Work’N Sport - Introduction.</p>
<p>The present agreements refer to the terms of use for any participants to Work’N Sport, the Company Connected Sport Challenge (CCSC here below) organized by QYD Cathay.</p>

<p class="terms_subtitle">2. Work’N Sport participant permission</p>
<p>By registrating to Work’N Sport-CCSC, the participant hereby gives permission to CCSC and QYD Cathay to:<br />
• Take part of the participant ‘s sport activities registered on Moves App or any other sport App connected to
Work’N Sport website.<br />
• Display the results of the sport activities for Work’N Sport throughout www.workn-sport.com on a company,
team and individual levels.<br />
• Send e-mails to the participant in relation with the CCSC and its partners unless the participant ticks in the «
No email » box.<br />
• Delete points for sport activities that have been registered with obvious faulty information. Prior to this, parties
shall first try to find a mutual solution.</p>

<p class="terms_subtitle">3. Internet access</p>
<p>In order to take part to Work’N Sport, participants shall have a working Internet connection and a valid e-mail
address. The cost for accessing the Internet and for the cost for data traffic is the participant’s responsibility.</p>

<p class="terms_subtitle">4. Work’N Sport – Corporate Connected Sport Challenge brand and App</p>
<p>Work’N Sport- Corporate Connected Sport Challenge brand and App are owned by QYD Cathay. It is not permitted
to use CCSC brand and App for any other purpose other than participating to the Challenge. Participant
shall not:<br />
• Use the CCSC in any other way than controlled in these terms of use<br />
• Hand over personal username and password to others<br />
• Bypass the technical mechanisms used in the service in order to prevent from reproduction and distribution.<br />
• Use the service in contradiction to current laws and regulations<br />
QYD Cathay reserves the right to shut down/terminate the participants’ access to the CCSC if the participant is
misusing the service.</p>

<p class="terms_subtitle">5. Handling of participants’ personal information</p>
<p>By registrating to CCSC the participant accepts this agreement and permits Work’N Sport and QYD Cathay to store
personal information about the participant. The information is stored in accordance with French Law. The CCSC
and QYD Cathay may not distribute to third party the participant’s personal information. The information will only
be used to administer the participant login information to the Challenge offerings within the concept and continuous
improvement of the CCSC.<br />
The participant agrees that his information about sport activity levels, results, points, finished challenges etc. can
be used to display lists within the CCSC.</p>

<p class="terms_subtitle">6. Information relevant to the CCSC</p>
<p>The participant agrees to that the CCSC can send relevant information, offerings from partners etc. to the participants
by e-mail, text messages and / or push messages and notifications.</p>

<p class="terms_subtitle">7. Disclaimer</p>
<p>Work’N Sport is offered at current status and QYD Cathay gives no guarantee that the information, content, product
or services are entirely correct. QYD Cathay will do its best to improve the system and kindly asks all participants
to give feedbacks about his/her customer experience.<br />
QYD Cathay takes no responsibility for injuries of the participants in practicing sports.<br />
QYD Cathay reserves the right to continuously change and develop the service supplied under the name Work’N
Sport – Corporate Connected Sport Challenge. QYD Cathay can only be held responsible for the amount the client has paid for the current service. Smaller technical issues must be seen as normal and cannot be used to claim breach of contract.<br />
In the users’ forums and / or social platforms connected to the service, the participants agree on not writing anything that can be seen as illegal, insulting, racist, threatening, obscene or in any other way against the law. The participants also agree on not using the social forums for any type of commercial use, for instance for the marketing of products or services.</p>

<p class="terms_subtitle">8. Dispute</p>
<p>In the occurrence of a dispute, the participant and QYD Cathay should try for a settlement. If the parties cannot reach an agreement, the supplier QYD Cathay has the right to take the dispute to the tribunal de commerce d’Annecy, France. The present contract is under French law.</p>

<p class="terms_subtitle">9. Change in the terms of use</p>
<p>QYD Cathay reserves the right to change the terms of use when needed. Changes made to the terms of use shall be communicated to the participant either via e-mail or by using the social networking platform within the service.
</p>
',

];


