<?php


return [
'tutoriel' => 'Work’N Sport Tutorial',

'steps' => '
<p>Download Moves App and create your profile.</p>

<p>Download the Work’N Sport App.</p>

<p>
<b>Step 1</b> : click « <b>Register</b> » et complete les fields of « <b>My Account</b> ».<br />
<b>Step 2</b> : create your teams using « <b>Manage my Teams</b> », by clicking « <b>New Team</b> ».<br />
<b>Step 3</b> : each of your participants activates the Moves app, by clicking « <b>Activate Moves</b> ».
</p>

<p>Move More, Play More,</p>

<p>The Work’N Sport team</p>',
];


