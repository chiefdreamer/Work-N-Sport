<?php

return [

'privacy' => '

<p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png">Privacy policy</p>

<p>When you register on the site or mobile app, we collect the personal information you give us such as your name, address and email address.</p>

<p>We also automatically receive your computer’s internet protocol (IP) address in order to provide us with information that helps us learn about your browser and operating system.
</p>

<p>Email marketing: With your permission, we may send you emails about our services, new products and other updates.</p>

<p><a href="http://www.moves-app.com/privacy">Please also refer to the Moves Privacy Policy.</a>
</p>',

];











