<?php

return [


	'moves_activation_ajouter' => 'Add teams and participants',
	'moves_activation_select' => 'Please select a participant',
	'moves_activation_code' => 'GET THE CODE',
	'moves_activation_etape1' => 'THE PARTICIPANT INSTALLS THE MOVES APP ON IOS OR ANDROID',
	'moves_activation_etape2' => 'THE PARTICIPANT ENTERS <b>THE CODE</b> ON THEIR SMARTPHONE (Connected Apps > Enter PIN/CODE)',
	'moves_activation_etape3' => 'WAIT FOR THE ACTIVATION COMPLETED PAGE',
	'moves_activation_etape4' => 'Important: The code is only valid for five minutes.',
	
	
'Activez Moves' => 'Activate Moves',
'Envoyez l’activation par email' => 'Send the activation by email',
'L’adresse email doit être déjà renseignée dans une équipe.' =>'The email address needs to be already saved in a team.',	
	
'Tester mon activation Moves.' => 'Test my Moves activation.',


'ACTIVATION COMPLETEE' => 'ACTIVATION COMPLETED',

	
'faq' => '<h1>Frequently Asked Questions</h1>

<h3>How does Moves work?</h3>

<p>Moves uses sensor and location information from your iPhone to recognize activities, routes and places. The data is uploaded to our servers, which do most of the complex processing to produce your daily stats and storyline.</p>

<h3>Where should I carry my iPhone for Moves to work?</h3>

<p>Moves works in your pocket, bag, purse, hand or armband – the important thing is that you have your iPhone on you. The app cannot track your walking, running and cycling if you leave it at home :).</p>

<h3>Which activities does Moves recognize?</h3>

<p>Moves recognizes walking, cycling and running. It also recognizes all motorized travel as ‘transport’. Other activities are not yet recognized, but we’ll work on them in the future.</p>

<h3>How accurate is the step counter?</h3>

<p>Moves recognizes steps when you are continuously walking or running. The accuracy is good for following day-to-day changes in activity levels, or comparing step counts to daily targets. To conserve battery, very short walks (less than 30 sec) are not always counted. If you’re having a bumpy car/train ride and see steps going up in the app, don’t worry: they are eventually removed from the daily total when the data is analyzed in more detail (unlike some other pedometers and gadgets).</p>

<h3>Does Moves recognize running and walking on a treadmill?</h3>

<p>If you carry your iPhone, it should recognize the activities. However the distance calculation is not very accurate and we aim to improve it in the future.</p>

<h3>How does the app work in the background?</h3>

<p>The app automatically tracks your activity in the background. If you remove it from the recent apps list (double-tap home button), Moves will be off for a while, but it wakes up automatically when you move to a new location.</p>

<h3>How can I backup / transfer my data to another iPhone?</h3>

<p>Create a free account in the app by providing your email address and password. When you start using Moves on a new phone sign in with that account either in start screen or in Settings > Account.</p>

<h3>Can I turn off the app?</h3>

<p>Yes, you can do so via the settings inside the app (Tracking). However, we think you will get the most out of the app if you track all of your everyday activities.</p>

<h3>Why can’t I have step counting or activity recognition without location services?</h3>

<p>On iPhone, it is not possible to collect sensor data in background without having location services on. In addition, the activity recognition would be worse, and places could not be recognized without location data.</p>

<h3>Is GPS on all the time?</h3>

<p>No. GPS is not used when the phone is not moving at all, and it is used only occasionally to detect movement speed and routes. Note that the arrow icon in the status bar doesn’t mean that the GPS is on. It’s for indicating that location services are on in general.</p>

<h3>How much battery power does Moves consume?</h3>

<p>The app runs continuously in the background, which does consume battery power. Our goal has been to create an app that will allow your phone to run fine if you charge it nightly. We have reached this goal in our tests, but your results may vary. There are many variables that affect battery consumption. We are continuously optimizing battery consumption.</p>

<h3>Why does Moves sometimes recognize activities or places incorrectly?</h3>

<p>Moves is based on state-of-the-art activity- and place-recognition algorithms, but minor hiccups can (and will) occur. You can easily correct these by tapping the incorrect part of your storyline and then tapping the pen icon. The app learns, so any corrections you enter will make it smarter in the future.</p>

<h3>Does Moves work abroad when data roaming is off?</h3>

<p>Moves can collect data without an internet connection, which will be analyzed as soon as you have a connection again. However, if you travel to a new country and do not have a data connection, the location services in your phone may be less accurate until you establish a network connection. Visiting a Wi-Fi hotspot just once can help the phone produce better location data.</p>

<h3>Who gets to see my data?</h3>

<p>See our <a href="http://www.moves-app.com/privacy">Privacy Policy</a>.</p>

<h3>Is there an API?</h3>

<p>Yes! Read more about it: <a href="https://dev.moves-app.com">Moves Developer Site</a>.</p>

<h3>Can I export my data?</h3>

<p>If you are technically oriented, you can use the <a href="https://dev.moves-app.com">API</a> to export your data. We plan to support easy export in the future.</p>

<h3>Who owns Moves?</h3>

<p>Moves is developed and run by ProtoGeo Oy. We are a team of eight people, led by Designer CEO <a href="http://sampokarjalainen.com">Sampo Karjalainen</a>, and distributed between Helsinki (FI), London (UK) and Pittsburgh (US). ProtoGeo has received seed funding from <a href="http://www.lifelineventures.com">Lifeline Ventures</a>, <a href="http://www.profounderscapital.com">PROfounders</a>, angel investors and <a href="http://www.tekes.fi">Tekes</a>. To get in touch with the team, <a href="mailto:sampo@protogeo.com">contact Sampo</a>.</p>

<h3>Is there an Android version?</h3>

<p>Yes, take a look at Moves <a href="http://moves-app.com">home page</a>.</p>

<h3>How can I send feedback?</h3>

<p>We recommend using the Feedback function inside the app. You can also send feedback via email: <a href="mailto:feedback@moves-app.com">feedback@moves-app.com</a></p>
',

];
