<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        	<div class="panel panel-default">
        	
        	
            		 <?php if($INCLUDE_SUB_MENU): ?>
					<div class="panel-heading">
						<?php echo $__env->make('shared.menu_tabs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
                	<?php endif; ?>
					
<p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png"><?php echo e(trans('wns.FACTURES_SUB')); ?></p>



			<?php if(count($invoices) > 0): ?>
			


					<div class="panel-body">
						<table class="table invoices-striped invoices-table" style="font-size:14px;">

							<!-- Table Headings -->
							<thead>
							<tr>
								<th style="text-align:left"><?php echo e(trans('wns.invoices_title')); ?></th>
								<th style="text-align:right"><?php echo e(trans('wns.invoices_product')); ?></th>
								<th style="text-align:right"><?php echo e(trans('wns.invoices_participants')); ?></th>
								<th style="text-align:right"><?php echo e(trans('wns.invoices_total')); ?></th>
								<th style="text-align:right">HTML</th>
								<th style="text-align:right">PDF</th>
							</tr>
							</thead>
				
				

							<!-- Table Body -->
							<tbody>
								<?php foreach($invoices as $invoice): ?>
									<tr>
							
										<td style="text-align:left">
											<div><?php echo e($invoice->created_at); ?></div>
										</td>
										
										<td style="text-align:right">
											<div><?php echo e($invoice->product); ?></div>
										</td>

										
										<td style="text-align:right">
											<div><?php echo e($invoice->qty); ?></div>
										</td>
										
										<td style="text-align:right">
											<div><?php echo e(number_format(($invoice->amount/100), 2, '.', '')); ?> €</div>
										</td>
										
										
										<td style="text-align:right">
											<div><a href="/facture.php?id=<?php echo e($invoice->id); ?>&user_id=<?php echo e(Auth::user()->id); ?>"><i class="fa fa-file-o" style="color:#0000ff"></i></a></div>
										</td>
										
										<td style="text-align:right">
											<div><a href="/facture_pdf.php?id=<?php echo e($invoice->id); ?>&user_id=<?php echo e(Auth::user()->id); ?>"><i class="fa fa-file-pdf-o" style="color:#0000ff"></i></a></div>
										</td>
										
										
										
										
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				</div>
				
				
			<?php else: ?>
			<div class="panel panel-body"><?php echo e(trans('wns.invoices_none')); ?></div>
				
			<?php endif; ?>
   
		 </div>
	
	 </div>
		
   
    </div>
</div>




<?php $__env->stopSection(); ?>



<?php echo $__env->make($DEFAULT_VIEW, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>