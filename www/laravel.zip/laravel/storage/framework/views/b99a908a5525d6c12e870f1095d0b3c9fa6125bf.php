<?php $__env->startSection('content'); ?>



<div class="container" margin>


<!--
<div style="margin: 4px 0 4px 0; padding: 4px 0 4px 0; background-color:#660147; color:#ffffff; text-align:center; width:100%">
<b><?php echo e(trans('wns.Non_lucratifs')); ?></b>
</div>
-->






		<div class="row">
			
			<div id="front_page" style="color: #ffffff; font-size: 16px;"> 
			
			<?php if(App::getLocale() =='fr'): ?> 
			<img style="padding-top:0px;" src="images/wns_vertical_strip.jpg">
			<?php elseif(App::getLocale() =='en'): ?> 
			<img style="padding-top:0px;" src="images/wns_vertical_strip_en.jpg">
			<?php endif; ?> 

			</div>
			
		</div>






		<div class="row">


			<div id="front_page" style="color: #ffffff; font-size: 16px;">   

			<?php if(App::getLocale() =='fr'): ?> 
			<!--<img src="/images/strip_under_carousel.jpg">-->
			<?php elseif(App::getLocale() =='en'): ?> 
			<!--<img src="/images/strip_under_carousel_en.jpg">-->
			<?php endif; ?>	

			</div>

		</div>


          
        
          
         <!-- 
        <div class="col-md-10 col-md-offset-1">
  
        
            <div class="panel panel-default">
                <div class="panel-heading">Welcome</div>

                <div class="panel-body">
                    Your Application's Landing Page.
                </div>
            </div>
            
        </div>
        -->
        
    </div>
    

</div>
 
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make($DEFAULT_VIEW, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>