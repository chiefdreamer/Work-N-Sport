<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading"><img style="margin: -3px 10px 0 5px; height:20px;" src="/images/icon_moves.png" /> MOVES APP</div>

                <div class="panel-body">
                
                		<div>ACTIVATION</div>    
                		
                		<p>
                		<div>Une erreur est survenue lors de l’activation</div>   
                		<div><a href="http://www.workn-sport.com/moves">Ressayer</a></div>  
                		 </p>
                		
             				


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>