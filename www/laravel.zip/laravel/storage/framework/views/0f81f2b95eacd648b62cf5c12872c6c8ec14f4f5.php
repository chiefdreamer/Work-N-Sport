
<ul class="nav nav-pills">


<li role="presentation" class="nav-pills-first">
<a href="<?php echo e(url('/account')); ?>"><i class="fa fa-btn fa-user"></i><?php echo e(trans('wns.Compte')); ?></a>
</li>

<li role="presentation" class="nav-pills-first">
<a href="<?php echo e(url('/teams')); ?>"><i class="fa fa-btn fa-list"></i><?php echo e(trans('wns.Equipes / Participants')); ?></a>
</li>


<li role="presentation" class="nav-pills-first">
<a href="<?php echo e(url('/moves')); ?>"><i class="fa fa-btn fa-bolt"></i>&nbsp;<?php echo e(trans('wns.ACTIVATION_SUB')); ?></a>
</li>




<!--
<li role="presentation" class="nav-pills-second" style="margin: 3px 0 0 50px;">
<a href="<?php echo e(url('/subscribe')); ?>"><i class="fa fa-credit-card"></i>&nbsp;<?php echo e(trans('wns.INSCRIPTIONS_SUB')); ?></a>
</li>
-->

<!--
<li role="presentation" class="nav-pills-second" style="margin: 3px 0 0 0px;">
<a href="<?php echo e(url('/account/invoices')); ?>"><i class="fa fa-file-o"></i>&nbsp;<?php echo e(trans('wns.FACTURES_SUB')); ?></a>
</li>
-->


<li role="presentation" class="nav-pills-second" style="margin: 3px 0 0 0px;">
<a href="<?php echo e(url('/about')); ?>"><i class="fa fa-info-circle"></i>&nbsp;<?php echo e(trans('wns.Tutoriel')); ?></a>
</li>

</ul>

