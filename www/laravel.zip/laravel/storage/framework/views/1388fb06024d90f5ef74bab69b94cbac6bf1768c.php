<?php $__env->startSection('content'); ?>
<div class="container" style="background-color: #ffffff;">
    <div class="row" style="text-align: center;"> 
        <div>
            <div>
            
            
                <div class="ranking_main">   <div class="trophy"><i class="fa fa-trophy" aria-hidden="true"></i></div>
				<?php echo e(trans('wns.CLASSEMENT MONDIAL CX')); ?> : <?php echo e($initial_start_date); ?> - <?php echo e($end_date); ?><!--<?php echo e($current_date); ?>-->
				</div>
				<div>CORPORATE DIVISION: 1</div>


   
				    <div class="container">
					
						<div class="ranking_category"><?php echo e(trans('wns.SOCIETES')); ?></div>
						<div>
						<?php foreach($companies_ranking as $company): ?>
							<div style="clear: both;" class="<?php if( Auth::id()  == $company->id_user): ?><?php echo e("ranking_SELECTED"); ?><?php endif; ?>">
							
							<?php if($company->pts_total>0): ?>
								<div class="ranking_c" style="width:40px;"><?php echo e($company->ranking); ?></div>
									
								<div class="ranking_company_main">
								<?php if(file_exists(public_path('/images_'.$CX.'/company_logo_'.$company->company_id.'.jpg'))): ?>					
									<img alt="<?php echo e($company->company_title); ?>" title="<?php echo e($company->company_title); ?>" style="margin: 0 0 0 10px; max-width:150px;" src="<?php echo e(asset('/images_'.$CX.'/company_logo_'.$company->company_id.'.jpg')); ?>">
								<?php else: ?>
									<span style="margin: 0 0 0 10px;"><?php echo e($company->company_title); ?></span>	
								<?php endif; ?>
								</div>
							<?php else: ?>
								<div class="ranking_c" style="width:40px;"></div> 
								
								<div class="ranking_company_main_grey">
								<?php if(file_exists(public_path('/images_'.$CX.'/company_logo_'.$company->company_id.'.jpg'))): ?>
									<img alt="<?php echo e($company->company_title); ?>" title="<?php echo e($company->company_title); ?>" style="margin: 0 0 0 10px; max-width:150px;" src="<?php echo e(asset('/images_'.$CX.'/company_logo_'.$company->company_id.'.jpg')); ?>">
								<?php else: ?>
									<span style="margin: 0 0 0 10px;"><?php echo e($company->company_title); ?></span>
								<?php endif; ?>
								</div>
							<?php endif; ?>
							
							<div class="ranking_points_company"><?php echo e($company->pts_total); ?> pts </div>
							</div>	
							<hr>					
						<?php endforeach; ?>
						</div>
						
						

						<div style="font-size:11px; color: #c2c2c2;"><?php echo e(trans('wns.Les entreprises sans équipes ou en mode « Challenge Privé » ne sont pas inclus dans le classement')); ?></div>
					
					
					
						<div class="ranking_category"><b><?php echo e(trans('wns.EQUIPES')); ?></div>
						<div>
						<?php foreach($teams_ranking as $team): ?>
							<div style="clear: both;" class="<?php if( Auth::id()  == $team->id_user): ?><?php echo e("ranking_SELECTED"); ?><?php endif; ?>">
							
						
								
								
								<?php if($team->pts_total>0): ?>
								<div class="ranking_t" style="width:40px;"><?php echo e($team->ranking); ?></div>
								<div class="ranking_team_main"><?php echo e($team->team_title); ?>

								<?php else: ?>
								<div class="ranking_t" style="width:40px;"></div>
								<div class="ranking_team_main_grey"><?php echo e($team->team_title); ?>

								<?php endif; ?>
								
								
								<div class="ranking_company"><?php echo e($team->team_company); ?></div>
								
								
						
								
								
							</div>
						
							<div  class="ranking_points_team"><?php echo e($team->pts_total); ?> pts</div>
						
							</div>	
							<hr>						
						<?php endforeach; ?>
						</div>
						
	



					</div>

	
	

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>






<?php echo $__env->make($DEFAULT_VIEW, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>