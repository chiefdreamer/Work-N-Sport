<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading"><b style="color:#ff0000">DEV</b> CLASSEMENTS : <?php echo e($initial_start_date); ?> - <?php echo e($current_date); ?></div>


                <div class="panel-body">
   
   
   
   					<div style="color:#ff0000">1 MINUTE = 1 POINT</div>
   
				    <div class="container">
					
					<div style="margin: 10px 0 0 0"><b>SOCIETES</b>
					<?php foreach($companies_ranking as $company): ?>
						<div style="clear: both;">
						<div style="display:inline-block; width: 160px;"><?php echo e($company->company_title); ?></div>
						<div style="display:inline-block; width: 160px;"><?php echo e($company->pts_total); ?> pts </div>
						</div>						
					<?php endforeach; ?>
					</div>
					
					
					<div style="margin: 10px 0 0 0"><b>EQUIPES</b>
					<?php foreach($teams_ranking as $team): ?>
						<div style="clear: both;">
						<div style="display:inline-block; width: 160px;"><?php echo e($team->team_title); ?></div>
						<div style="display:inline-block; width: 160px;"><?php echo e($team->pts_total); ?> pts</div>
						</div>						
					<?php endforeach; ?>
					</div>


			
					<!--
					<div style="margin: 10px 0 0 0"><b>PARTICIPANTS</b></div>
					<?php foreach($participants as $participant): ?>
						<div style="clear: both;">
						<div style="display:inline-block; width: 160px;"> <?php echo e($participant->first_name); ?> <?php echo e($participant->last_name); ?></div> 
						<div style="display:inline-block; width: 160px;"> <?php echo e($participant->pts); ?> pts</div>
						</div>						
					<?php endforeach; ?>
					</div>
					-->
	
				</div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>