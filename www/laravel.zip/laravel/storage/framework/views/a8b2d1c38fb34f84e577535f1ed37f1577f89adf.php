<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <h2><b>Work’n Sport | Contact</b></h2>

        <div>
        
		<p><b>Société</b> : <?php echo e($company); ?></p>
		<p><b>Prénom</b> : <?php echo e($first_name); ?></p>
		<p><b>Nom</b> : <?php echo e($last_name); ?></p>
		<p><b>Désignation d’emploi</b> : <?php echo e($position); ?></p>
		<p><b>Email</b> : <?php echo e($email); ?></p>
		<p><b>Téléphone</b> : <?php echo e($telephone); ?></p>
		<p><b>Message</b> : <?php echo e($email_message); ?></p>

        </div>

    </body>
</html>

