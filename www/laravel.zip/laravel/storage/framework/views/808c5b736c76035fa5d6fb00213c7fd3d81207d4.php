<?php $__env->startSection('content'); ?>





<div class="container">






<div class="dashboard">
<div><img src="images/dash1.jpg"></div>


<div id="dashboard_link1" style="cursor: pointer;" data-toggle="collapse" href="#collapseExample1">
<img src="images/dash2.jpg">
</div>
<div class="collapse" id="collapseExample1">
<div>
<img src="images/dash3.jpg">
</div>
</div>

<div><img src="images/dash4.jpg"></div>


<div id="dashboard_link2" style="cursor: pointer;" data-toggle="collapse" href="#collapseExample2">
<img src="images/dash2.jpg">
</div>
<div class="collapse" id="collapseExample2">
<div><img src="images/dash6.jpg"></div>
</div>


<div><img src="images/dash7.jpg"></div>
</div>



</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>