<?php $__env->startSection('content'); ?>
<div class="container" style="margin: 10px auto 0 auto">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
            		
            		 <?php if($INCLUDE_SUB_MENU): ?>
					<div class="panel-heading">
						<?php echo $__env->make('shared.menu_tabs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
                	<?php endif; ?>
                
                
         				<?php if(Session::has('flash_message')): ?>
							<div class="alert alert-success"><span class="glyphicon glyphicon-ok"></span><em> <?php echo session('flash_message'); ?></em></div>
						<?php endif; ?>
				
				
				<div>
    

 
</div>

<p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png"><?php echo e(trans('wns.Compte')); ?></p>



                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/account/update?app=')); ?><?php echo e(app('request')->input('app')); ?>" onSubmit= "return validatePasswordCheck();">
                        <?php echo csrf_field(); ?>

					<p><?php echo e(trans('wns.La personne clé de votre société qui sera notre interlocutrice.')); ?></p>

                        <div class="form-group<?php echo e($errors->has('non_commercial') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label"><?php echo e(trans('wns.Non_lucratifs_form')); ?></label>
                            <div class="col-md-6">
                                <input style="margin: 20px 0 0 0; width:20px; height:20px;" type="checkbox" class="form-control" name="non_commercial" value="1" <?php echo e(isset($is_checked2) ? $is_checked2 : ''); ?>>

                                <?php if($errors->has('non_commercial')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('non_commercial')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> 
                        
                        
                         <div class="form-group<?php echo e($errors->has('company') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">* <?php echo e(trans('wns.Société')); ?></label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" id="company" name="company" value="<?php echo e($company); ?>">

                                <?php if($errors->has('company')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('company')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                       



                        <div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">* <?php echo e(trans('wns.Prénom')); ?></label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo e($first_name); ?>">

                                <?php if($errors->has('first_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('first_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">* <?php echo e(trans('wns.Nom')); ?></label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo e($last_name); ?>">

                                <?php if($errors->has('last_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('last_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        
                        
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">* <?php echo e(trans('wns.Email')); ?></label>

                            <div class="col-md-6">
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo e($email); ?>">

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">* <?php echo e(trans('wns.Téléphone')); ?></label>

                            <div class="col-md-6">
                                <input type="phone" class="form-control" id="phone" name="phone" value="<?php echo e($phone); ?>">

                                <?php if($errors->has('phone')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('phone')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label"><?php echo e(trans('wns.Adresse')); ?></label>

                            <div class="col-md-6">
                                <input type="address" class="form-control" id="address" name="address" value="<?php echo e($address); ?>">

                                <?php if($errors->has('address')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        
                        <div class="form-group<?php echo e($errors->has('city') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label"><?php echo e(trans('wns.Ville')); ?></label>

                            <div class="col-md-6">
                                <input type="city" class="form-control" id="city" name="city" value="<?php echo e($city); ?>">

                                <?php if($errors->has('city')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('city')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('postcode') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label"><?php echo e(trans('wns.Postal')); ?></label>

                            <div class="col-md-6">
                                <input type="postcode" class="form-control" id="postcode" name="postcode" value="<?php echo e($postcode); ?>">

                                <?php if($errors->has('postcode')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('postcode')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('country') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">* <?php echo e(trans('wns.Pays')); ?></label>

                            <div class="col-md-6">
                 
                                <select id="country" name="country" class="form-control" id="country">
                                <option selected value=""><?php echo e(trans('wns.Pays')); ?></option>
				    			
				    			<option <?php if($country  == 'Australia'): ?> selected <?php endif; ?> value="<?php echo e('Australia'); ?>"><?php echo e('Australia'); ?></option>
				    			<option <?php if($country  == 'Austria'): ?> selected <?php endif; ?> value="<?php echo e('Austria'); ?>"><?php echo e('Austria'); ?></option>
				    			<option <?php if($country  == 'Belgium'): ?> selected <?php endif; ?> value="<?php echo e('Belgium'); ?>"><?php echo e('Belgium'); ?></option>
				    			<option <?php if($country  == 'Canada'): ?> selected <?php endif; ?> value="<?php echo e('Canada'); ?>"><?php echo e('Canada'); ?></option>
								<option <?php if($country  == 'Chile'): ?> selected <?php endif; ?> value="<?php echo e('Chile'); ?>"><?php echo e('Chile'); ?></option>
								<option <?php if($country  == 'China'): ?> selected <?php endif; ?> value="<?php echo e('China'); ?>"><?php echo e('China'); ?></option>
								<option <?php if($country  == 'Czech Republic'): ?> selected <?php endif; ?> value="<?php echo e('Czech Republic'); ?>"><?php echo e('Czech Republic'); ?></option>
								
								<option <?php if($country  == 'Denmark'): ?> selected <?php endif; ?> value="<?php echo e('Denmark'); ?>"><?php echo e('Denmark'); ?></option>
								<option <?php if($country  == 'Estonia'): ?> selected <?php endif; ?> value="<?php echo e('Estonia'); ?>"><?php echo e('Estonia'); ?></option>
								
								<option <?php if($country  == 'Ecuador'): ?> selected <?php endif; ?> value="<?php echo e('Ecuador'); ?>"><?php echo e('Ecuador'); ?></option>
								
								<option <?php if($country  == 'Finland'): ?> selected <?php endif; ?> value="<?php echo e('Finland'); ?>"><?php echo e('Finland'); ?></option>
								
								
								<option <?php if($country  == 'France'): ?> selected <?php endif; ?> value="<?php echo e('France'); ?>"><?php echo e('France'); ?></option>
								
								<option <?php if($country  == 'Germany'): ?> selected <?php endif; ?> value="<?php echo e('Germany'); ?>"><?php echo e('Germany'); ?></option>
								<option <?php if($country  == 'Greece'): ?> selected <?php endif; ?> value="<?php echo e('Greece'); ?>"><?php echo e('Greece'); ?></option>
								<option <?php if($country  == 'Hungary'): ?> selected <?php endif; ?> value="<?php echo e('Hungary'); ?>"><?php echo e('Hungary'); ?></option>
								
								<option <?php if($country  == 'Iceland'): ?> selected <?php endif; ?> value="<?php echo e('Iceland'); ?>"><?php echo e('Iceland'); ?></option>
								<option <?php if($country  == 'Ireland'): ?> selected <?php endif; ?> value="<?php echo e('Ireland'); ?>"><?php echo e('Ireland'); ?></option>
								<option <?php if($country  == 'Israel'): ?> selected <?php endif; ?> value="<?php echo e('Israel'); ?>"><?php echo e('Israel'); ?></option>
								
								<option <?php if($country  == 'Italy'): ?> selected <?php endif; ?> value="<?php echo e('Italy'); ?>"><?php echo e('Italy'); ?></option>
								<option <?php if($country  == 'Japan'): ?> selected <?php endif; ?> value="<?php echo e('Japan'); ?>"><?php echo e('Japan'); ?></option>
								<option <?php if($country  == 'Korea'): ?> selected <?php endif; ?> value="<?php echo e('Korea'); ?>"><?php echo e('Korea'); ?></option>
								
								<option <?php if($country  == 'Luxembourg'): ?> selected <?php endif; ?> value="<?php echo e('Luxembourg'); ?>"><?php echo e('Luxembourg'); ?></option>
								<option <?php if($country  == 'Mexico'): ?> selected <?php endif; ?> value="<?php echo e('Mexico'); ?>"><?php echo e('Mexico'); ?></option>
								<option <?php if($country  == 'Netherlands'): ?> selected <?php endif; ?> value="<?php echo e('Netherlands'); ?>"><?php echo e('Netherlands'); ?></option>	
								
								<option <?php if($country  == 'New Zealand'): ?> selected <?php endif; ?> value="<?php echo e('New Zealand'); ?>"><?php echo e('New Zealand'); ?></option>
								<option <?php if($country  == 'Norway'): ?> selected <?php endif; ?> value="<?php echo e('Norway'); ?>"><?php echo e('Norway'); ?></option>
								<option <?php if($country  == 'Poland'): ?> selected <?php endif; ?> value="<?php echo e('Poland'); ?>"><?php echo e('Poland'); ?></option>	
								
								<option <?php if($country  == 'Portugal'): ?> selected <?php endif; ?> value="<?php echo e('Portugal'); ?>"><?php echo e('Portugal'); ?></option>
								
								<option <?php if($country  == 'Romania'): ?> selected <?php endif; ?> value="<?php echo e('Romania'); ?>"><?php echo e('Romania'); ?></option>
								
								<option <?php if($country  == 'Slovak Republic'): ?> selected <?php endif; ?> value="<?php echo e('Slovak Republic'); ?>"><?php echo e('Slovak Republic'); ?></option>
								<option <?php if($country  == 'Slovenia'): ?> selected <?php endif; ?> value="<?php echo e('Slovenia'); ?>"><?php echo e('Slovenia'); ?></option>	
								
								<option <?php if($country  == 'South Africa'): ?> selected <?php endif; ?> value="<?php echo e('South Africa'); ?>"><?php echo e('South Africa'); ?></option>	
								
								<option <?php if($country  == 'Spain'): ?> selected <?php endif; ?> value="<?php echo e('Spain'); ?>"><?php echo e('Spain'); ?></option>
								<option <?php if($country  == 'Sweden'): ?> selected <?php endif; ?> value="<?php echo e('Sweden'); ?>"><?php echo e('Sweden'); ?></option>
								<option <?php if($country  == 'Switzerland'): ?> selected <?php endif; ?> value="<?php echo e('Switzerland'); ?>"><?php echo e('Switzerland'); ?></option>
								
								<option <?php if($country  == 'Turkey'): ?> selected <?php endif; ?> value="<?php echo e('Turkey'); ?>"><?php echo e('Turkey'); ?></option>
								
								<option <?php if($country  == 'United Arab Emirates'): ?> selected <?php endif; ?> value="<?php echo e('United Arab Emirates'); ?>"><?php echo e('United Arab Emirates'); ?></option>
								
								<option <?php if($country  == 'United Kingdom'): ?> selected <?php endif; ?> value="<?php echo e('United Kingdom'); ?>"><?php echo e('United Kingdom'); ?></option>					
								
								<option <?php if($country  == 'United States'): ?> selected <?php endif; ?> value="<?php echo e('United States'); ?>"><?php echo e('United States'); ?></option>	
 	





								</select>
					

                                <?php if($errors->has('country')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('country')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


						 <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">* <?php echo e(trans('wns.Mot de passe')); ?></label>

                            <div class="col-md-6">
                                <input type="password" class="form-control" id="password" name="password">

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        

                        <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">* <?php echo e(trans('wns.Confirmation de mot de passe')); ?></label>

                            <div class="col-md-6">
                                <input type="password" class="form-control" name="password_confirmation"  id="password_confirmation">

                                <?php if($errors->has('password_confirmation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
             
                        

     
     
                         <div class="form-group<?php echo e($errors->has('cg_cities') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label"><?php echo e(trans('wns.Je participe aux Corporate Games')); ?></label>
                            <div class="col-md-6">
                               
						 <?php echo $html_multselect; ?>

					
					
					
					
                                <?php if($errors->has('cg_cities')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('cg_cities')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        


  
  
                        
                        <div class="form-group<?php echo e($errors->has('private_challenge') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label"><?php echo e(trans('wns.« Challenge Privé ». Votre entreprise et ses participants n’apparaissent plus sur les classements publics')); ?></label>
                            <div class="col-md-6">
                                <input style="margin: 20px 0 0 0; width:20px; height:20px;" type="checkbox" class="form-control" name="private_challenge" value="1" <?php echo e(isset($is_checked) ? $is_checked : ''); ?>>

                                <?php if($errors->has('private_challenge')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('private_challenge')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


						 <div class="form-group<?php echo e($errors->has('email_updates') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label"><?php echo e(trans('wns.Email hebdomadaire des classements publics')); ?></label>
                            <div class="col-md-6">
                                <input style="margin: 20px 0 0 0; width:20px; height:20px;" type="checkbox" class="form-control" name="email_updates" value="1" <?php echo e(isset($is_checked3) ? $is_checked3 : ''); ?>>

                                <?php if($errors->has('email_updates')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email_updates')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        


                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-sign-in"></i>Save
                                </button>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if(session()->has('message')): ?>
    <div class="alert alert-info"><?php echo e(session('message')); ?></div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make($DEFAULT_VIEW, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>