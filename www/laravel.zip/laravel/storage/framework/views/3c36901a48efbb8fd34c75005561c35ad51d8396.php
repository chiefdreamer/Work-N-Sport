<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
            
               
                
                
                <div class="panel-body">
           
                <p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png">Contact</p>
                
                     
                
                <?php if(!empty($message)): ?>
                 <div class="panel-heading"><?php echo e($message); ?></div>   
                 
                 
                 
				<?php else: ?>


     
                
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/contact/send')); ?>">
                        <?php echo csrf_field(); ?>



						<div class="form-group<?php echo e($errors->has('company') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">* <?php echo e(trans('wns.Contact_Société')); ?></label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="company" value="<?php echo e(old('company')); ?>">

                                <?php if($errors->has('company')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('company')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                   
                        
                        
                        <div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">* <?php echo e(trans('wns.Contact_Prénom')); ?></label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="first_name" value="<?php echo e(old('first_name')); ?>">

                                <?php if($errors->has('first_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('first_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">* <?php echo e(trans('wns.Contact_Nom')); ?></label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="last_name" value="<?php echo e(old('last_name')); ?>">

                                <?php if($errors->has('last_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('last_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        
                        <div class="form-group<?php echo e($errors->has('position') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label"><?php echo e(trans('wns.Contact_Position')); ?></label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="position" value="<?php echo e(old('position')); ?>">

                                <?php if($errors->has('position')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('position')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">* <?php echo e(trans('wns.Contact_Email')); ?></label>

                            <div class="col-md-6">
                                <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                     	<div class="form-group<?php echo e($errors->has('telephone') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label"><?php echo e(trans('wns.Contact_Phone')); ?></label>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="telephone" value="<?php echo e(old('telephone')); ?>">

                                <?php if($errors->has('telephone')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('telephone')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        
                        
                        <div class="form-group<?php echo e($errors->has('email_message') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label"><?php echo e(trans('wns.Contact_Message')); ?></label>

                            <div class="col-md-6">
                                <textarea class="form-control" name="email_message" style="height:60px"><?php echo e(old('email_message')); ?></textarea>

                                <?php if($errors->has('email_message')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email_message')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        
    

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary" style="width:100%; background-color: FF0000;">
                                    <i class="fa fa-paper-plane"></i>&nbsp;Send
                                </button>
                            </div>
                        </div>
                    </form>
                    
                    
                    <?php endif; ?>
                    
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>