<!-- Main Content -->
<?php $__env->startSection('content'); ?>
<div class="container" style="margin: 10px auto 0 auto">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><?php echo e(trans('wns-moves.Activez Moves')); ?></div>
                <div class="panel-body">
                

  
                    <form class="form-horizontal" role="form" method="POST" action="">
	               

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Email</label>

                            <div class="col-md-6">
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>">

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="button" class="btn btn-primary" onClick="activate_moves_not_logged_in();return false;">
                                    <i class="fa fa-btn fa-envelope"></i><?php echo e(trans('wns-moves.Envoyez l’activation par email')); ?>

                                </button>
                                <p style="font-size:12px;" ><?php echo e(trans('wns-moves.L’adresse email doit être déjà renseignée dans une équipe.')); ?></p>
                                <p style="font-size:12px;" ><i class="fa fa-btn fa-bolt"></i><a style="cursor:pointer;" onClick="test_moves_token_not_logged_in();return false;"><?php echo e(trans('wns-moves.Tester mon activation Moves.')); ?></a></p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($DEFAULT_VIEW, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>