<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>WORK N SPORT</title>



		<?php $__env->startSection('facebook_url', 'https://www.facebook.com/WorkN-Sport-951584984895304/'); ?>
		<?php $__env->startSection('twitter_url',  'https://twitter.com/worknsport/'); ?>
		<?php $__env->startSection('linkedin_url', 'https://www.linkedin.com/groups/8527807/'); ?>
		
		<?php $__env->startSection('flag_url_fr', "http://www.workn-sport.com/pdf/worknsport_fr.pdf"); ?>
		<?php $__env->startSection('flag_url_es', "http://www.workn-sport.com/pdf/worknsport_es.pdf"); ?>
		<?php $__env->startSection('flag_url_gb', "http://www.workn-sport.com/pdf/worknsport_gb.pdf"); ?>
		<?php $__env->startSection('flag_url_de', "http://www.workn-sport.com/pdf/worknsport_de.pdf"); ?>
		<?php $__env->startSection('flag_url_cn', "http://www.workn-sport.com/pdf/worknsport_cn.pdf"); ?>
		<?php $__env->startSection('flag_url_fi', "http://www.workn-sport.com/pdf/worknsport_fi.pdf"); ?>	
	
		
		
		
		
    <!-- Fonts -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700" rel='stylesheet' type='text/css'>

    <!-- Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet">




    <link href="<?php echo e(asset('css/flag-icon.css')); ?>" rel="stylesheet">
    
 
    <link href="<?php echo e(asset('css/custom.css')); ?>" media="all" rel="stylesheet" type="text/css" />
     
        <?php /* <link href="<?php echo e(elixir('css/app.css')); ?>" rel="stylesheet"> */ ?>

    <style>
        body {
            font-family: 'Lato';
        }

        .fa-btn {
            margin-right: 6px;
        }
        
        .moves-icon{
        	background: url('http://www.workn-sport.com/images/icon_moves.png') no-repeat 10px 15px / 20px 20px; 
    
        
    </style>
    
</head>
<body id="app-layout">
    



    <?php echo $__env->yieldContent('content'); ?>

    

    <!-- JavaScripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
 
 
 
     
     <!-- Multiselect -->
	<script type="text/javascript" src="http://davidstutz.github.io/bootstrap-multiselect/dist/js/bootstrap-multiselect.js"></script>
	<link rel="stylesheet" href="http://davidstutz.github.io/bootstrap-multiselect/dist/css/bootstrap-multiselect.css" type="text/css"/>



   

	<script type="text/javascript" src="<?php echo e(asset('js/custom.js')); ?>"></script>
    
    <!--for carousel swipe-->
	<script src="<?php echo e(asset('js/carousel-swipe.js')); ?>"></script> 
	
    
    <?php /* <script src="<?php echo e(elixir('js/app.js')); ?>"></script> */ ?>
    
   

           

     
       
</body>
</html>
