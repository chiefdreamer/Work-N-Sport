<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <h2><b>Work’n Sport | Move More, Play More!</b></h2>

        <div>
 
 <!--       
		<p>Nous vous remercions pour votre inscription sur le site Work’n Sport. Veuillez maintenant valider votre adresse email en cliquant sur le lien ci-dessous. More More, Play More! The Work’N Sport Team.
		</p>
		<p>We thank you for registrating on our website Work’N Sport. Please, now validate your email address by clicking on the link below. Move More, Play More! The Work’N Sport Team.</p> 
-->


		
		
			<p>Merci beaucoup d’avoir créé votre compte Work’N Sport, pour rejoindre la compétition, voici les prochaines étapes:</p>

			<p>
			1) cliquez ou copier-coller le lien ci-dessous et connectez-vous sur le site de Work’n sport avec votre identifiant et mot de passe.<br/>
			2) complétez les champs de votre compte.<br/>
			3) dans l’onglet “1 - Gerer mes Equipes” créez vos équipes de 3.<br/>
			4) dans l’onglet “2 - Activez l’app. Moves”, sélectionnez votre nom, cliquez sur “Obtenir le code”.<br/>
			5) Téléchargez “Moves”, dans la partie App connectées, cliquez sur “Enter pin” pour entrer le code qui vous a été communiqué précédemment pour connecter Moves et Work’n Sport.<br/>
			6) vous pouvez suivre votre classement sur le site internet www.workn-sport.com ou sur l’application work’n sport, disponible sur Android et bientôt sur iOS.
			</p>

			<p>N’hésitez pas à nous contacter pour toutes questions.</p>

			<p>Move More, Play More</p>

			<p>L’équipe de Work’n Sport</p>















            <br/>
            <br/>
           <p><a href="<?php echo e(URL::to('activate/' . $token)); ?>"><?php echo e(URL::to('activate/' . $token)); ?></a></p>

        </div>

    </body>
</html>



