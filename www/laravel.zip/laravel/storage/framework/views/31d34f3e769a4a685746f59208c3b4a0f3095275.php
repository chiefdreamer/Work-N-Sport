<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
           


            		 <?php if($INCLUDE_SUB_MENU): ?>
					<div class="panel-heading">
						<?php echo $__env->make('shared.menu_tabs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
                	<?php endif; ?>

				
				<p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png"><?php echo trans('wns-steps.tutoriel'); ?></p>
				                
				<div class="panel-body"><?php echo trans('wns-steps.steps'); ?></div>

      			<div class="panel-body" style="text-align:left;">
				<iframe width="100%" height="315" src="https://www.youtube.com/embed/ZEOJL2CPhvI?rel=0" frameborder="0" allowfullscreen></iframe>
             	</div>
             	
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make($DEFAULT_VIEW, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>