<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        	<div class="panel panel-default">
        	
        	
            		 <?php if($INCLUDE_SUB_MENU): ?>
					<div class="panel-heading">
						<?php echo $__env->make('shared.menu_tabs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
                	<?php endif; ?>
					
					
			<!-- Display My Teams -->
			<?php if(count($teams) > 0): ?>
			


     		<p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png"><?php echo e(trans('wns.Equipes')); ?></p>


					<div class="panel-body">
						<table class="table table-striped teams-table">

							<!-- Table Headings -->
			
			

							<!-- Table Body -->
							<tbody>
								<?php foreach($teams as $team): ?>
									<tr>
										<!-- Team Name -->
										<td class="table-text" width="25%">
											<div><?php echo e($team->title); ?></div>
										</td>
										
										<td class="table-text" width="25%">
											<div><?php echo e($team->description); ?></div>
										</td>
										
										<td class="table-text" width="25%">
											<div>
											<?php if($at_least_one_in_team_not_activated[$team->id]): ?>
												
												
												
												<form action="<?php echo e(url('teams/update')); ?>" method="POST">
										        <?php echo csrf_field(); ?>

										        <?php echo method_field('PATCH'); ?>

												
		
												<button type="button" class="btn btn-success_OFF  btn-xs AddEditButton" 																															
												data-toggle="modal"												 
												data-target="#confirmUpdate__TARGET" 
												data-id="<?php echo e(isset($team->id) ? $team->id : ''); ?>" 
												data-title="<?php echo e(isset($team->title) ? $team->title : ''); ?>" 
												data-description="<?php echo e(isset($team->description) ? $team->description : ''); ?>" 
												 
												
												data-moves1="<?php echo e(isset($teams_participants[$team->id]['moves1']) ? $teams_participants[$team->id]['moves1'] : ''); ?>"							
												data-first_name1="<?php echo e(isset($teams_participants[$team->id]['first_name1']) ? $teams_participants[$team->id]['first_name1'] : ''); ?>" 
												data-last_name1="<?php echo e(isset($teams_participants[$team->id]['last_name1']) ? $teams_participants[$team->id]['last_name1'] : ''); ?>" 
												data-email1="<?php echo e(isset($teams_participants[$team->id]['email1']) ? $teams_participants[$team->id]['email1'] : ''); ?>"												
												
												data-moves2="<?php echo e(isset($teams_participants[$team->id]['moves2']) ? $teams_participants[$team->id]['moves2'] : ''); ?>"
												data-first_name2="<?php echo e(isset($teams_participants[$team->id]['first_name2']) ? $teams_participants[$team->id]['first_name2'] : ''); ?>" 
												data-last_name2="<?php echo e(isset($teams_participants[$team->id]['last_name2']) ? $teams_participants[$team->id]['last_name2'] : ''); ?>" 
												data-email2="<?php echo e(isset($teams_participants[$team->id]['email2']) ? $teams_participants[$team->id]['email2'] : ''); ?>"
												
												data-moves3="<?php echo e(isset($teams_participants[$team->id]['moves3']) ? $teams_participants[$team->id]['moves3'] : ''); ?>"
												data-first_name3="<?php echo e(isset($teams_participants[$team->id]['first_name3']) ? $teams_participants[$team->id]['first_name3'] : ''); ?>" 
												data-last_name3="<?php echo e(isset($teams_participants[$team->id]['last_name3']) ? $teams_participants[$team->id]['last_name3'] : ''); ?>" 
												data-email3="<?php echo e(isset($teams_participants[$team->id]['email3']) ? $teams_participants[$team->id]['email3'] : ''); ?>" > 
												
										
												<i class="fa fa-edit"></i> 
													
												<?php if(App::getLocale() =='fr'): ?> 
												<span style="color:#ff0000;"><i>Activez Moves</i></span>
												<?php elseif(App::getLocale() =='en'): ?> 
												<span style="color:#ff0000;"><i>Activate Moves</i></span>
												<?php endif; ?>

													
												</button>
												
												</form>
												
												
											<?php endif; ?>
											</div>
										</td>
										

										
										<td>
										    <form action="<?php echo e(url('teams/delete/'.$team->id)); ?>" method="POST">
												<?php echo csrf_field(); ?>

												<?php echo method_field('DELETE'); ?>

				
												
											<?php if(App::getLocale() =='fr'): ?> 
											<button type="button" class="btn btn-danger  btn-xs" data-toggle="modal" data-target="#confirmDelete__TARGET" data-title="Supppimer l'équipe" data-message="Etes-vous sûr de vouloir supprimer définitivement cette équipe ?">
											<i class="fa fa-trash"></i> Supprimer
											</button>
											<?php elseif(App::getLocale() =='en'): ?> 
											<button type="button" class="btn btn-danger  btn-xs" data-toggle="modal" data-target="#confirmDelete__TARGET" data-title="Delete Team" data-message="Are you sure you want to permanently delete this team?">
											<i class="fa fa-trash"></i> Delete
											</button>
											<?php endif; ?> 
											
											</form>
										</td>
										
										
										
										<td>
											<form action="<?php echo e(url('teams/update')); ?>" method="POST">
										        <?php echo csrf_field(); ?>

										        <?php echo method_field('PATCH'); ?>

												
		
												<button type="button" class="btn btn-success  btn-xs AddEditButton" 																															
												data-toggle="modal"												 
												data-target="#confirmUpdate__TARGET" 
												data-id="<?php echo e(isset($team->id) ? $team->id : ''); ?>" 
												data-title="<?php echo e(isset($team->title) ? $team->title : ''); ?>" 
												data-description="<?php echo e(isset($team->description) ? $team->description : ''); ?>" 
												
												
												data-moves1="<?php echo e(isset($teams_participants[$team->id]['moves1']) ? $teams_participants[$team->id]['moves1'] : ''); ?>"							
												data-first_name1="<?php echo e(isset($teams_participants[$team->id]['first_name1']) ? $teams_participants[$team->id]['first_name1'] : ''); ?>" 
												data-last_name1="<?php echo e(isset($teams_participants[$team->id]['last_name1']) ? $teams_participants[$team->id]['last_name1'] : ''); ?>" 
												data-email1="<?php echo e(isset($teams_participants[$team->id]['email1']) ? $teams_participants[$team->id]['email1'] : ''); ?>"												
												
												data-moves2="<?php echo e(isset($teams_participants[$team->id]['moves2']) ? $teams_participants[$team->id]['moves2'] : ''); ?>"
												data-first_name2="<?php echo e(isset($teams_participants[$team->id]['first_name2']) ? $teams_participants[$team->id]['first_name2'] : ''); ?>" 
												data-last_name2="<?php echo e(isset($teams_participants[$team->id]['last_name2']) ? $teams_participants[$team->id]['last_name2'] : ''); ?>" 
												data-email2="<?php echo e(isset($teams_participants[$team->id]['email2']) ? $teams_participants[$team->id]['email2'] : ''); ?>"
												
												data-moves3="<?php echo e(isset($teams_participants[$team->id]['moves3']) ? $teams_participants[$team->id]['moves3'] : ''); ?>"
												data-first_name3="<?php echo e(isset($teams_participants[$team->id]['first_name3']) ? $teams_participants[$team->id]['first_name3'] : ''); ?>" 
												data-last_name3="<?php echo e(isset($teams_participants[$team->id]['last_name3']) ? $teams_participants[$team->id]['last_name3'] : ''); ?>" 
												data-email3="<?php echo e(isset($teams_participants[$team->id]['email3']) ? $teams_participants[$team->id]['email3'] : ''); ?>" > 
												
										
													<i class="fa fa-edit"></i> 
													
													<?php if(App::getLocale() =='fr'): ?> 
													Modifier 
													<?php elseif(App::getLocale() =='en'): ?> 
													Edit
													<?php endif; ?> 

													
												</button>
											</form>
										</td>
										
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				</div>
			<?php endif; ?>
   
	
	
        
        
        
            <div class="panel panel-default">
           

                <div class="panel-body">
					<button type="button" class="btn btn-primary AddEditButton" 
					data-toggle="modal" 
					data-target="#confirmAdd__TARGET"
					
					
					data-first_name1="<?php echo e(isset($participant1_default['first_name1']) ? $participant1_default['first_name1'] : ''); ?>" 
					data-last_name1="<?php echo e(isset($participant1_default['last_name1']) ? $participant1_default['last_name1'] : ''); ?>" 
					data-email1="<?php echo e(isset($participant1_default['email1']) ? $participant1_default['email1'] : ''); ?>"	
					
					data-first_name2="" 
					data-last_name2="" 
					data-email2="" 
					
					data-first_name3="" 
					data-last_name3="" 
					data-email3="" 		
					> 
					
						<i class="fa fa-plus-square"></i> <?php echo e(trans('wns.Nouvelle équipe')); ?>

					</button>


				</div>
        
        </div>
    </div>
</div>



<!-- Modal Dialog For Deleting-->
<div class="modal fade" id="confirmDelete__TARGET" role="dialog" aria-labelledby="confirmDeleteLabel" aria-hidden="true">
  <div class="modal-dialog modal-teams">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Supprimer</h4>
      </div>
      <div class="modal-body">
        <p>Are you sure ?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
        <button type="button" class="btn btn-danger" id="confirm">Supprimer</button>
      </div>
    </div>
   
  </div>
</div>







<!-- Modal Dialog For Update-->
<div class="modal fade" id="confirmUpdate__TARGET" class="confirmAdd" role="dialog" aria-labelledby="confirmAddLabel" aria-hidden="true">
  <div class="modal-dialog modal-teams">
    <div class="modal-content">
    
       <?php echo Form::open(array('url' => 'teams/update','class' => 'confirmTeamForm')); ?>

       
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">
        <?php if(App::getLocale() =='fr'): ?> 
		Modifier 
		<?php elseif(App::getLocale() =='en'): ?> 
		Edit
		<?php endif; ?>
		</h4>
      </div>
      
   
      <div class="modal-body">


				<div class="form-group">
			
					<?php echo Form::label('title', 'Title *', ['class' => 'control-label']); ?>

					<?php echo Form::text('title', null, ['class' => 'form-control']); ?>

					
					<?php echo Form::hidden('id', null,array('id' => 'id')); ?>

					
					
		
                                
				</div>

				<div class="form-group">
					<?php echo Form::label('description', 'Description', ['class' => 'control-label']); ?>

					<?php echo Form::textarea('description', null, ['size' => '50x3','class' => 'form-control']); ?>

				</div>	
				
				<div class="form-group">	
					<?php echo Form::label('title', 'Participant 1 : *', ['class' => 'control-label, team_participant_label']); ?><span id="moves1"></span><br />
					<?php echo Form::text('first_name1', null, ['id' => 'first_name1','class' => 'form-control, team_participant_input', 'placeholder' => 'Prénom']); ?>

					<?php echo Form::text('last_name1', null, ['id' => 'last_name1','class' => 'form-control, team_participant_input', 'placeholder' => 'Nom']); ?>

					<?php echo Form::text('email1', null, ['id' => 'email1','class' => 'form-control, team_participant_input', 'placeholder' => 'Email']); ?>

					
					<?php echo Form::label('title', 'Participant 2 :', ['class' => 'control-label, team_participant_label']); ?><span id="moves2"></span><br />
					<?php echo Form::text('first_name2', null, ['id' => 'first_name2', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Prénom']); ?>

					<?php echo Form::text('last_name2', null, ['id' => 'last_name2', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Nom']); ?>

					<?php echo Form::text('email2', null, ['id' => 'email2', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Email']); ?>

					
					<?php echo Form::label('title', 'Participant 3 :', ['class' => 'control-label, team_participant_label']); ?><span id="moves3"></span><br />
					<?php echo Form::text('first_name3', null, ['id' => 'first_name3', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Prénom']); ?>

					<?php echo Form::text('last_name3', null, ['id' => 'last_name3', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Nom']); ?>

					<?php echo Form::text('email3', null, ['id' => 'email3', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Email']); ?>

					
		
		
				
					
				</div>

		
				
      </div>
      <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
              

				<?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

      </div>

      			<?php echo Form::close(); ?>

      			
    </div>
    
    
    			
  </div>
</div>
</div>






<!-- Modal Dialog For Add-->
<div class="modal fade" id="confirmAdd__TARGET" class="confirmAdd" role="dialog" aria-labelledby="confirmAddLabel" aria-hidden="true">
  <div class="modal-dialog  modal-teams">
    <div class="modal-content">
    
       <?php echo Form::open(array('url' => 'teams/store','class' => 'confirmTeamForm')); ?>

       
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Nouvelle Equipe</h4>
      </div>
      
   
      <div class="modal-body">


				<div class="form-group">  
				
					<?php echo Form::label('title', 'Titre *', ['class' => 'control-label']); ?>

					<?php echo Form::text('title', null, ['class' => 'form-control']); ?>

					
	                   
                                     
				</div>

				<div class="form-group">
					<?php echo Form::label('description', 'Description', ['class' => 'control-label']); ?>

					<?php echo Form::textarea('description', null, ['size' => '50x2','class' => 'form-control']); ?>

				</div>	
				
				<div class="form-group">
				
					<?php echo Form::label('title', 'Participant 1 : *', ['class' => 'control-label, team_participant_label']); ?><br />
					<?php echo Form::text('first_name1', null, ['id' => 'first_name1', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Prénom']); ?>

					<?php echo Form::text('last_name1', null, ['id' => 'last_name1', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Nom']); ?>

					<?php echo Form::text('email1', null, ['id' => 'email1', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Email']); ?>

					
					<?php echo Form::label('title', 'Participant 2 :', ['class' => 'control-label, team_participant_label']); ?><br />
					<?php echo Form::text('first_name2', null, ['id' => 'first_name2', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Prénom']); ?>

					<?php echo Form::text('last_name2', null, ['id' => 'last_name2', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Nom']); ?>

					<?php echo Form::text('email2', null, ['id' => 'email2', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Email']); ?>

					
					<?php echo Form::label('title', 'Participant 3 :', ['class' => 'control-label, team_participant_label']); ?><br />
					<?php echo Form::text('first_name3', null, ['id' => 'first_name3', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Prénom']); ?>

					<?php echo Form::text('last_name3', null, ['id' => 'last_name3', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Nom']); ?>

					<?php echo Form::text('email3', null, ['id' => 'email3', 'class' => 'form-control, team_participant_input', 'placeholder' => 'Email']); ?>

					
	
	
	
			
			
					
				</div>

		
				
      </div>
      <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
              

				<?php echo Form::submit('Add New Team', ['class' => 'btn btn-primary']); ?>

      </div>

      			<?php echo Form::close(); ?>

      			
    </div>
    
    
    			
  </div>
</div>
</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make($DEFAULT_VIEW, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>