<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
            
            
				<?php if(!Auth::guest()): ?>
            		 <?php if($INCLUDE_SUB_MENU): ?>
					<div class="panel-heading">
						<?php echo $__env->make('shared.menu_tabs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
                	<?php endif; ?>
				<?php endif; ?>  
				
        		<p class="terms_title_main"><img style="height: 35px; margin: -4px 0 0 10px;" src="/images/swirl.png"><?php echo e(trans('wns.INSCRIPTIONS_SUB')); ?></p>


            
                <div class="panel-heading"><?php echo e(trans('wns.Inscriptions et le paiement se font en ligne directement.')); ?></div>


				<div class="panel-heading"><?php echo e(trans('wns.Inscriptions_info')); ?></div>
				
				<div class="panel-heading"><?php echo e(trans('wns.Inscriptions_info_team')); ?></div>
				
				


                <div class="panel-body">
      




				<table class="table subscriptionsTable">
				  <thead class="thead-default">
 
					<tr>
					  <td valign="top" style="width:20%">
						<p><?php echo e(trans('wns.Nombre d’équipes inscrites au sein de votre entreprise.')); ?></p>
					  </td>
					  <td valign="top" style="width:20%">
						<p><?php echo e(trans('wns.Prix HT en € par participant et par mois (si paiement mensuel)')); ?></p>
					  </td>
					  <!--
					  <td valign="top" style="width:20%">
						<p><?php echo e(trans('wns.Prix HT en € par participant pour l’année 2016 (si paiement annuel pour la période du 1er mai 2016 au 31 décembre 2016)')); ?></p>
					  </td>
					  -->
					  <td valign="top" style="width:20%">
						<p><?php echo e(trans('wns.Prix HT en € par participant pour l’année 2017 (si paiement annuel)')); ?></p>
					  </td>
					  <td valign="top" style="width:20%">
						<p><?php echo e(trans('wns.Prix HT en € par participant pour l’année 2017 (si paiement annuel et participant Corporate Games)')); ?></p>
					  </td>
					</tr>
					</thead>
	
					<tbody>
	 
					<tr>
					  <td valign="top">
						<p>1 – 99</p>
					  </td>
					  <td valign="top">
						<p>2</p>
					  </td>
					  <!--<td valign="top">
						<p>11</p>
					  </td>-->
					  <td valign="top">
						<p>19</p>
					  </td>
					  <td valign="top">
						<p>5</p>
					  </td>
					</tr>
					<tr>
					  <td valign="top">
						<p><?php echo e(trans('wns.Jusqu’à')); ?> 199</p>
					  </td>
					  <td valign="top">
						<p><?php echo e(trans('wns.1,9')); ?></p>
					  </td>
					  <!--<td valign="top">
						<p>10</p>
					  </td>-->
					  <td valign="top">
						<p>18</p>
					  </td>
					  <td valign="top">
						<p>5</p>
					  </td>
					</tr>
					<tr>
					  <td valign="top">
						<p><?php echo e(trans('wns.Jusqu’à')); ?>  299</p>
					  </td>
					  <td valign="top">
						<p><?php echo e(trans('wns.1,8')); ?></p>
					  </td>
					  <!--<td valign="top">
						<p>9</p>
					  </td>-->
					  <td valign="top">
						<p>17</p>
					  </td>
					  <td valign="top">
						<p>5</p>
					  </td>
					</tr>
					<tr>
					  <td valign="top">
						<p><?php echo e(trans('wns.Plus de')); ?> 300</p>
					  </td>
					  <td valign="top">
						<p><?php echo e(trans('wns.Merci de nous contacter')); ?></p>
					  </td>
					  <!--<td valign="top">
						<p><?php echo e(trans('wns.Merci de nous contacter')); ?></p>
					  </td>
					  -->
					  <td valign="top">
						<p><?php echo e(trans('wns.Merci de nous contacter')); ?></p>
					  </td>
					  <td valign="top">
						<p><?php echo e(trans('wns.Merci de nous contacter')); ?></p>
					  </td>
					</tr>
					
					
					<tr>
					  <td valign="top" colspan="5">
			
			
			
				<?php if(App::getLocale() =='fr'): ?> 
				
					<div style="display:inline-block">
					N° <input type="text" style="width:200px" maxlength="3" placeholder="Nombre de participants" name="qty_name" id="qty">
					</div>
			
					
					<div style="display:inline-block">
					<select name="payment_type" id="payment_type">
					
				    <option value="annual_2016_2017">Années 2016-2017 (CG/FR)</option>
				    
				    <!--<option value="annual_2016">Annuel 2016</option>-->
					<option value="annual_2017">Annuel 2017</option>
					
					<option value="monthly_1">Mensuel (1 mois)</option>
					<option value="monthly_3">Mensuel (3 mois)</option>
					<option value="monthly_6">Mensuel (6 mois)</option>
					<option value="monthly_9">Mensuel (9 mois)</option>
					</select>
					</div>
					
					
				<?php elseif(App::getLocale() =='en'): ?> 
				
				
					<div style="display:inline-block">
					N° <input type="text" style="width:200px" maxlength="3" placeholder="Number of participants" name="qty_name" id="qty">
					</div>
			
					
					<div style="display:inline-block">
					<select name="payment_type" id="payment_type">
					
				    <option value="annual_2016_2017">Years 2016-2017 (CG/FR)</option>
				    
				    <!--<option value="annual_2016">Annual 2016</option>-->
					<option value="annual_2017">Annual 2017</option>
					
					<option value="monthly_1">Monthly (1 month)</option>
					<option value="monthly_3">Monthly (3 months)</option>
					<option value="monthly_6">Monthly (6 months)</option>
					<option value="monthly_9">Monthly (9 months)</option>
					</select>
					</div>
					
				<?php endif; ?>
				
					  
			
					
					
					</div> 
					
					<div style="display:inline-block;"><span style="margin: 0 0 0 10px">Total HT</span><div id="total" style="display:inline-block;width:200px; text-align: left; font-weight: bold;margin: 0 0 0 20px"></div><div id="total_message" style="display:inline-block;width:20px; text-align: left; font-weight: bold;margin: 0 0 0 20px"></div><span id="errmsg"></span><span id="errmsg"></span></div>
					
					<script>
					
					// used on payments page   
					var cg_cities = new Array();
				
					cg_cities = <?php echo isset($vads_cg_cities) ? $vads_cg_cities : ''; ?>;
					
    				
					</script>
					
					<form id="form_order" method="post" action="http://www.workn-sport.com/payments/form_payment.php">	
						
					<input type="hidden" name="vads_cust_id" value="<?php echo e(isset($vads_cust_id) ? $vads_cust_id : ''); ?>">
					<input type="hidden" name="vads_cust_email" value="<?php echo e(isset($vads_cust_email) ? $vads_cust_email : ''); ?>">
					<input type="hidden" name="vads_cust_phone" value="<?php echo e(isset($vads_cust_phone) ? $vads_cust_phone : ''); ?>">
					
					<input type="hidden" id="id_vads_cust_legal_name" name="vads_cust_legal_name" value="<?php echo e(isset($vads_cust_legal_name) ? $vads_cust_legal_name : ''); ?>">
					<input type="hidden" id="id_vads_cust_address" name="vads_cust_address" value="<?php echo e(isset($vads_cust_address) ? $vads_cust_address : ''); ?>">
					<input type="hidden" id="id_vads_cust_city" name="vads_cust_city" value="<?php echo e(isset($vads_cust_city) ? $vads_cust_city : ''); ?>">
					<input type="hidden" id="id_vads_cust_zip" name="vads_cust_zip" value="<?php echo e(isset($vads_cust_zip) ? $vads_cust_zip : ''); ?>">
					<input type="hidden" id="id_vads_cust_country" name="vads_cust_country" value="fr">
					
					
					
					<input type="hidden" id="id_amount" name="vads_amount" value="<?php echo e(isset($vads_amount) ? $vads_amount : ''); ?>">
				
					<input type="hidden" name="vads_cust_first_name" value="<?php echo e(isset($vads_cust_first_name) ? $vads_cust_first_name : ''); ?>">
					<input type="hidden" name="vads_cust_last_name" value="<?php echo e(isset($vads_cust_last_name) ? $vads_cust_last_name : ''); ?>">
		
					<!-- duration-->
					<input type="hidden" id="id_vads_order_info" name="vads_order_info" value="<?php echo e(isset($vads_order_info) ? $vads_order_info : ''); ?>">

					<!-- qty-->
					<input type="hidden" id="id_vads_order_info2" name="vads_order_info2" value="<?php echo e(isset($vads_order_info2) ? $vads_order_info2 : ''); ?>">
		
		
		
					<div onClick="return checkTotal();" style="margin: 15px 0 0 0;"><a style="width:300px;" class="btn btn-primary" href="#" role="button" >
					<img src="/images/cards.png" style="width:50px; vertical-align:middle; margin: 0 5px 0 0;"> <?php echo e(trans('wns.Paiement par carte bancaire')); ?></a> 
					</div>

	
					</form>
		
		
			
					</td>
					</tr>
					
					
				  </tbody>
				</table>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make($DEFAULT_VIEW, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>