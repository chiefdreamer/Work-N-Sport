<?php

	//Etag
	
    $file = 'index.php';
    $last_modified_time = filemtime($file); 
    $etag = md5_file($file); 

    header("Last-Modified: ".gmdate("D, d M Y H:i:s", $last_modified_time)." GMT"); 
    header("Etag: $etag"); 

    if (@strtotime($_SERVER['HTTP_IF_MODIFIED_SINCE']) == $last_modified_time || 
        trim($_SERVER['HTTP_IF_NONE_MATCH']) == $etag) { 
        header("HTTP/1.1 304 Not Modified"); 
    	exit; 
	} 


?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title></title>

	<style>
	body{
		font-family: arial;
		font-size: 11px;
		width: 600px;	  
	} 
	
	table{
		border-collapse: collapse;
		border: 1px solid #c2c2c2;
	}
	
	
	table td{
		border-collapse: collapse;
		border: 1px solid #c2c2c2;
		color:#222222;
	}
	
	
	table td.w1{
		min-width:290px;
	}
	
	table td.w2{
		min-width:auto;
	}
	
	
	
	

	</style>
</head>
<body>




<?php

//if($_POST['email']==''){
	echo '<p><b>Enter email address to refresh points</b></p>';
	echo '<form action="#" method="post">';
	echo '<input type ="text" name="email" value="'.$_POST['email'].'" style="width:150px; background-color:#b4c6ea;">';
	echo '<input type ="submit" value="submit"  style="width:150px; background-color:#b4c6ea;">';
	echo '</form><br><br>';
//}

?>

<p><b>Data syncing</b></p>

<p>Open Moves app on WiFi for a few minutes to send data to Moves server</br>
www.moves-app.com TO http://www.workn-sport.com (data is updated every 24 hrs)</p>

<p>General notes from <a href="https://dev.moves-app.com/docs/api" target="_moves">Moves API</a>
</p>

<p>In ideal conditions the API should provide at most couple of hours old user data. User data is uploaded to our servers whenever user opens the app in phone and periodically every couple of hours.
The data updates may be irregular if user has bad internet connection or is using the Moves battery saving mode.
</p>




<br>
<br>


<?php


if($_POST['email']==''){
exit();
}


//custom class in libraries folder
use App\Libraries\Moves;
require('/var/www/laravel/app/Libraries/Moves.php');
require('/var/www/laravel/app/Functions/movesConfig.php');
$m = new Moves($client_id,$client_secret,$redirect_url);




//Access laravel sesssion
require '/var/www/laravel/bootstrap/autoload.php';
$app = require_once '/var/www/laravel/bootstrap/app.php';
$app->make('Illuminate\Contracts\Http\Kernel')
    ->handle(Illuminate\Http\Request::capture());


use App\Http\Requests;
use Illuminate\Http\Request;






require_once('../config.php');


$participants = DB::table('participants')
   ->selectRaw('participants.first_name, participants.last_name, participants.pts_updated, participants.access_token, participants.refresh_token, participants.id_team ,participants.id_user, participants.id')   
   ->where('participants.email','=',$_POST['email'])
   ->where('participants.access_token','!=', '')
   ->get();
   
   
$curl_array = Array();

//loop throug all participants
foreach ($participants as $participant){		 


$date = $participant->pts_updated;
$createDate = new DateTime($date); 
$date2 = $createDate->format('Y-m-d');

//old date to force refresh by  cron_update_async_api.php
$date2 = '2000-01-01';


	//if access token present		
	if($participant->access_token !=''){
		$curl_array[]['url'] ="http://www.workn-sport.com/cron_update_async_api.php?id=".$participant->id."&access_token=".$participant->access_token."&refresh_token=".$participant->refresh_token."&pts_updated=".$date2;

	}
}	


		

// create cURL resource
$c=0;
foreach ($curl_array as $curl){
	${'ch_'.$c} = curl_init();
	$c++;
}



// set URL and other appropriate options			
$c=0;
foreach ($curl_array as $curl){
	curl_setopt(${'ch_'.$c}, CURLOPT_URL, $curl['url']);
	curl_setopt(${'ch_'.$c}, CURLOPT_HEADER, 0);
	$c++;
}

//create the multiple cURL handle
$mh = curl_multi_init();


//add the handle
$c=0;
foreach ($curl_array as $curl){
	curl_multi_add_handle($mh,${'ch_'.$c});
	$c++;
}


$active = null;
//execute the handle
do {
	$mrc = curl_multi_exec($mh, $active);
} while ($mrc == CURLM_CALL_MULTI_PERFORM);

while ($active && $mrc == CURLM_OK) {
	if (curl_multi_select($mh) != -1) {
		do {
			$mrc = curl_multi_exec($mh, $active);
		} while ($mrc == CURLM_CALL_MULTI_PERFORM);
	}
}


//close the handle	
$c=0;
foreach ($curl_array as $curl){
	curl_multi_remove_handle($mh, ${'ch_'.$c});
	$c++;
}


curl_multi_close($mh);


			




		$participants = DB::table('participants')
		   ->selectRaw('participants.id, participants.moves_id_user, participants.email, participants.first_name, participants.last_name, participants.access_token, participants.refresh_token, participants.pts, participants.pts_updated')   
		   ->where('participants.email','=',$_POST['email'])
		   ->orderby('participants.id')
		   ->get();
		   
 
		   
		   /*
		   $activated = DB::table('participants')
		   ->selectRaw('participants.access_token')   
		   ->where('participants.access_token','!=','')
		   ->orderby('participants.id')
		   ->get();
		   
		   $ac= count($activated) ;
		   */
		      
	
	
function get_starred($str) {
    $len = strlen($str);
    return substr($str, 0, 10).str_repeat('•', $len - 5);
}


function hide_email($email) {
//return $email;

    $mail_segments = explode("@", $email);
    $mail_segments[0] = str_repeat("•", strlen($mail_segments[0]));

    return implode("@", $mail_segments);
}


?>



<?php


 
	echo '<table border="1" cellpadding="4" >';	   
	
	echo '<tr><td valign="top"><b>Points updated for</b></td>
	<td><b>Activated Moves app token</b></td>
	<td valign="top"><b>Moves ID</b></td>	
	<td><b>Pts</b></td>
	<!--<td><b>Pts udpated (Moves>WnS)</b></td>-->
	</tr>';
	
	
		$c=0;
		//$ac=0;			 
		//loop through ALL participants
		foreach ($participants as $participant){		
		
	
		



		
	
			if($participant->email !=''  ){
				$c++;
	   	
					 
						//ONLY SEND EMAILS TO davide.giorgi@orange.fr
						$access_token='';
						
						if($participant->access_token){
						$access_token = get_starred($participant->access_token);
						//$ac++;
						}
						
						echo '<tr>';	
											
						echo '<td valign="top" class="w1">'.ucwords($participant->first_name).' '.$participant->last_name.' '.hide_email($participant->email).'</td>
						<td class="w1"><a href="https://api.moves-app.com/api/1.1/user/profile?access_token='.$participant->access_token.'" target="_profile">'.$access_token.'</a>';						
						echo '</td>';
						
						
						echo '<td valign="top" class="w2">'.$participant->moves_id_user.'</td>';		
						echo '</td>';
						
						
						
						echo '<td valign="top" class="w2" align="right"><nobr>';						
						if($participant->access_token){ 
						echo ' <a href="http://www.workn-sport.com/_api1_ACTIVITY_DETAILS_READONLY.php?id='.$participant->id.'&name='.ucwords($participant->first_name).' '.$participant->last_name.'" target="_details">'.$participant->pts.' Pts</nobr></a>'; 
						}						
						echo '</td>';
						
						//echo '<td valign="top" class="w2">'.$participant->pts_updated.'</td>';		
						//echo '</td>';
						
						
						echo '</tr>';
	
				 
				
			}

			

			
		}	

					
echo '</table>';




	
				
	
?>


</body>
</html>


