<?php



include_once '../Moves.php';
include_once 'config.php';
$m = new PHPMoves\Moves(Config::$client_id,Config::$client_secret,Config::$redirect_url);

if (isset($_GET['token'])) {
    $access_token = $_GET['token'];
    //echo json_encode($m->get_profile($access_token));
    
    echo json_encode($m->validate_token($access_token))
        
}
?>