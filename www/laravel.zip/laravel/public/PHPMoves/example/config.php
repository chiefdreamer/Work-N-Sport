<?php
Class Config {
    //Set client_id provided when you registered your Moves Apps
    public static $client_id = "t6HNc4_kcmXx4PUDTXBjJ8agBS41drZu";
    //Set client_secret provided when you registered your Moves Apps
    public static $client_secret = "zckf_60YaCbjv3D61bpo0DDUkmAivFDuEOdnmRytTQ9grt2xpq330WL2igm46h5j";
   
    //Set your redirect url. For this demo it would be http://your-url/example/test.php  
    //This is overridden by the url set for the App on the moves api interface
    public static $redirect_url = "http://www.workn-sport.com/PHPMoves/example/test.php"; 
}
