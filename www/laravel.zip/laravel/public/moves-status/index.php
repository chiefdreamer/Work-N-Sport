<?php










//custom class in libraries folder
use App\Libraries\Moves;
require('/var/www/laravel/app/Libraries/Moves.php');
require('/var/www/laravel/app/Functions/movesConfig.php');
$m = new Moves($client_id,$client_secret,$redirect_url);




//Access laravel sesssion
require '/var/www/laravel/bootstrap/autoload.php';
$app = require_once '/var/www/laravel/bootstrap/app.php';
$app->make('Illuminate\Contracts\Http\Kernel')
    ->handle(Illuminate\Http\Request::capture());






	

require_once('../config.php');






//if(date("Y-m-d") == '2017-01-10'){
		//RUN IN SEQUEL PRO
		//update participants_TEMP, participants set participants.type = participants_TEMP.pts where participants.id=participants_TEMP.id

							
		//reset all pts to 0		
		//$row = DB::table('participants')->where('id','!=',0)->update(['pts' => 0]);	
		
		//copy pts from type to pts (if not 0) and divide by 90
		//$row = DB::table('participants')->where('type','!=', 0)->update(['pts' => DB::raw('type/90')]);
//}







		$participants = DB::table('participants')
		   ->selectRaw('participants.id, participants.moves_id_user, participants.email, participants.first_name, participants.last_name, participants.access_token, participants.refresh_token, participants.pts')   
		   ->where('participants.id','!=',0)
		   ->orderby('participants.id')
		   ->get();
		   
 
		   
		   $activated = DB::table('participants')
		   ->selectRaw('participants.access_token')   
		   ->where('participants.access_token','!=','')
		   ->orderby('participants.id')
		   ->get();
		   
		   $ac= count($activated) ;
		      
	
	
function get_starred($str) {
    $len = strlen($str);
    return substr($str, 0, 10).str_repeat('•', $len - 5);
}


function hide_email($email) {
//return $email;

    $mail_segments = explode("@", $email);
    $mail_segments[0] = str_repeat("•", strlen($mail_segments[0]));

    return implode("@", $mail_segments);
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title></title>

	<style>
	body{
		font-family: arial;
		font-size: 11px;	  
	} 
	
	table{
		border-collapse: collapse;
		border: 1px solid #c2c2c2;
	}
	
	
	table td{
		border-collapse: collapse;
		border: 1px solid #c2c2c2;
		color:#222222;
	}
	
	
	table td.w1{
		min-width:290px;
	}
	
	table td.w2{
		min-width:auto;
	}
	
	
	
	

	</style>
</head>
<body>



<?php

	 
	echo '<table border="1" cellpadding="4" >';	   
	
	echo '<tr><td valign="top"><b>All participants</b></td>
	<td><b>Activated Moves apps ('.$ac.')</b></td>
	<td valign="top"><b>Moves ID</b></td>	
	<td><b>Pts</b></td></tr>';
	
	
		$c=0;
		//$ac=0;			 
		//loop through ALL participants
		foreach ($participants as $participant){		
		
	
		



		
	
			if($participant->email !=''  ){
				$c++;
	   	
					 
						//ONLY SEND EMAILS TO davide.giorgi@orange.fr
						$access_token='';
						
						if($participant->access_token){
						$access_token = get_starred($participant->access_token);
						//$ac++;
						}
						
						echo '<tr>';	
											
						echo '<td valign="top" class="w1">'.$c.' '.ucwords($participant->first_name).' '.$participant->last_name.' '.hide_email($participant->email).'</td>
						<td class="w1"><a href="https://api.moves-app.com/api/1.1/user/profile?access_token='.$participant->access_token.'" target="_profile">'.$access_token.'</a>';						
						echo '</td>';
						
						
						echo '<td valign="top" class="w2">'.$participant->moves_id_user.'</td>';		
						echo '</td>';
						
						
						
						echo '<td valign="top" class="w2" align="right">';						
						if($participant->access_token){ 
						echo ' <a href="http://www.workn-sport.com/_api1_ACTIVITY_DETAILS_READONLY.php?id='.$participant->id.'&name='.ucwords($participant->first_name).' '.$participant->last_name.'" target="_details">'.$participant->pts.' Pts</a>'; 
						}						
						echo '</td>';
						
						
						echo '</tr>';
	
				 
				
			}

			

			
		}	

					
echo '</table>';





	
echo '<br /><br /><table border="1" cellpadding="4" >';	 


	echo '<!--<tr><td valign="top" colspan="2"><b>Participants that need to re-authorize Moves</b></td></tr>-->';
		
		$c=0;			 
		//loop through ALL participants
		foreach ($participants as $participant){		
		
	
		



		
	
			if($participant->email !='' && $participant->access_token ==''  && $participant->refresh_token !='' ){
				$c++;
	   	
					 
						//ONLY SEND EMAILS TO davide.giorgi@orange.fr
						$access_token='';
						
						if($participant->access_token){
						$access_token = get_starred($participant->access_token);
						}
						
						//echo '<tr><td valign="top">'.$c.' '.ucwords($participant->first_name)." ".$participant->last_name." ".$participant->email."</td><td>".$access_token."</td></tr>";

						echo '<!--<tr><td valign="top">'.$c.' '.ucwords($participant->first_name)." ".$participant->last_name." ".hide_email($participant->email)."</td></tr>-->";
	
				
				
			}

			
  
			
		}	
				
echo '</table><br /><br />';


	
				
	
?>


</body>
</html>


