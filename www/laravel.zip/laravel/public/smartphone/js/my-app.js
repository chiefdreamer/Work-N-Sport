// Initialize your app
var myApp = new Framework7({
		//FOR DEV ONLY
		//cacheDuration: 10000
		// ... other parameters



});



// Export selectors engine
var $$ = Dom7;



$$('.device-info').on('click', function () {
    myApp.alert(Framework7.prototype.device.os+" "+Framework7.prototype.device.osVersion);
});



// Add view
var mainView = myApp.addView('.view-main', {
    // Because we use fixed-through navbar we can enable dynamic navbar
    dynamicNavbar: true,

});

// Callbacks to run specific code for specific pages, for example for About page:
myApp.onPageInit('about', function (page) {
    // run createContentPage func after link was clicked
 
    $$('.create-page').on('click', function () {
        createContentPage();
    });
});








/* WORK N SPORT*/ 

myApp.onPageInit('rankings', function (page) {  

		

		
		
$$.get('http://www.workn-sport.com/rankings-smartphone?app=1', {}, function (data) {        
        $$('#rankings').html(data);          
    });         
});


//Replaced with iframes
/*
myApp.onPageInit('rankings-my', function (page) {  
$$.get('http://www.workn-sport.com/my/rankings-smartphone', {}, function (data) {        
        $$('#rankings-my').html(data);          
    });        
});
*/



/*
myApp.onPageInit('account', function (page) {  
$$.get('http://www.workn-sport.com/account-smartphone', {}, function (data) {        
        $$('#account').html(data);          
    });        
});
*/











// Generate dynamic page
var dynamicPageIndex = 0;
function createContentPage() {
	mainView.router.loadContent(
        '<!-- Top Navbar-->' +
        '<div class="navbar">' +
        '  <div class="navbar-inner">' +
        '    <div class="left"><a href="#" class="back link"><i class="icon icon-back"></i><span>Back</span></a></div>' +
        '    <div class="center sliding">Dynamic Page ' + (++dynamicPageIndex) + '</div>' +
        '  </div>' +
        '</div>' +
        '<div class="pages">' +
        '  <!-- Page, data-page contains page name-->' +
        '  <div data-page="dynamic-pages" class="page">' +
        '    <!-- Scrollable page content-->' +
        '    <div class="page-content">' +
        '      <div class="content-block">' +
        '        <div class="content-block-inner">' +
        '          <p>Here is a dynamic page created on ' + new Date() + ' !</p>' +
        '          <p>Go <a href="#" class="back">back</a> or go to <a href="services.html">Services</a>.</p>' +
        '        </div>' +
        '      </div>' +
        '    </div>' +
        '  </div>' +
        '</div>'
    );
	return;
}