<?php


//USED TO TEST MOVES ACCESS TOKEN



//custom class in libraries folder
use App\Libraries\Moves;
require('/var/www/laravel/app/Libraries/Moves.php');
require('/var/www/laravel/app/Functions/movesConfig.php');
$m = new Moves($client_id,$client_secret,$redirect_url);




//Access laravel sesssion
require '/var/www/laravel/bootstrap/autoload.php';
$app = require_once '/var/www/laravel/bootstrap/app.php';
$app->make('Illuminate\Contracts\Http\Kernel')
    ->handle(Illuminate\Http\Request::capture());






require_once('config.php');



		$participants = DB::table('participants')
		   ->selectRaw('participants.id, participants.email, participants.first_name, participants.access_token')   
		   ->where('participants.email','=',$_POST['email'])
		   ->limit(1)
		   ->get();
		   
	
	
	     
	
				 
		//loop through ALL participants
		foreach ($participants as $participant){		
		
						//echo $participant->access_token;exit();

						$url = "https://api.moves-app.com/oauth/v1/tokeninfo?access_token=".$participant->access_token;

						 
						$ch = curl_init();
						curl_setopt($ch, CURLOPT_URL, $url);
						curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true );
						// This is what solved the issue (Accepting gzip encoding)
						//curl_setopt($ch, CURLOPT_ENCODING, "gzip,deflate");     
						$response = curl_exec($ch);
						curl_close($ch);
						//echo $response;
						
					
						
						$response_decoded = json_decode($response);
						
						//echo ($response_decoded->client_id);exit();
						

						
						if(isset($response_decoded->client_id)){
							echo "Ce compte Moves est activé.";exit();
						}else{
							echo "Ce compte Moves n'est pas activé.";exit();
						}
						
					
	
			 
		}	
				

echo 'L’adresse email n’a pas été trouvée dans les équipes.';
  

				
	
?>

