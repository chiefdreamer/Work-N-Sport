<?php

echo phpinfo()

?>

