<?php


exit('blocked');






//$devmode = false; 
//$devmode = true; 

//USED TO SEND WEEKLY EMAILS WITH RANKING AND POINTS TO USERS 


//ENABLE BELOW TO ONLY SEND TO info@liquidsky.net
//**********
//**********
//**********
$devmode = true; 
//$devmode = false;
  
//**********
//**********
//**********



//block access from browser
if (!$devmode){
	if(php_sapi_name() != "cli"){
	   echo "Access denied"; exit();
	}
}
		


  
  


 


error_reporting(0);

session_start();



//Access laravel sesssion
require '/var/www/laravel/bootstrap/autoload.php';
$app = require_once '/var/www/laravel/bootstrap/app.php';
$app->make('Illuminate\Contracts\Http\Kernel')
    ->handle(Illuminate\Http\Request::capture());






   




require_once('config.php');





////////////////
////////////////
////////////////
////////////////
////////////////
//////////////// COMPANIES
////////////////
////////////////
////////////////
////////////////
////////////////








		//users to loop through
		$users = DB::table('users')
		   ->selectRaw('users.id, users.email_updates, users.company, users.email, users.first_name, users.last_name')   
		   ->where('users.id','!=',0)
		   ->where('users.private_challenge','=',0)
		   ->orderBy('users.company', 'ASC')
		   ->get();

			//AAARG DOR NOT use 
			//->where('users.email_updates',1)
		
		
		 
						//STORE COMPANY RANKINGS
						DB::statement(DB::raw('set @row=0'));
						$companies_ranking_RANK = DB::select("
				
						SELECT *, @row := @row + 1 as ranking  FROM (SELECT  						 			
						p.id,
						p.id_user,
						u.email as user_email,
						u.company as company_title,
						u.id as user_id, 
						u.first_name as first_name,
                        IFNULL(sum(p.pts) , 0) AS pts_total
                        FROM participants 
                        AS p                     
                                                  
                        JOIN  (SELECT id, first_name, email, email_updates, company, private_challenge FROM users)
                        AS u ON p.id_user = u.id 
                        
                   		WHERE (p.pts !=-1   			
            			AND u.private_challenge = 0)		
            			
            			GROUP BY id_user
            			ORDER BY pts_total DESC, company_title ASC 		
                   		) r ");  
                   		
                   		
                   		//AAARG DOR NOT use  messes with ranking !!
                   		//AND u.email_updates = 1)
                   		
                   		
                   		
                   		 
                   		
                   		$company_rank = Array();
                   		$company_points = Array();
                   		
                   		$company_rank_NAME = Array();
						$company_rank_NAME[0]='';
						
						$company_rank_FIRST_NAME = Array();
						$company_rank_FIRST_NAME[0]='';
						
						$company_rank_EMAIL = Array();
						$company_rank_EMAIL[0]='';
						
						$company_rank_POINTS = Array();
						$company_rank_POINTS[0]='';
						
						 //loop through ALL companies
						 foreach ($companies_ranking_RANK as $item){
						 
						 
								$company_rank_NAME[$item->ranking]='';
								$company_rank_FIRST_NAME[$item->ranking]='';
								$company_rank_EMAIL[$item->ranking]='';
								$company_rank_POINTS[$item->ranking]='';
								
								$company_points[$item->user_id] = $item->pts_total;
								
								if($item->pts_total >0){
									$company_rank[$item->user_id] = $item->ranking;
									$company_rank_FIRST_NAME[($item->ranking)] = $item->first_name;
									$company_rank_EMAIL[($item->ranking)] = $item->user_email;
									$company_rank_NAME[($item->ranking)] = $item->company_title;
									$company_rank_POINTS[($item->ranking)] = $item->pts_total;
									//echo $item->ranking."<br>"; 
								}else{
									$company_rank[$item->user_id] = $item->ranking;
									$company_rank_FIRST_NAME[($item->ranking)] = $item->first_name;
									$company_rank_EMAIL[($item->ranking)] = $item->user_email;
									$company_rank_NAME[($item->ranking)] = $item->company_title;
									//$company_rank_POINTS[($item->ranking)] = 0;
								}
								
								
								//dev only ranked are stored !!
								//echo $company_rank[$item->user_id]." ".$company_points[$item->user_id]." ".$company_rank[$item->user_id]."<br>";
						 } 
						 
					

		  
		  
				 
				 
		//loop through ALL users
		foreach ($users as $user){		
		
	
		
		//$createDate = new DateTime($date);
		//$date2 = $createDate->format('Y-m-d');
		

		
			if($user->email !=''){
				
				//DEV
				//echo $user->company."<br>";
	
	
                   		
                   	 				
				
				
						$company_rank2=0;
						$company_points2=0;	
									
						$company_higher_name='';
						$company_higher_points =0;
						
						$points_diff=0;
						$company_higher='';
						$company_higher_en='';
						
			
						if(isset($company_rank[$user->id]) && isset($company_points[$user->id])){
				
					
							$company_rank2=$company_rank[$user->id];
							$company_points2=$company_points[$user->id];
							
							
							
							if($company_rank2>0){
							$company_higher_name = $company_rank_NAME[($company_rank2)-1];
							$company_higher_points = $company_rank_POINTS[($company_rank2)-1];
							}
							
						}
						
						$points_diff  = ($company_higher_points) -($company_points2);
						
						
						if ($points_diff>0){
							$company_higher = "juste derrière la société: ".$company_higher_name." (".$company_higher_points."points) (+".$points_diff." points)";							
							$company_higher_en = "just behind the company: ".$company_higher_name." (".$company_higher_points."points) (+".$points_diff." points)";
					    }
					    
					   
		  
		  
		  					if($devmode){
						   		echo 'USER EMAIL [COMPANY]:'.$user->company .", ".$company_rank2."<br>";
							}
						
						//DEV	
						//if($user->email =="emmanuel@corporate-games.fr" ){
						if($user->email =="jean-francois.sellier@talan.com"){
						
					 
							
							///ONLY EMAIL SEND TO 
							if($devmode){
								$user->email= "liquidskyweb@gmail.com";
							}
							
						
							 
							\Mail::send('emails.updatesuser', ['company' => $user->company, 'email' => $user->email, 'first_name' => ucwords($user->first_name), 'company_rank' => $company_rank2, 'company_points' => $company_points2, 'company_higher' => $company_higher, 'company_higher_en' => $company_higher_en], function($message) use ($user){
								$message->from('no-reply@workn-sport.com', 'Work’N Sport – Le 1er challenge connecté solidaire multisports pour entreprises');
								$message->to($user->email, $user->first_name, $user->last_name)
										->subject('Votre classement hebdomadaire Work’N Sport | Your weekly Work’N Sport ranking');
							}); 
							
							
					
						}
						 
						
			
					
			
				
		
				
				
			}

			

			
		}	
				

echo "======================<br><br><br>";

////////////////
////////////////
////////////////
////////////////
////////////////
//////////////// TEAMS
////////////////
////////////////
////////////////
////////////////
////////////////


		

		   
		   //participants to loop through
		   $participants = DB::table('participants')
		   ->join('teams', 'participants.id_team', '=', 'teams.id')
		   ->join('users', 'participants.id_user', '=', 'users.id')		   
		   ->selectRaw('participants.id, participants.id_user, participants.email, participants.first_name, participants.last_name, teams.title as team_title, users.company as team_company, users.private_challenge')
		   ->where('users.private_challenge',0)	 	   
		   ->groupBy('id_team')		
		   ->orderBy('participants.id_user', 'asc')	 
		   ->orderBy('participants.first_name', 'asc')	  
		   ->get();
		   

		
		
						//STORE TEAM RANKINGS
						DB::statement(DB::raw('set @row=0'));
						$teams_ranking_RANK = DB::select("
				
						SELECT *, @row := @row + 1 as ranking  FROM (SELECT  						 			
						p.id as participant_id,
						p.email as email,
						u.company as company_title,
						u.id as user_id, 
						t.id as id_team, 
						t.title as team_title, 
                        IFNULL(sum(p.pts) , 0) AS pts_total
                        FROM participants 
                        AS p                     
                                                  
                        JOIN  (SELECT id, email_updates, company, private_challenge FROM users)
                        AS u ON p.id_user = u.id 
                        
                        JOIN  (SELECT id, title FROM teams)
                        AS t ON p.id_team = t.id 
                        
                   		WHERE (p.pts !=-1   			
            			AND u.private_challenge = 0)		
            			
            			GROUP BY id_team
            			ORDER BY pts_total DESC, company_title ASC

      		
                   		) r ");  
                   		
           
                   		 
                   		 
                   		$team_rank = Array();
                   		$team_points = Array();
                   		
                   		$team_rank_NAME = Array();
						$team_rank_NAME[0]='';
						
						$team_rank_POINTS = Array();
						$team_rank_POINTS[0]='';
						
						 //loop through ALL teams
						 foreach ($teams_ranking_RANK as $item){
						 
						 
								$team_rank_NAME[$item->ranking]='';
								$team_rank_POINTS[$item->ranking]='';
								
								$team_points[$item->participant_id] = $item->pts_total;
								
								if($item->pts_total >0){
									$team_rank[$item->participant_id] = $item->ranking;
									$team_rank_NAME[($item->ranking)] = $item->team_title;
									$team_rank_POINTS[($item->ranking)] = $item->pts_total;
									//echo $item->ranking."<br>"; 
								}else{
									$team_rank[$item->participant_id] = $item->ranking;
									$team_rank_NAME[($item->ranking)] = $item->team_title;
									$team_rank_POINTS[($item->ranking)] = 0;
								}
								  
								  
								  
								
								//dev only ranked are stored !!
								//echo $team_rank[$item->id_user]." ".$team_points[$item->id_user]." ".$team_rank[$item->id_user]."<br>";
						 } 
						 
					

		  
		  
				 
				 
		//loop through ALL participants
		foreach ($participants as $participant){		
		
	

		
			if($participant->email !=''){
				
				//DEV
				//echo $user->team."<br>";
	
	
                   		
            
				
						///COMPANY INFO
						////////////////////////
						$ID_USER = $participant->id_user;
						
			
						$company_rank2=0;
						$company_points2=0;	
									
						$company_higher_name='';
						$company_higher_points =0;
						
						$points_diff=0;
						$company_higher='';
						$company_higher_en='';
						
						
						
						if(isset($company_rank[$ID_USER]) && isset($company_points[$ID_USER])){
					
							$company_rank2=$company_rank[$ID_USER];
							$company_points2=$company_points[$ID_USER];
	
							if($company_rank2>0){
							$company_higher_name = $company_rank_NAME[($company_rank2)-1];
							$company_higher_points = $company_rank_POINTS[($company_rank2)-1];
							}
							
						}
						
						$points_diff  = ($company_higher_points) -($company_points2);
						
						
						if ($points_diff>0){
							$company_higher = "juste derrière la société: ".$company_higher_name." (".$company_higher_points."points) (+".$points_diff." points)";							
							$company_higher_en = "just behind the company: ".$company_higher_name." (".$company_higher_points."points) (+".$points_diff." points)";
					    }
					    ////////////////////////
		  
		
		
		
				
						  // echo 'COMPANY EMAIL: Bonjour '.$company_rank_FIRST_NAME[($company_rank2)].', '. $company_rank_NAME[($company_rank2)] ." ".$company_points2." ".$company_higher."<br><br>";
					
						
						
						
						   
						   
						    
				
						$team_rank2=0;
						$team_points2=0;	
									
						$team_higher_name='';
						$team_higher_points =0;
						
						$points_diff=0;
						$team_higher='';
						$team_higher_en='';
						
		
						
						if(isset($team_rank[$participant->id]) && isset($team_points[$participant->id])){
					
							$team_rank2=$team_rank[$participant->id];
							$team_points2=$team_points[$participant->id];
							
							
							
							if($team_rank2>0){
							$team_higher_name = $team_rank_NAME[($team_rank2)-1];
							$team_higher_points = $team_rank_POINTS[($team_rank2)-1];
							}
							
						}
						
						$points_diff  = ($team_higher_points) -($team_points2);
						
						
						if ($points_diff>0){
							$team_higher = "juste derrière l'équipe: ".$team_higher_name." (".$team_higher_points."points) (+".$points_diff." points)";							
							$team_higher_en = "just behind the team: ".$team_higher_name." (".$team_higher_points."points) (+".$points_diff." points)";
					    }
					    
		
		
							if($devmode){
								echo 'PARTICIPANT EMAIL [COMPANY]:'.$company_rank_NAME[($company_rank2)].', '.$company_rank2."<br>";
								echo 'PARTICIPANT EMAIL [TEAM]:'.$participant->team_title .', '.$team_rank2.'<br><br>';
							}


					   	//DEV
						//if($participant->email =="emmanuel@qyd.fr"){
						if($participant->email =="jean-francois.sellier@talan.com"){
						
				
					
							
							///ONLY EMAIL SEND TO 
							if($devmode){
								$participant->email= "liquidskyweb@gmail.com";
							}
						
						
							\Mail::send('emails.updatesparticipant', ['company' => $company_rank_NAME[($company_rank2)], 'email' => $participant->email, 'first_name' => ucwords($participant->first_name), 'company_rank' => $company_rank2, 'company_points' => $company_points2, 'company_higher' => $company_higher, 'company_higher_en' => $company_higher_en, 'team_title' => $participant->team_title, 'email' => $participant->email, 'first_name' => ucwords($participant->first_name), 'team_rank' => $team_rank2, 'team_points' => $team_points2, 'team_higher' => $team_higher, 'team_higher_en' => $team_higher_en], function($message) use ($participant){
								$message->from('no-reply@workn-sport.com', 'Work’N Sport – Le 1er challenge connecté solidaire multisports pour entreprises');
								$message->to($participant->email, $participant->first_name, $participant->last_name)
										->subject('Votre classement hebdomadaire Work’N Sport | Your weekly Work’N Sport ranking');
							}); 
						
		
					
						
						}
						
			
					
			
				
		
				
				
			}

			

			
		}	
				




				
	
?>

