<?php

//DB CONNECTION
$db = new mysqli('localhost', 'root', 'WgZ5z0520LIsql', 'forge');

if($db->connect_errno > 0){
    die('Unable to connect to database [' . $db->connect_error . ']');
}

