<?php


error_reporting(0);

session_start();



//Access laravel sesssion
require '../bootstrap/autoload.php';
$app = require_once '../bootstrap/app.php';
$app->make('Illuminate\Contracts\Http\Kernel')
    ->handle(Illuminate\Http\Request::capture());
  
/*
$data= Array();

$data['email'] ="Client email";
$data['first_name'] ="First name";
$data['last_name'] ="Last name";

use Mail;
Mail::send('emails.notify', ['email' => $data['email'], 'first_name' => $data['first_name'], 'last_name' => $data['last_name']], function ($m) use ($data){
	$m->from('info@workn-sport.com', 'workn-sport');
	$m->to('liquidskyweb@gmail.com', 'DG')->subject('Merci pour votre inscription Work-nSport:');
});
*/

				
				

	
	
$isAuthorized = Auth::check();

//if logged in and user id is in url
if (!$isAuthorized || Auth::user()->id != $_GET['user_id']){
echo "Permission denied";exit;
}


error_reporting(0);




require_once('config.php');




	
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title></title>
	
<style>
body {
	font-family: "lucida grande","Segoe UI", Arial, sans-serif; 
	font-size: 11px;
	
	background-color: #ffffff;
}


table.border_yes {
    border-collapse: collapse;
}


table.border_yes, table.border_yes td {
   border: 1px solid #c6c6c6;
} 

table.border_no, table.border_no td {
   border: 0px solid #c6c6c6;
   font-size: 11px;
} 

</style>

</head>



<body>
<center>
<div style="width:700px;" align="center">





		<?php
		
		$sql ="SELECT * from users WHERE id ='".$_GET['user_id']."'  ";
		if(!$user = $db->query($sql)){
			die('There was an error ['.$db->error.']');
		}		
	
		while($row = $user->fetch_assoc()){
			$company_name =$row['company'];
		}
	
	

		
		
		
		$sql ="SELECT * from invoices WHERE id ='".$_GET['id']."'  ";
		if(!$invoice = $db->query($sql)){
			die('There was an error ['.$db->error.']');
		}
	
			

		while($row = $invoice->fetch_assoc()){
		
		
		
		
		$address = $row['company'].'<br>';
		$address .= $row['address'].'<br>';
		$address .= $row['postcode'].' ';
		$address .= $row['city'].'<br>';;
		
		if ($row['country'] =='fr'){$address .= 'France<br><br>';;}
		
		
		$contact = $row['first_name'].' ';
		$contact .= $row['last_name'].'<br>';
		$contact .= $row['phone'].'<br>';
		$contact .= $row['email'].'<br>';

		$total = ($row['amount']/100);
		$number_of_participants = $row['qty'];
		$unit_cost = ($total/$number_of_participants);
		
		$date = $row['created_at'];
		$inv_num =$row['id'];
		}
	
	



		

		$running_cost= 0;
		
		?>
		
		
<div style="text-align:center">
<b>FACTURE</b><br>
<b>INSCRIPTION A WORK-N-SPORT</b><br>					
The Corporate Connected Multi-sports Challenge<br><br>						
</div>




<table  style="width:700px" class="border_yes" cellpadding="6"  align="center">


<tr>
<td colspan="7">

	<table class="border_no">
	<tr>

	<td valign ="top" style="width:430px">

	
	<b>Adresse de facturation</b><br>
	
	<?php echo $address;?>
	
	<br>
	<br>
	<b>Contact</b><br>
	<?php echo $contact;?>
	</td>
	
	</td>
	
	<td valign ="top">

	<b>QYD Cathay - Work’N Sport</b><br>
	6C Impasse des Michaudes<br>
	74 940 Annecy-le-Vieux<br><br>

	Téléphone :  +33674119757<br>
	N° de TVA : 00000000000000<br>
	N° SIRET : 49387574400069<br><br>
	
	<span style="font-size:9px;">
	Coordonnées bancaires<br>
	RIB : 00000 00000 00000000000 00 CE RHONE ALPES<br>
	IBAN : FR00 0000 0000 0000 0000 0000 000<br>
	BIC : 00000000000<br>
	</span>
	

	</td>

	</tr>
	</table>




</td>
</tr>


			
<tr>
	<td align="left" colspan="2" valign ="top" style="font-size:11px;">
	Date de facturation : <?php echo date('Y-m-d',strtotime($date)); ?><br>

	</td>
	

	
	<td valign ="top" colspan="5"  align="right" style="font-size:11px;">
	Numéro : <?php echo $inv_num.'-'.$code.'-'.strtoupper($company_name) ?><br>
	Conditions de règlement : 100% à réception de la facture
	</td>

</tr>




<tr>
<td><b>Description</b></td>
<td align="right"><b>Coût Unitaire HT</b></td>
<td align="right"><b>Quantité</b></td>
<td align="right"><b>Total HT</b></td>
<td align="right"><b>% TVA</b></td>
<td align="right"><b>Montant TVA</b></td>
<td align="right"><b>Total TTC</b></td>
</tr>

<tr>
<td align="left">Inscription WORK-N-SPORT </td>
<td align="right"><?php echo $unit_cost?> €</td>
<td align="right"><?php echo $number_of_participants?></td>
<td align="right"><?php echo ($number_of_participants*$unit_cost)?> €</td>
<td align="right">20%</td>
<td align="right"><?php $total_ = $number_of_participants*$unit_cost*0.2; echo number_format($total_,2);?> €</td>
<td align="right"><?php $total1 = $number_of_participants*$unit_cost*1.2; echo number_format($total1,2); $running_cost=$running_cost+$total1; ?> €</td>
</tr>







<tr><td colspan="6"><b>Total TTC</b></td><td align="right"><b><?php echo number_format($running_cost,2); ?> €</b></td></tr>

</table>






<div style="text-align:center; font-size:11px;">
			

<a href="http://www.work-n-sport.com/" target="_top"><img src="images/logo_worknsport.jpg" style="width:120px; margin: 5px 0 0 0" border="0"></a><br>		
<b><i>Move More, Play More!</i></b><br>
www.work-n-sport.com<br>
</div>



</div>

</center>

</body>
</html>
