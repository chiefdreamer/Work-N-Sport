<?php

//security login check in facture.php


/*
$testGD = get_extension_funcs("gd"); // Grab function list 
if (!$testGD){ echo "GD not even installed."; exit; }
echo"<pre>".print_r($testGD,true)."</pre>";
exit;
*/


session_start();

ob_start();


require_once 'dompdf/dompdf_config.inc.php';
$dompdf = new DOMPDF();




require('facture.php');

$date_time = date("Y-m-d_H-i-s",time());


$dompdf->load_html(ob_get_clean());

$dompdf->render();


//create folder if it does not exist
//if (!file_exists ('invoices/'.$_SESSION['id_company'])){
//	mkdir('invoices/'.$_SESSION['id_company']);
//}

$output = $dompdf->output();


//save to file
//file_put_contents($_SERVER['DOCUMENT_ROOT'].'/inscription/invoices/'.$_SESSION['id_company'].'/facture.pdf', $output);


//download to desktop
$dompdf->stream("facture_worknsport_".$date_time.".pdf");


?>