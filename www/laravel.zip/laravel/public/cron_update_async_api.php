<?php



//REFRESH TOKEN IF CURRENT ACCESS TOKEN NOT VALID
//UPDATE POINTS IF LAST UPDATE WAS MORE THAN 24HRS AGO



//CALLED BY cron_update_async.php



//custom class in libraries folder
use App\Libraries\Moves;

require('/var/www/laravel/app/Libraries/Moves.php');

require('/var/www/laravel/app/Functions/movesConfig.php');

$m = new Moves($client_id,$client_secret,$redirect_url);



error_reporting(0);

session_start();



//Access laravel sesssion
require '/var/www/laravel/bootstrap/autoload.php';
$app = require_once '/var/www/laravel/bootstrap/app.php';
$app->make('Illuminate\Contracts\Http\Kernel')
    ->handle(Illuminate\Http\Request::capture());


	
//$isAuthorized = Auth::check();

//if logged in and user id is in url

//if (!$isAuthorized ){
//echo "Permission denied";exit;
//}


error_reporting(1);


require_once('config.php');


			$id = $_GET['id'];	
			$token = $_GET['access_token'];
			$refresh_token = $_GET['refresh_token'];
			
			
				
			$refresh_data = true;
			
			$userId = '';

	
			
			/*
			echo "USER ID: ".$id."<br>";
			echo "RANGE: ".$range."<br>";
			echo "PTS UPDATED: ".$pts_updated."<br>";
			echo "NOW: ".$now."<br>";
			echo "NOW-RANGE: ".$now-range."<br>";
			echo "IS PTS_UPDATED < NOW-RANGE <br>";
			echo "refresh_data value: ".$refresh_data."<br><br>";
			*/
			
			//exit();
			
			
			
			
  
 
		 	  
			 	
				
			if($token!=''){
			
					//$profile = json_encode($m->get_profile($token));
					//if($profile=="null"){
					
					if ($m->validate_token($token)==false){
					
						//var_dump('PROB WITH ACCESS TOKEN NOW TRYING REFRESH: '.$token."<br><br>");
				
				
				
						//USE REFRESH TOKEN
						//*********************
						$refreshed = $m->refresh($refresh_token, "refresh_token");
						//*********************
						//*********************
						
						//var_dump("TRYING REFRESH TOKEN: ".$refresh_token."<br><br>");
						
					
						
						//$profile = json_encode($m->get_profile($token));						
						//if($profile=="null"){
						
						if ($m->validate_token($refreshed['access_token'])==false){
						
							//var_dump('PROB WITH REFRESHED ACCESS TOKEN'.$refreshed['access_token']."<br><br>");
							
			
	
						}else{
						
						
							//var_dump('REFRESHED TOKEN SUCCESSFUL<br><br>');
							//var_dump($refreshed['access_token']."::".$profile."<br><br>");
							
							
							//UPDATE DB
							//lsm 12/17/16 (added refreshed_at)
							
							if($refreshed['access_token']!= '' && $refreshed['refresh_token']!=''){
								$row1 = DB::table('participants')->where('id', $id)->update(
									['access_token' => $refreshed['access_token'], 'refresh_token' => $refreshed['refresh_token'], 'updated_at' => date('Y-m-d H:i:s'), 'refreshed_at' => date('Y-m-d H:i:s')]
								);
							}
							
							  					
							
							//added // lsm 12/28/16
							if( $refresh_data == true){
								updatePoints($m, $id, $refreshed['access_token']); 
							}
				
				
						}
						
						
					//all good	
					}else{
						//var_dump($token."<br>");
						
						if( $refresh_data == true){
							updatePoints($m, $id, $token);
						}
					}
					
					
				
			}
				
		




 
 
		
				function updatePoints($m, $id, $token){
					
					//default
					$initial_start_date = '2016-04-01';
					
					// Challenge 1
					if(date("Y-m-d") >= '2016-11-07'){$initial_start_date = '2016-11-07';}
					
					
					
					
					   
					// Challenge 2
					// RESET POINTS ONLY ONCE ON 11 JANUARY 2017 
					if(date("Y-m-d") >= '2017-01-10'){$initial_start_date = '2017-01-10';}					
					 
					// Do not clear only divide by 90 approx 3 months to reduce non active moves accounts
					if(date("Y-m-d") == '2017-01-11'){
					
						//reset all pts to 0	
						//$row = DB::table('participants')->where('id','!=',0)->update(['pts' => 0]);	
						
						//copy pts from type to pts (if not 0) and divide by 90
						$row = DB::table('participants')->where('type','!=', 0)->update(['pts' => DB::raw('type/90')]);
					}
					
					
					
					// Challenge 3
					// RESET POINTS ONLY ONCE ON 02 APRIL 2017 AT midnight 
					if(date("Y-m-d") >= '2017-04-02'){$initial_start_date = '2017-04-01';}				
					$now2 =time();

					$date1 ='02-04-2017 00:00:00';
					$date2 ='02-04-2017 00:50:00';

					if ( $now2  > strtotime($date1) && $now2  < strtotime($date2) ){
						//reset all pts to 0	
						$row = DB::table('participants')->where('id','!=',0)->update(['pts' => 0]);	
					}
					
				
					
					// Challenge 4
					// RESET POINTS ONLY ONCE ON 02 JULY 2017 AT midnight 
					if(date("Y-m-d") >= '2017-07-02'){$initial_start_date = '2017-07-01';}			
					$now2 =time();

					$date1 ='02-07-2017 00:00:00';
					$date2 ='02-07-2017 00:50:00';

					if ( $now2  > strtotime($date1) && $now2  < strtotime($date2) ){	
						//reset all pts to 0	
						$row = DB::table('participants')->where('id','!=',0)->update(['pts' => 0]);	
					}
					
					
					
					// Challenge 5
					// POINTS RESET MANUALLY using (cron_update_MANUAL.php)	
					// rebuilt previous points as points deleted :p			
					//if(date("Y-m-d") >= '2017-12-31'){						
					//	$initial_start_date = '2017-07-01';
					//	$initial_end_date = '2017-12-31';
					//}	
										

					if(date("Y-m-d") >= '2017-12-31'){
						$initial_start_date = '2018-01-01';
					}		
		
					
					
					
   

					   
					
					//LOOP THROUGH MONTHS	

					//RESET pts
					$pts = 0;
	
					//$firstDate="";
	
					//FIRST DATE DATA IS AVALABLE FOR USER
					$profile = json_encode($m->get_profile($token));	
					$profile = json_decode($profile);
	
				
					
					
					
					$firstDate = $profile->profile->firstDate;
					$firstDate = strtotime($firstDate);

					$start = $month = strtotime($initial_start_date);	
					$end = time();//END IS NOW :)
					
					if($initial_end_date!=''){
						$end = strtotime($initial_end_date);
					}
	
	
					//REQUIRED FOR CORRECT DATA RANGE			
					//check if firstDate is more recent than start_date if so use firstDate as start_date
					 if ($firstDate > $start){						
						$start = $month = $firstDate;
					 }
	 
					

					//LOOP THROUGH MONTHS
					while($month < $end)
					{
	
							/*				
							Thirty days hath September,
							April, June, and November.
							All the rest have thirty-one,
							Except for February alone,
							Which hath but twenty-eight days clear
							And twenty-nine in each leap year. 
							*/
	
							 // 01 to (30) OF THE CURRENT ITERATED MONTH
			 
			 
							 //current month
							 $start_date =  date('Y-m-d', $month);

			 
							 //last day of iterated month (t)
							 $end_date = date('Y-m-t', $month);
							 
							 	
				
	
				
							 //check if iterated month is more recent than end if so use end as end_date					 
							 if ( date('Y-m-t',$month) > date('Y-m-d',$end) ){
								$end_date = date('Y-m-d', $end);
							 }


							$summary = json_encode($m->get_range($token,'/user/summary/daily',$start_date, $end_date ));
			

			
							if (isset($summary)) {

										//get pts
										
								
																	
						
										foreach (json_decode($summary) as $item){
						
												if (isset($item->summary[0])) {
				
									
														if (isset($item->summary[0])) {
														
															//if($item->summary[0]->group != "transport"){										
															//	$pts_data = ($item->summary[0]->duration);
															//	$pts = $pts + $pts_data;
															//}
															
															// lsm 11/15/16
															//LOOP THROUGH ACTIVITY GROUPS !!!
															foreach ($item->summary as $item2){
														
																if($item2->group != "transport"){										
																	$pts_data = ($item2->duration);
																	$pts = $pts + $pts_data;
																	
																
																	//echo $item->date.": ".$item2->group.": ".round(($pts_data/60.0),0)."min <br>";
																
																}
																
															}
															
															
														} 
	
									
												}									
			
										}
		
							}
	
	
	
								// ITERATE TO NEXT MONTH
								// FIXED PROB OF PG points, next datedate was being set to +1 =31-05-2016 instead of 02-05-2016)
								
								
								// lsm 2/17/17
								$month = strtotime(date('Y-m-01', $month));
								$month = strtotime("+1 month", $month);

 
			 
					}
					//END LOOP THROUGH MONTHS

			
							//convert to minutes
							$pts = ($pts/60.0);
			
			
							//save pts to db (NEW PARTICIPANTS WILL HAVE DIFFERENT TIME STAMPS)
							
							//had to hide to reset point start of 2018
							if($pts>0){
								//var_dump($participant->participant_id." ".$token." ".$pts."<br>");
								
								
								//userID
								$profile2 = json_encode($m->get_profile($token));	
								$profile2 = json_decode($profile2);
								$userId = $profile2->userId;   
									

		    
									$row = DB::table('participants')->where('id', $id)->update(
									['moves_id_user' => $userId, 'pts' => $pts, 'pts_updated' => date('Y-m-d H:i:s')]);
								
	
							} 


 

				}		

	
?>