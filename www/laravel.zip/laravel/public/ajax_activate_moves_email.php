<?php


//USED TO ACTIVATE MOVES BY SENDING EMAIL TO PARTICIPANT



//custom class in libraries folder
use App\Libraries\Moves;
require('/var/www/laravel/app/Libraries/Moves.php');
require('/var/www/laravel/app/Functions/movesConfig.php');
$m = new Moves($client_id,$client_secret,$redirect_url);




//Access laravel sesssion
require '/var/www/laravel/bootstrap/autoload.php';
$app = require_once '/var/www/laravel/bootstrap/app.php';
$app->make('Illuminate\Contracts\Http\Kernel')
    ->handle(Illuminate\Http\Request::capture());






   



	

require_once('config.php');



		$participants = DB::table('participants')
		   ->selectRaw('participants.id, participants.email, participants.first_name, participants.last_name, participants.refresh_token')   
		   ->where('participants.id','=',$_POST['participant_id'])
		   ->limit(1)
		   ->get();
		   
	
	
	     
	
				 
		//loop through ALL participants
		foreach ($participants as $participant){		
		

	
			if($participant->email !=''){

						// lsm 12/15/16 (removed location scope)
						// $activate_url = "https://api.moves-app.com/oauth/v1/authorize?response_type=code&client_id=t6HNc4_kcmXx4PUDTXBjJ8agBS41drZu&scope=activity+location&redirect_uri=http://www.workn-sport.com/moves&state=".$participant->id;
						$activate_url = "https://api.moves-app.com/oauth/v1/authorize?response_type=code&client_id=t6HNc4_kcmXx4PUDTXBjJ8agBS41drZu&scope=activity&redirect_uri=http://www.workn-sport.com/moves&state=".$participant->id;

						 
				
						
							\Mail::send('moves.authorize', ['email' => $participant->email, 'first_name' => ucwords($participant->first_name), 'activate_url' => $activate_url], function($message) use ($participant){
								$message->from('info@workn-sport.com', 'Work’N Sport – Le 1er challenge connecté solidaire multisports pour entreprises');
								$message->to($participant->email, $participant->first_name, $participant->last_name)
										->subject('Work-n-Sport | Activez l’app Moves');
							});
		
							echo "Email envoyé à : ".$participant->email;exit();
				
				
			}

			 

			
		}	
				
 

echo "Erreur";exit();
				
	
?>

