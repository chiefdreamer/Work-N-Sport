<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title></title>
	
	<style>
	body{
		font-family: arial;
		font-size: 14px;	  
	} 
	</style>
</head>
<body>




<?php


//REFRESH TOKEN IF CURRENT ACCESS TOKEN NOT VALID
//UPDATE POINTS IF LAST UPDATE WAS MORE THAN 24HRS AGO


// CALLS FILE BELOW to save pts to db
// cron_update_async_api.php




//custom class in libraries folder
use App\Libraries\Moves;

require('/var/www/laravel/app/Libraries/Moves.php');

require('/var/www/laravel/app/Functions/movesConfig.php');

$m = new Moves($client_id,$client_secret,$redirect_url);




error_reporting(0);

session_start();



//Access laravel sesssion
require '/var/www/laravel/bootstrap/autoload.php';
$app = require_once '/var/www/laravel/bootstrap/app.php';
$app->make('Illuminate\Contracts\Http\Kernel')
    ->handle(Illuminate\Http\Request::capture());



	
//$isAuthorized = Auth::check();

//if logged in and user id is in url

//if (!$isAuthorized ){
//echo "Permission denied";exit;
//}


error_reporting(0);


	
	


echo "<b>".$_GET['name']."</b>";

require_once('config.php');

		if($_GET['email']!=''){
			$email_to_check=$_GET['email'];
		}
		
		if($_GET['id']!=''){
			$id_to_check=$_GET['id'];
		}
		
		//->where('participants.email','=', $email_to_check)
		$participants = DB::table('participants')
		   ->selectRaw('participants.first_name, participants.last_name, participants.pts_updated, participants.access_token, participants.refresh_token, participants.id_team ,participants.id_user, participants.id')   
		   ->where('participants.id','!=',0)
		   ->where('participants.access_token','!=', '')		   
		   ->when($email_to_check, function ($q) use ($email_to_check) {
				return $q->where('email', $email_to_check); 
			})
			->when($id_to_check, function ($q) use ($id_to_check) {
				return $q->where('id', $id_to_check); 
			})
		   ->orderBy('participants.id_team', 'ASC')
		   ->orderBy('participants.first_name', 'ASC')
		   ->get();
		   
		   
		$curl_array = Array();
		
		//loop throug all participants
		foreach ($participants as $participant){		
		
		
		
		$date = $participant->pts_updated;
		$createDate = new DateTime($date);
		$date2 = $createDate->format('Y-m-d');



			//if access token present		
			if($participant->access_token !=''){
				$curl_array[]['url'] ="http://www.workn-sport.com/_api2_ACTIVITY_DETAILS_READONLY.php?id=".$participant->id."&access_token=".$participant->access_token."&refresh_token=".$participant->refresh_token."&pts_updated=".$date2;
				//echo "http://www.workn-sport.com/update_async_api.php?id=".$participant->id."&access_token=".$participant->access_token."&refresh_token=".$participant->refresh_token."&pts_updated=".$date2."<br>";
			}
		}	
				


			// create cURL resource
			$c=0;
			foreach ($curl_array as $curl){
				${'ch_'.$c} = curl_init();
				$c++;
			}



			// set URL and other appropriate options			
			$c=0;
			foreach ($curl_array as $curl){
				curl_setopt(${'ch_'.$c}, CURLOPT_URL, $curl['url']);
				curl_setopt(${'ch_'.$c}, CURLOPT_HEADER, 0);
				$c++;
			}

			//create the multiple cURL handle
			$mh = curl_multi_init();


			//add the handle
			$c=0;
			foreach ($curl_array as $curl){
				curl_multi_add_handle($mh,${'ch_'.$c});
				$c++;
			}
			
			

			$active = null;
			//execute the handle
			do {
				$mrc = curl_multi_exec($mh, $active);
			} while ($mrc == CURLM_CALL_MULTI_PERFORM);

			while ($active && $mrc == CURLM_OK) {
				if (curl_multi_select($mh) != -1) {
					do {
						$mrc = curl_multi_exec($mh, $active);
					} while ($mrc == CURLM_CALL_MULTI_PERFORM);
				}
			}






			//close the handle	
			$c=0;
			foreach ($curl_array as $curl){
			
				/*
				$httpCode 	= curl_getinfo(${'ch_'.$c}, CURLINFO_HTTP_CODE);
				$url      	= curl_getinfo(${'ch_'.$c}, CURLINFO_EFFECTIVE_URL);
				if ( $httpCode != 200 ){
					echo $url." Error<br>";
				} else {
					echo " Success ".$html."<br>";
				}
				*/
	
			
				curl_multi_remove_handle($mh, ${'ch_'.$c});
				$c++;
			}
			
			
			curl_multi_close($mh);


		
	
?>

</body>
</html>

