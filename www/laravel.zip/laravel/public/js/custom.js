

//croppic
/*
$(function(){

    var eyeCandy = $('#cropContainerEyecandy');
    var croppedOptions = {
        uploadUrl: 'upload',
        cropUrl: 'crop',
        cropData:{
            'width' : eyeCandy.width(),
            'height': eyeCandy.height()
        }
    };
    var cropperBox = new Croppic('cropContainerEyecandy', croppedOptions);

});    
*/

    


function isValidEmailAddress(emailAddress) {
    var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
    return pattern.test(emailAddress);
};


function activate_moves(participant_id, email){
	

		
		if( !isValidEmailAddress(email) ) {
			alert("Une adresse email valide est requise");
			return false;		
		}
		
		$.ajax({
		   type: "POST",
			url: "ajax_activate_moves_email.php", 
			data: {"participant_id":participant_id},
			success: function (output) {
				 alert(output);
			}
		});
    


};



function activate_moves_not_logged_in(){
	

		var email =$("#email").val();
		
		
		if( !isValidEmailAddress(email) ) {
			alert("Une adresse email valide est requise");
			return false;		
		}
		
		$.ajax({
		   type: "POST",
			url: "/ajax_activate_moves_email_not_logged_in.php", 
			data: {"email":email},
			success: function (output) {
				 alert(output);
			}
		});
    


};


// lsm 11/13/16
function test_moves_token_not_logged_in(){
	
		var email =$("#email").val();
		
		
		if( !isValidEmailAddress(email) ) {
			alert("Une adresse email valide est requise");
			return false;		
		}
		
		$.ajax({
		   type: "POST",
			url: "/ajax_test_token.php", 
			data: {"email":email},
			success: function (output) {
				 alert(output);
			}
		});
    

};

  
    
//multiselect
$(function(){
	$('#cg_cities').multiselect();
});

    
    
    
//online orders




$(function(){
  //called when key is pressed in textbox
  $("#qty").keyup(function (e) {
     //if the letter is not digit then display error and don't type anything
  
     //8: backspace     
     //48-57: 0-9
     //16: shift (nneded for azerty keyboard numbers)
     
     
     
    // alert(e.which);
     
     if (e.which != 8 && e.which != 0 && e.which != 16 && (e.which < 48 || e.which > 57)) {
        //display error message
        $("#errmsg").html("Numéros uniquement").show().fadeOut("slow");
        		$('#qty').val('');
               	return false;
    }

    updateTotal();
  
    

	});
}); 

  
  
  

    
	$('#payment_type').change( function() {
		updateTotal();
	});


function updateTotal(){

	
	$('#total').text("");
	
	
	var total=0;
	var qty = $('#qty').val();
	var pricing = Array();
	


	
	if($('#payment_type').val()=="monthly_1"){
		var pricing= Array(2, 1.9, 1.8);
	}
	
	if($('#payment_type').val()=="monthly_3"){
		var pricing= Array(6, 5.7, 5.4);
	}
	
	if($('#payment_type').val()=="monthly_6"){
		var pricing= Array(12, 11.4, 10.8);
	}
	
	if($('#payment_type').val()=="monthly_9"){
		var pricing= Array(18, 17.1, 16.2);
	}
	
	
	
	if($('#payment_type').val()=="annual_2016"){
		var pricing= Array(11, 10, 9);
	}
	
	if($('#payment_type').val()=="annual_2017"){
		var pricing= Array(19, 18, 17);
	}
	
	// lsm 10/13/16
	if($('#payment_type').val()=="annual_2016_2017"){
		var pricing= Array(5, 5, 5);
	}




	qty = parseFloat(qty);
	if (qty >0 && qty <=299){
		total = qty*parseFloat(pricing[2]);
	}
	
	if (qty >0 && qty <=199){
		total = qty*parseFloat(pricing[1]);
	}
	
	if (qty >0 && qty <=99){
		total = qty*parseFloat(pricing[0]);
	}
	
	
	
	
	
	//total = Math.round(total * 100) / 100
	total = total.toFixed(2);
	total_cents = (total*100);
	$('#total').text(total+" €");
	
	
	
	
	if (qty >299){
		$('#total').text('');
		 $("#errmsg").html("Merci de nous contacter").show().fadeOut("slow");
		 return false;
	}
	
	
	if(total_cents==''){
		//alert('no total');
	}
	
	$('#id_amount').val(total_cents);
	
	$('#id_vads_order_info').val($('#payment_type').val()); //duration
	$('#id_vads_order_info2').val($('#qty').val()); //qty
	


	
};



function checkTotal(){
	updateTotal();
	
		
		//'1'  = 'Annecy-le-Vieux'
		//'2'  = 'Marseille'
		//'3'  = 'Puteaux'
		
		
	
		if($('#payment_type').val()=="annual_2016_2017"){
			if($.inArray("1", cg_cities) == -1 && $.inArray("2", cg_cities) == -1 && $.inArray("3", cg_cities) == -1){
				alert('Veuillez completer le lieu du Corporate Games en France');
				document.location.href="/account";
				return false;
			}
		}
		
		
		if($('#id_vads_cust_legal_name').val()==''){
			alert('Veuillez completer le nom de votre société dans votre compte');
			document.location.href="/account";
			return false;
		}
		
		if($('#id_vads_cust_address').val()==''){
			alert('Veuillez completer votre adresse dans votre compte');
			document.location.href="/account";
			return false;
		}
		
		if($('#id_vads_cust_city').val()==''){
			alert('Veuillez completer votre ville dans votre compte');
			document.location.href="/account";
			return false;
		}
		
		if($('#id_vads_cust_zip').val()==''){
			alert('Veuillez completer votre code postal dans votre compte');
			document.location.href="/account";
			return false;
		}
		
		if($('#id_vads_cust_country').val()==''){
			alert('Veuillez completer votre pays dans votre compte');
			document.location.href="/account";
			return false;
		}
		

		

	
	
	if($('#id_amount').val()=='' || $('#id_amount').val()=='0'){
		alert('Veuillez choisir le nombre de participants et la durée de l’inscription');
		return false;
	}else{	
	  $("#form_order").submit()
	}
}



function validatePasswordCheck(){


		if($('#company').val()==''){
			alert('Veuillez saisir le no de votre société');
			//document.location.href="/account";
			return false;
		}
		
		if($('#first_name').val()==''){
			alert('Veuillez saisir votre prénom');
			//document.location.href="/account";
			return false;
		}
		
		if($('#last_name').val()==''){
			alert('Veuillez saisir votre nom');
			//document.location.href="/account";
			return false;
		}
		
		if($('#email').val()==''){
			alert('Veuillez saisir votre email');
			//document.location.href="/account";
			return false;
		}
		
		
		if($('#phone').val()==''){
			alert('Veuillez saisir votre numéro de téléphone');
			//document.location.href="/account";
			return false;
		}
		
		
		if($('#address').val()==''){
			//alert('Veuillez saisir votre adresse');
			//document.location.href="/account";
			//return false;
		}
		
		if($('#city').val()==''){
			//alert('Veuillez saisir votre ville');
			//document.location.href="/account";
			//return false;
		}
		
		if($('#postcode').val()==''){
			//alert('Veuillez saisir votre code postal');
			///document.location.href="/account";
			//return false;
		}
		
		
		if($('#country').val()==''){
			alert('Veuillez saisir votre pays');
			//document.location.href="/account";
			return false;
		}
		
		
		if($('#password').val()==''){
			alert('Veuillez saisir votre mot de passe');
			//document.location.href="/account";
			return false;
		}

		if($('#password_confirmation').val()==''){
			alert('Veuillez confirmer votre mot de passe');
			//document.location.href="/account";
			return false;
		}
		
}		







//ANIMATIONS

$(function () {
    setInterval(function () {
        $('#dashboard_link1').fadeTo('slow', 0.3).fadeTo('slow', 1.0);
    }, 2000);
    
    setInterval(function () {
        $('#dashboard_link2').fadeTo('slow', 0.3).fadeTo('slow', 1.0);
    }, 2000);



	//CAROUSEL SWIPE
   $("#carousel-example-generic").carousel()
   
	
});




function getCode(url){	

	if($("#id_participant").val() ==''){
		alert('Veuillez sélectionner un participant');
	}else{
		document.location.href=url+"&state="+$("#id_participant").val();
	}

}





//DELETE
//Dialog show event handler 
$('#confirmDelete__TARGET').on('show.bs.modal', function (e) {
  //set title/message
  $message = $(e.relatedTarget).attr('data-message');
  $(this).find('.modal-body p').text($message);
  $title = $(e.relatedTarget).attr('data-title');
  $(this).find('.modal-title').text($title);

  // Pass form reference to modal for submission on yes/ok
  var form = $(e.relatedTarget).closest('form');
  $(this).find('.modal-footer #confirm').data('form', form);
});

//Form confirm ('delete') handler, submits form
$('#confirmDelete__TARGET').find('.modal-footer #confirm').on('click', function(){
  $(this).data('form').submit();
});






//ADD NEW TEAM
//Dialog show event handler 
//default values for participant 1 from main account (see controller + view)
$('#confirmAdd__TARGET').on('show.bs.modal', function (e) {

	//get data-... VALUES STORED IN "ADD NEW TEAM" BUTTON
  	  	
  	$first_name1 = $(e.relatedTarget).attr('data-first_name1');
  	$last_name1 = $(e.relatedTarget).attr('data-last_name1');
  	$email1 = $(e.relatedTarget).attr('data-email1');

	$(this).find('#first_name1').val($first_name1);
	$(this).find('#last_name1').val($last_name1);
	$(this).find('#email1').val($email1);
  	
});








//UPDATE TEAMS/ PARTICIPANTS
//Dialog show event handler 
$('#confirmUpdate__TARGET').on('show.bs.modal', function (e) {

	//get data-...  VALUES STORED IN "EDIT" BUTTON
	
	$id = $(e.relatedTarget).attr('data-id');
  	$title = $(e.relatedTarget).attr('data-title');
  	$description = $(e.relatedTarget).attr('data-description');
  	
  	
  	$moves1 = $(e.relatedTarget).attr('data-moves1');
  	$first_name1 = $(e.relatedTarget).attr('data-first_name1');
  	$last_name1 = $(e.relatedTarget).attr('data-last_name1');
  	$email1 = $(e.relatedTarget).attr('data-email1');
  	
  	$moves2 = $(e.relatedTarget).attr('data-moves2');
  	$first_name2 = $(e.relatedTarget).attr('data-first_name2');
  	$last_name2 = $(e.relatedTarget).attr('data-last_name2');
  	$email2 = $(e.relatedTarget).attr('data-email2');
  	
  	$moves3 = $(e.relatedTarget).attr('data-moves3');
  	$first_name3 = $(e.relatedTarget).attr('data-first_name3');
  	$last_name3 = $(e.relatedTarget).attr('data-last_name3');
  	$email3 = $(e.relatedTarget).attr('data-email3');
  	
  	
  	//set modal fields
  	$(this).find('#id').val($id);
	$(this).find('#title').val($title);
	$(this).find('#description').val($description);
	
	
	$(this).find('#moves1').html($moves1);
	$(this).find('#first_name1').val($first_name1);
	$(this).find('#last_name1').val($last_name1);
	$(this).find('#email1').val($email1);
	
	$(this).find('#moves2').html($moves2);
	$(this).find('#first_name2').val($first_name2);
	$(this).find('#last_name2').val($last_name2);
	$(this).find('#email2').val($email2);
	
	$(this).find('#moves3').html($moves3);
	$(this).find('#first_name3').val($first_name3);
	$(this).find('#last_name3').val($last_name3);
	$(this).find('#email3').val($email3);
	

	
});










/*!
 * Laravel-Bootstrap-Modal-Form (https://github.com/JerseyMilker/Laravel-Bootstrap-Modal-Form)
 * Copyright 2015 Jesse Leite - MIT License
 *
 * Bromance:
 * Adam Wathan has nice boots. Thank you for BootForms magic.
 * Matt Higgins has nice beard. Thank you for JS wizardry.
 */

$(function() {


        
    // Prepare reset.
    function resetModalFormErrors() {
        $('.form-group').removeClass('has-error');
        $('.form-group').find('.help-block').remove();
    }

    // Intercept submit.
    $('.confirmTeamForm').on('submit', function(submission) {
        submission.preventDefault();



        // Set vars.
        var form   = $(this),
            url    = form.attr('action'),
            submit = form.find('[type=submit]');

        // Check for file inputs.
        if (form.find('[type=file]').length) {

            // If found, prepare submission via FormData object.
            var input       = form.serializeArray(),
                data        = new FormData(),
                contentType = false;

            // Append input to FormData object.
            $.each(input, function(index, input) {
                data.append(input.name, input.value);
            });

            // Append files to FormData object.
            $.each(form.find('[type=file]'), function(index, input) {
                if (input.files.length == 1) {
                    data.append(input.name, input.files[0]);
                } else if (input.files.length > 1) {
                    data.append(input.name, input.files);
                }
            });
        }

        // If no file input found, do not use FormData object (better browser compatibility).
        else {
            var data        = form.serialize(),
                contentType = 'application/x-www-form-urlencoded; charset=UTF-8';
        }

        // Please wait.
        if (submit.is('button')) {
            var submitOriginal = submit.html();
            submit.html('Please wait...');
        } else if (submit.is('input')) {
            var submitOriginal = submit.val();
            submit.val('Please wait...');
        }

        // Request.
        $.ajax({
            type: "POST",
            url: url,
            data: data,
            dataType: 'json',
            cache: false,
            contentType: contentType,
            processData: false

        // Response.
        }).always(function(response, status) {

            // Reset errors.
            resetModalFormErrors();

            // Check for errors.
            if (response.status == 422) {
                var errors = $.parseJSON(response.responseText);

                // Iterate through errors object.
                $.each(errors, function(field, message) {
                    console.error(field+': '+message);
                    var formGroup = $('[name='+field+']', form).closest('.form-group');
                    formGroup.addClass('has-error').append('<p class="help-block">'+message+'</p>');
                });

                // Reset submit.
                if (submit.is('button')) {
                    submit.html(submitOriginal);
                } else if (submit.is('input')) {
                    submit.val(submitOriginal);
                }

            // If successful, reload.
            } else {
                location.reload();
 
            }
        });
    });

    // Reset errors when opening modal.
    $('.AddEditButton').click(function() {
        resetModalFormErrors();
    });

});





