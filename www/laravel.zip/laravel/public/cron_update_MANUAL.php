<?php


//REFRESH TOKEN IF CURRENT ACCESS TOKEN NOT VALID
//UPDATE POINTS IF LAST UPDATE WAS MORE THAN 10HRS AGO


// CALLS FILE BELOW to save pts to db
// cron_update_async_api.php



//block access from browser
//if(php_sapi_name() != "cli"){
   //echo "Access denied"; exit();
//}
	
	 
	
	

//custom class in libraries folder
use App\Libraries\Moves;

require('/var/www/laravel/app/Libraries/Moves.php');

require('/var/www/laravel/app/Functions/movesConfig.php');

$m = new Moves($client_id,$client_secret,$redirect_url);




error_reporting(0);

session_start();



//Access laravel sesssion
require '/var/www/laravel/bootstrap/autoload.php';
$app = require_once '/var/www/laravel/bootstrap/app.php';
$app->make('Illuminate\Contracts\Http\Kernel')
    ->handle(Illuminate\Http\Request::capture());



	
//$isAuthorized = Auth::check();

//if logged in and user id is in url

//if (!$isAuthorized ){
//echo "Permission denied";exit;
//}


error_reporting(0);


	

require_once('config.php');

 
 

		$participants = DB::table('participants')
		   ->selectRaw('participants.first_name, participants.last_name, participants.pts, participants.pts_updated, participants.access_token, participants.refresh_token, participants.id_team ,participants.id_user, participants.id')   		   		   
		   ->where('participants.id','!=',0)
		   ->where('participants.access_token','!=', '')
		   ->orderBy('participants.pts_updated', 'ASC')
		   ->get();
		   
		   
	
			//oldest updated first
			//->orderBy('participants.pts_updated', 'ASC')  DEFAULT
		    
		    //most points first
			// ->orderBy('participants.pts', 'DESC')
			
			//LIMIT 
			//->take(116)
			//->get();
			
		   
		   
		   
		   
		//$curl_array = Array();
		
		//loop throug all participants
		foreach ($participants as $participant){		 
		
		
		
		$date = $participant->pts_updated;
		//$createDate = new DateTime($date); 
		//$date2 = $createDate->format('Y-m-d');
		$date2 = strtotime($date);



			//if access token present		
			if($participant->access_token !=''){
			
				//ONLY DG
				//if($participant->id == 90){ 
				
	
			
				
				$url = "http://www.workn-sport.com/cron_update_async_api.php?id=".$participant->id."&access_token=".$participant->access_token."&refresh_token=".$participant->refresh_token."&pts_updated=".$date2;
				
	
				
			
				$now = date(time());
				//$pts_updated = strtotime($date2);
				$pts_updated = $date2;

				// VARIES PER PARTICIPANT
				// if more than 1 hrs have passed
				// 1*60*60 
		 
		 
		 
		 		//if more than 10 hour has passed
				$range_more = (10*60*60);   //DEFAULT
				
				//if less than 24 hours have passed
				$range_less = (24*60*60);
	
				
				
				
				
				//DEV
				//echo $pts_updated.":".($now-$range)."<br>"; 				
				//if ($pts_updated < ($now-$range)){
				//	echo $participant->id.": refesh: yes"."<br><br>";
				//}else{
				//	echo $participant->id.": refesh: no"."<br><br>";
				//}
			
			
				//if less time has passed
				//if ($pts_updated > ($now-$range_less) ){
				
				//if more time has passed DEFAULT
				if ($pts_updated < ($now-$range_more)){
				
				
					
					//DEV
					echo "CALLED: cron_update_async_api.php?id=".$participant->id."&access_token=".$participant->access_token."&refresh_token=".$participant->refresh_token."&pts_updated=".$date2."<br>";
					
					$curl = curl_init();
					curl_setopt_array($curl, array(
						CURLOPT_RETURNTRANSFER => 1,
						CURLOPT_URL => $url
					));
					$resp = curl_exec($curl);
					curl_close($curl);
				}
				
				
				
				//}
				//END ONLY DG
				
			}
		}	
				




				
	
?>

