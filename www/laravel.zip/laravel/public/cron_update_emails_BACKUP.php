<?php



$devmode = false; 
//$devmode = true; 

//USED TO SEND WEEKLY EMAILS WITH RANKING AND POINTS TO USERS 


//ENABLE BELOW TO ONLY SEND TO info@liquidsky.net
//**********
//**********
//**********
//$devmode = true; 
//**********
//**********
//**********



//block access from browser
if (!$devmode){
	if(php_sapi_name() != "cli"){
	   echo "Access denied"; exit();
	}
}
		

  
  
  





error_reporting(0);

session_start();



//Access laravel sesssion
require '/var/www/laravel/bootstrap/autoload.php';
$app = require_once '/var/www/laravel/bootstrap/app.php';
$app->make('Illuminate\Contracts\Http\Kernel')
    ->handle(Illuminate\Http\Request::capture());






   
	
//$isAuthorized = Auth::check();

//if logged in and user id is in url

//if (!$isAuthorized ){
//echo "Permission denied";exit;
//}





require_once('config.php');



		$users = DB::table('users')
		   ->selectRaw('users.id, users.email_updates, users.company, users.email, users.first_name, users.last_name')   
		   ->where('users.id','!=',0)
		   ->where('users.private_challenge','=',0)
		   ->orderBy('users.company', 'ASC')
		   ->get();
		   
	
	
	
	
	
		
		
		
		
		
						//ALL companies ordered by pts_total
						DB::statement(DB::raw('set @row=0'));
						$companies_ranking_RANK = DB::select("
				
						SELECT *, @row := @row + 1 as ranking  FROM (SELECT  						 			
						p.id,
						p.id_user,
						u.company as company_title,
						u.id as user_id, 
                        IFNULL(sum(p.pts) , 0) AS pts_total
                        FROM participants 
                        AS p                     
                                                  
                        JOIN  (SELECT id, company, private_challenge FROM users)
                        AS u ON p.id_user = u.id 
                        
                   		WHERE (p.pts !=-1   			
            			AND u.private_challenge = 0)		
            			
            			GROUP BY id_user
            			ORDER BY pts_total DESC, company_title ASC

      		
                   		) r ");  
                   		
                   		
                   		$company_rank = Array();
                   		$company_points = Array();
                   		
                   		$company_rank_NAME = Array();
						$company_rank_NAME[0]='';
						
						$company_rank_POINTS = Array();
						$company_rank_POINTS[0]='';
						
						 //loop through ALL companies
						 foreach ($companies_ranking_RANK as $item){
						 
						 
								$company_rank_NAME[$item->ranking]='';
								$company_rank_POINTS[$item->ranking]='';
								
								$company_points[$item->user_id] = $item->pts_total;
								
								if($item->pts_total >0){
									$company_rank[$item->user_id] = $item->ranking;
									$company_rank_NAME[($item->ranking)] = $item->company_title;
									$company_rank_POINTS[($item->ranking)] = $item->pts_total;
									//echo $item->ranking."<br>"; 
								}else{
									$company_rank[$item->user_id] = 0;
									$company_rank_NAME[($item->ranking)] = 0;
									$company_rank_POINTS[($item->ranking)] = 0;
								}
								
								
								//dev only ranked are stored !!
								//echo $company_rank[$item->user_id]." ".$company_points[$item->user_id]." ".$company_rank[$item->user_id]."<br>";
						 } 
						 
					
		  
				 
				 
		//loop through ALL users
		foreach ($users as $user){		
		
	
		
		//$createDate = new DateTime($date);
		//$date2 = $createDate->format('Y-m-d');
		
		$email_updates = $user->email_updates;

		//if access token present		
			if($user->email_updates ==1 && $user->email !=''){
				
				//DEV
				//echo $user->company."<br>";
	
	
                   		
                   	 				
				//DEV
				if($devmode){
				
				
				
						$company_rank2=0;
						$company_points2=0;	
									
						$company_higher_name='';
						$company_higher_points =0;
						
						$points_diff=0;
						$company_higher='';
						$company_higher_en='';
						
						if(isset($company_rank[$user->id]) && isset($company_points[$user->id])){
					
							$company_rank2=$company_rank[$user->id];
							$company_points2=$company_points[$user->id];
							
							
							
							if($company_rank2>0){
							$company_higher_name = $company_rank_NAME[($company_rank2)-1];
							$company_higher_points = $company_rank_POINTS[($company_rank2)-1];
							}
							
						}
						
						$points_diff  = ($company_higher_points) -($company_points2);
						
						
						if ($points_diff>0){
							$company_higher = "Votre classement est just derrière : <br />".$company_higher_name." (".$company_higher_points."pts) (+".$points_diff." pts)";							
							$company_higher_en = "Your ranking is just behind: <br />".$company_higher_name." (".$company_higher_points."pts) (+".$points_diff." pts)";
					    }
					    
					   //DEV
					   
		
					   
					   //ONLY SEND EMAILS TO 
			
						if($user->email =="info@liquidsky.net"){
						
						
						   echo $user->company ." ".$company_points2." ".$company_higher."<br>";
					
						
					 
					 
						
						
							\Mail::send('emails.updates', ['company' => $user->company, 'email' => $user->email, 'first_name' => ucwords($user->first_name), 'company_rank' => $company_rank2, 'company_points' => $company_points2, 'company_higher' => $company_higher, 'company_higher_en' => $company_higher_en], function($message) use ($user){
								$message->from('no-reply@workn-sport.com', 'Work’N Sport – Le 1er challenge connecté solidaire multisports pour entreprises');
								$message->to("info@liquidsky.net", $user->first_name, $user->last_name)
										->subject('Votre classement hebdomadaire Work’N Sport | Your weekly Work’N Sport ranking');
							}); 
						
						}
						 
						
			
					
				}
				
				//PROD
				if(!$devmode){
	
						$company_rank2=0;
						$company_points2=0;	
									
						$company_higher_name='';
						$company_higher_points =0;
						
						$points_diff=0;
						$company_higher='';
						$company_higher_en='';
						
						if(isset($company_rank[$user->id]) && isset($company_points[$user->id])){
					
							$company_rank2=$company_rank[$user->id];
							$company_points2=$company_points[$user->id];
							
							
							
							if($company_rank2>0){
							$company_higher_name = $company_rank_NAME[($company_rank2)-1];
							$company_higher_points = $company_rank_POINTS[($company_rank2)-1];
							}
							
						}
						
						$points_diff  = ($company_higher_points) -($company_points2);
						
						
						if ($points_diff>0){
							$company_higher = "Votre classement est juste derrière : <br />".$company_higher_name." (".$company_higher_points."pts) (+".$points_diff." pts)";
							$company_higher_en = "Your ranking is just behind: <br />".$company_higher_name." (".$company_higher_points."pts) (+".$points_diff." pts)";
					    }
					    
				 
					
						//if($user->email =="emmanuel@corporate-games.fr"){
						
							\Mail::send('emails.updates', ['company' => $user->company, 'email' => $user->email, 'first_name' => ucwords($user->first_name), 'company_rank' => $company_rank2, 'company_points' => $company_points2, 'company_higher' => $company_higher, 'company_higher_en' => $company_higher_en], function($message) use ($user){
								$message->from('no-reply@workn-sport.com', 'Work’N Sport – Le 1er challenge connecté solidaire multisports pour entreprises');
								$message->to($user->email, $user->first_name, $user->last_name)
										->subject('Votre classement hebdomadaire Work’N Sport | Your weekly Work’N Sport ranking');
							});
						
						//}  
						
				}
				
				
			}

			

			
		}	
				



				
	
?>

