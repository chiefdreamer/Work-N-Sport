<?php


exit('no access');

/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2014 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2014 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    1.8.0, 2014-03-02
 */






//ALL PARTICIPANTS WILL BE ADDED FOR TALAN id: 154
//$_SETTINGS_id_user = 154;

//ALL PARTICIPANTS WILL BE ADDED FOR AVRIL id: 188
//$_SETTINGS_id_user = 188;

//ALL PARTICIPANTS WILL BE ADDED FOR MONEXT id: 161
//$_SETTINGS_id_user = 161;

//ALL PARTICIPANTS WILL BE ADDED FOR BPCE id: 208
//$_SETTINGS_id_user = 208;


//ALL PARTICIPANTS WILL BE ADDED FOR CNOSF id:140
//$_SETTINGS_id_user = 140;


//ALL PARTICIPANTS WILL BE ADDED FOR REED id:234
//$_SETTINGS_id_user = 234;

/*
//Access laravel sesssion
require '/var/www/laravel/bootstrap/autoload.php';
$app = require_once '/var/www/laravel/bootstrap/app.php';
$app->make('Illuminate\Contracts\Http\Kernel')
    ->handle(Illuminate\Http\Request::capture());



   	
$isAuthorized = Auth::check();

//if logged in and user id is in url

if (!$isAuthorized ){
echo "Permission denied";exit();
}

*/

require_once('../config.php');





printf("Initial character set: %s<br>", mysqli_character_set_name($db));

/* change character set to utf8 */
if (!mysqli_set_charset($db, "utf8")) {
    printf("Error loading character set utf8: %s<br>", mysqli_error($db));
    exit();
} else {
    printf("Current character set: %s<br><br>", mysqli_character_set_name($db));
}







define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

date_default_timezone_set('Europe/Paris');

/** PHPExcel_IOFactory */
require_once ('Classes/PHPExcel/IOFactory.php');






if (!file_exists ('import_file_utf8.xlsx')){	
	exit('No file to import: import_file_utf8.xlsx');
}

	





//echo date('H:i:s') , " Load from Excel2007 file" , EOL;




function getTeamID($team_name){
		global $db, $_SETTINGS_id_user;
	
		
		//search for team_name
		
		$sql = "SELECT * FROM `teams` WHERE `id_user` = '".$_SETTINGS_id_user."' AND `title` = '".addslashes($team_name)."'";
		if(!$result = $db->query($sql)){die('There was an error ['.$db->error.']');}
		$row = $result->fetch_assoc();
		
		//no team found so insert new
		if ($row['id']==''){
			$now = date('Y-m-d H:i:s');
			
		
			$team_name = addslashes($team_name);
			$sql = "INSERT INTO `teams` (id_user, title, created_at, updated_at) VALUES('".$_SETTINGS_id_user."','".$team_name."','".$now."', '".$now."')";	
			echo $sql."<br>";
			if(!$result = $db->query($sql)){die('There was an error ['.$db->error.']');}
			
			return $db->insert_id; 
			
		}else{
			return $row['id'];
		}
	
}








$objReader = PHPExcel_IOFactory::createReader('Excel2007');
$objPHPExcel = $objReader->load('import_file_utf8.xlsx');

//echo date('H:i:s') , " Iterate worksheets" , EOL;





$error ="
<b>Erreur des noms ou ordre des colonnes :</b><br><br>
01] Société<br>
02] Equipe<br>
03] Nom<br>
04] Prénom<br>
05] Email<br>";









//CHECK COLUMN NAMES
//STOP IMPORT IF ITEMS DO NOT MATCH LIST

//WORKSHEETS
$w=0;
foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {

$w++;

	if ($w>1){break;}
				
	//echo 'Worksheet - ' , $worksheet->getTitle() , EOL;

	//ROWS
	$r=0;
	foreach ($worksheet->getRowIterator() as $row) {
	$r++;
	
	if($r>1){break;}
	
	
		// skip first rows
		if($r==1){
		
			$cellIterator = $row->getCellIterator();
			$cellIterator->setIterateOnlyExistingCells(false); // Loop all cells, even if it is not set
			
			
			//CELLS
			$c=0;
			foreach ($cellIterator as $cell) {
			$c++;

				//if (!is_null($cell)) {	
					//echo '        Cell - ' , $cell->getCoordinate() , ' - ' , $cell->getCalculatedValue() , EOL;
				//}
				
				
				
				
			switch ($c) {

				//company
				case 1:
				if(trim($cell->getCalculatedValue())!="Société"){
					echo "Société:<br> ".$error;exit();
				}
				break;
				
				//team
				case 2:
				if(trim($cell->getCalculatedValue())!="Equipe"){
					echo "Equipe:<br> ".$error;exit();
				}
				break;
				
				//lastname
				case 3:
				if(trim($cell->getCalculatedValue())!="Nom"){
					echo "Nom:<br> ".$error;exit();
				}
				break;
				
				//firstname
				case 3:
				if(trim($cell->getCalculatedValue())!="Prénom"){
					echo "Prénom:<br> ".$error;exit();
				}
				break;
				
				//email
				case 3:
				if(trim($cell->getCalculatedValue())!="Email"){
					echo "Email:<br> ".$error;exit();
				}
				break;
				
		
			
			}
			
		}
		
		}	
	
	}


}















//IMPORT DATA


$skip_rows =1;


$main_array =Array();




//WORKSHEETS
$w=0;
foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {

$w++;

//only import 1st worksheet
//break out of loop
if ($w>1){break;}

			
	//echo 'Worksheet - ' , $worksheet->getTitle() , EOL;

	//ROWS
	$r=0;
	foreach ($worksheet->getRowIterator() as $row) {
	$r++;
		//echo '    Row number - ' , $row->getRowIndex() , EOL;

		// skip first rows
		if($r>$skip_rows){
	
			$cellIterator = $row->getCellIterator();
			$cellIterator->setIterateOnlyExistingCells(false); // Loop all cells, even if it is not set
			
			
			//CELLS
			$c=0;
			foreach ($cellIterator as $cell) {
			$c++;

				//if (!is_null($cell)) {	
					//echo '        Cell - ' , $cell->getCoordinate() , ' - ' , $cell->getCalculatedValue() , EOL;
				//}
				
				
				
				
			switch ($c) {

				//company
				case 1:
					$company = $cell->getCalculatedValue()."";
					echo 'Société: '.$company."<br>";
				break;
				
				//lastname
				case 2:
					$team = $cell->getCalculatedValue()."";
					$team_id = getTeamID($team);
					echo 'Equipe: '.$team."<br>";
				break;
							
				//lastname
				case 3:
					$lastname = $cell->getCalculatedValue()."";
					echo 'Nom: '.$lastname."<br>";
				break;
				
				//firstname
				case 4:
					$firstname = $cell->getCalculatedValue()."";
					echo 'Prénom: '.$firstname."<br>";
				break;
			
				//email
				case 5:
					$email = $cell->getCalculatedValue()."";
					echo 'Email: '.$email."<br>";
				break;
				
			
			}
			
			

				

				//echo 'A:'.$worksheet->getCellByColumnAndRow(0, $r)."...";
				
				//break out of cell loop + row parent loop at first occurance of empty col 1 
				if(trim($worksheet->getCellByColumnAndRow(0, $r))==''){break 2;}
			
				//}
			
			}
		
			// append to main array
			$now = date('Y-m-d H:i:s');
			
			$main_array[] = array(
			$_SETTINGS_id_user,
			$team_id,
			$lastname,
			$firstname,
			trim($email),
			$now,
			$now);
			
		}
	}
	

}



// before participants are created, teams may have already been created but teams are not duplicated see getTeamID()


//echo '<br>'.($r-$skip_rows-1). " Participants ajoutés<br>";




//worksheet 1 only
//echo $w."<br>";

if( $w==1){

 
 

	$stmt =  $db->stmt_init();
	$sql="INSERT INTO participants (id_user, id_team, pos, last_name, first_name , email, created_at, updated_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
	echo $sql."<br>";
	$stmt->prepare($sql);  
	
	$p=0;
	foreach($main_array as $row){
		
	   
	   
	     
		//increment pos number

		$pos=0;
		
		$sql2 = "SELECT MAX(pos) AS maxPos FROM `participants` WHERE `id_user` = '".$_SETTINGS_id_user."' AND `id_team` = '".$row[1]."' ";
		if(!$result2 = $db->query($sql2)){die('There was an error ['.$db->error.']');}
		if($result2){
			$row2 = $result2->fetch_assoc();
			$pos = ($row2['maxPos']+1);
		}
	
		if ($pos>3) {echo('ERROR >3 participants per team')."<br>";break;}
			
		echo $row[0].", ".$row[1].", ".$pos.", ".$row[2].", ".$row[3].", ".$row[4].", ".$row[5].", ".$row[6]."<br>";
			
		$stmt->bind_param('iiisssss', $row[0], $row[1], $pos, $row[2], $row[3], $row[4], $row[5], $row[6]);
		$stmt->execute();
		
		$p++;
	}
	
	
	echo $p." Participants added<br>";;

	if($stmt->error!=''){
		echo $stmt->error;
	}

	//printf("Error: %s.\n", $stmt->error);

	$stmt->close();
  
  
    
      
    
    
    



}




?>

