<?php


//REFRESH TOKEN IF CURRENT ACCESS TOKEN NOT VALID
//UPDATE POINTS IF LAST UPDATE WAS MORE THAN 24HRS AGO



//CALLED BY cron_update_async.php



//custom class in libraries folder
use App\Libraries\Moves;

require('/var/www/laravel/app/Libraries/Moves.php');

require('/var/www/laravel/app/Functions/movesConfig.php');

$m = new Moves($client_id,$client_secret,$redirect_url);



error_reporting(0);

session_start();




//Access laravel sesssion
require '/var/www/laravel/bootstrap/autoload.php';
$app = require_once '/var/www/laravel/bootstrap/app.php';
$app->make('Illuminate\Contracts\Http\Kernel')
    ->handle(Illuminate\Http\Request::capture());


	
//$isAuthorized = Auth::check();

//if logged in and user id is in url

//if (!$isAuthorized ){
//echo "Permission denied";exit;
//}


error_reporting(1);


require_once('config.php');


			$id = $_GET['id'];	
			$token = $_GET['access_token'];
			$refresh_token = $_GET['refresh_token'];
			
			
				
			$refresh_data = false;
			$now = date(time());
			$pts_updated = strtotime($_GET['pts_updated']);

			// VARIES PER PARTICIPANT
			// if more than 24 hrs have passed
			// 24*60*60 
			
			
			$range = (24*60*60);
			if ($pts_updated < $now-$range){
				$refresh_data = true;
			}
 
 			//DEV FORCE REFRESH
			$refresh_data = true;
			  
			 
			 	
				
			if($token!=''){
			
					$profile = json_encode($m->get_profile($token));
					if($profile=="null"){
				
				
					//REFRESH TOKEN CODE REMOVED !!!
					
					
					
						
					//all good	
					}else{
						//var_dump($token."::".$profile."<br><br>");
						
						if( $refresh_data == true){
						
						
							updatePoints($m, $id, $token);
						}
					}
					
					
				
			}
				
		




 
 
		
				function updatePoints($m, $id, $token){
					
					//default
					$initial_start_date = '2016-04-01';
					
					if(date("Y-m-d") >= '2016-11-07'){$initial_start_date = '2016-11-07';}
					
					if(date("Y-m-d") >= '2017-01-10'){$initial_start_date = '2017-01-10';}
									
					if(date("Y-m-d") >= '2017-04-02'){$initial_start_date = '2017-04-01';}
					
					if(date("Y-m-d") >= '2017-07-02'){$initial_start_date = '2017-07-01';}
					
					if(date("Y-m-d") >= '2017-12-31'){$initial_start_date = '2018-01-01';}
			
					
					//LOOP THROUGH MONTHS	

					//RESET pts
					$pts = 0;
	
					//$firstDate="";
	
					
					
					$profile = json_encode($m->get_profile($token));	
					$profile = json_decode($profile);					
					$userID = $profile->userId;
					 
					
					//FIRST DATE DATA IS AVALABLE FOR USER
					
					
					$firstDate = $profile->profile->firstDate;
					$firstDate = strtotime($firstDate);

					$start = $month = strtotime($initial_start_date);	
					$end = time();//END IS NOW :)
	
	
					//REQUIRED FOR CORRECT DATA RANGE			
					//check if firstDate is more recent than start_date if so use firstDate as start_date
					 if ($firstDate > $start){						
						$start = $month = $firstDate;
					 }
	 


					//LOOP THROUGH MONTHS
					while($month < $end)
					{
					//echo "<br>";
					//echo date('Y-m-d', $month)."<br>";
					//echo date('Y-m-d', $end)."<br>";
	
							/*				
							Thirty days hath September,
							April, June, and November.
							All the rest have thirty-one,
							Except for February alone,
							Which hath but twenty-eight days clear
							And twenty-nine in each leap year. 
							*/
	
							 // 01 to (30) OF THE CURRENT ITERATED MONTH
			 
			 
							 //current month
							 $start_date =  date('Y-m-d', $month);

			 
							 //last day of iterated month (t)
							 $end_date = date('Y-m-t', $month);
				
	
				
							 //check if iterated month is more recent than end if so use end as end_date					 
							 if ( date('Y-m-t',$month) > date('Y-m-d',$end) ){
								$end_date = date('Y-m-d', $end);	
							 }


							$summary = json_encode($m->get_range($token,'/user/summary/daily',$start_date, $end_date ));
			

							echo "<br><br>".$start_date." to ". $end_date."<br><br>";
							echo "<br><br>RAW DATA FROM MOVES:<br>".$summary."<br><br>";
							
							if (isset($summary)) {

										//get pts
						
										foreach (json_decode($summary) as $item){
						
												if (isset($item->summary[0])) {
				
									
														if (isset($item->summary[0])) {
														
															// lsm 11/15/16
															//LOOP THROUGH ACTIVITY GROUPS !!!
															foreach ($item->summary as $item2){
														
																if($item2->group != "transport"){										
																	$pts_data = ($item2->duration);
																	$pts = $pts + $pts_data;
																	
																	//added custom activities
																	if($item2->group!=''){
																		$activity_type=$item2->group;
																	}else{
																		$activity_type=$item2->activity;
																	}
																	
																	echo $item->date.": ".$activity_type.": ".round(($pts_data/60.0),0)."min <br>";
																} 
																
															}	  
															
														}  
	
									
												}									
			
										}
		
							}
	
	
	
	
	 
	
								// ITERATE TO NEXT MONTH
								// FIXED PROB OF PG points, next datedate was being set to +1 =31-05-2016 instead of 02-05-2016)
								//$month = strtotime("+1 month", $month);
								//$month = strtotime(date('Y-m-01', $month));
								
								
								
								
								//echo date('Y-m-01', $month)."<br>";
								
								// lsm 2/17/17
								$month = strtotime(date('Y-m-01', $month));
								$month = strtotime("+1 month", $month);  
								
				
				   				
						 
 								  
 								
 
			 
					}
					//END LOOP THROUGH MONTHS

			
							//convert to minutes
							$pts = ($pts/60.0);
			
			
												
							echo "<br><b>TOTAL POINTS: ". round($pts,0)." min "."</b><br />";
							
							
							//save pts to db (NEW PARTICIPANTS WILL HAVE DIFFERENT TIME STAMPS)		
							
							/*
							if($pts>0){
								//var_dump($participant->participant_id." ".$token." ".$pts."<br>");
								$row = DB::table('participants')->where('id', $id)->update(
									['pts' => $pts, 'pts_updated' => date('Y-m-d H:i:s')]
								);
							}
							*/




				}		


	 
?>